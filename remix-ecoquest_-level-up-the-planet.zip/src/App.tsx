import { useState, useEffect } from 'react';
import { 
  Home, 
  Flame, 
  Sparkles, 
  Gift, 
  User, 
  Camera, 
  Coins, 
  Volume2, 
  VolumeX, 
  X, 
  Leaf, 
  Clock, 
  Trophy, 
  Compass, 
  Bell,
  CloudCheck,
  FileSpreadsheet,
  Download,
  Database
} from 'lucide-react';

// Import Types
import { UserStats, DailyAction, PartnerReward, ProofPhoto, Pet, Friend } from './types';
import { getRequiredXP, getLevelUnlock } from './utils/levelUtils';

// Import Predefined Data
import { 
  INITIAL_ACTIONS, 
  INITIAL_PETS, 
  INITIAL_REWARDS, 
  PRELOADED_ALBUM 
} from './data';

// Import Custom Views
import HomeView from './components/HomeView';
import ActionsView from './components/ActionsView';
import IslandView from './components/IslandView';
import StoreView from './components/StoreView';
import ProfileView from './components/ProfileView';
import LoginView from './components/LoginView';
import ExcelDatabaseModal from './components/ExcelDatabaseModal';

// Excel Database Services
import { DatabaseState, exportDatabaseToExcel } from './services/excelDatabaseService';

// Firebase Services
import { 
  ensureAuth, 
  subscribeUserStats, 
  saveUserStatsToFirestore, 
  subscribeProofPhotos, 
  addProofPhotoToFirestore, 
  recordRedemptionInFirestore, 
  clearUserPhotosFromFirestore 
} from './services/firebaseService';

export default function App() {
  // Navigation State: 'home' | 'actions' | 'island' | 'store' | 'profile' | 'login'
  const [activeTab, setActiveTab] = useState<'home' | 'actions' | 'island' | 'store' | 'profile' | 'login'>('home');
  
  // Passed selected action ID to Proof Mode camera
  const [targetActionId, setTargetActionId] = useState<string>('clean_plate');

  // Firebase state
  const [userId, setUserId] = useState<string | null>(null);
  const [isFirebaseSynced, setIsFirebaseSynced] = useState<boolean>(false);

  // Load / Save States
  const [userStats, setUserStats] = useState<UserStats>(() => {
    const saved = localStorage.getItem('eco_stats_v2');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { /* fallback */ }
    }
    return {
      todayCO2: 2.4, // Perfect match with user prompt (2.4 kg CO2)
      totalCO2: 7.2,
      todayCoins: 35, // 35 / 100 Carbon Coin today
      coins: 120,
      streak: 3,
      level: 2,
      experience: 45,
      treesPlanted: 1, // Perfect match with user prompt (= Planted 1 tree)
      petId: 'nong_cloud',
    };
  });

  const [actions, setActions] = useState<DailyAction[]>(() => {
    const saved = localStorage.getItem('eco_actions_v2');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { /* fallback */ }
    }
    return INITIAL_ACTIONS;
  });

  const [rewards, setRewards] = useState<PartnerReward[]>(INITIAL_REWARDS);
  
  const [album, setAlbum] = useState<ProofPhoto[]>(() => {
    const saved = localStorage.getItem('eco_album_v2');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { /* fallback */ }
    }
    return PRELOADED_ALBUM;
  });

  const [friends, setFriends] = useState<Friend[]>(() => {
    const saved = localStorage.getItem('karb_friends_list');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { /* fallback */ }
    }
    return [
      {
        id: 'f1',
        name: 'คุณวินน์ หอสตรี',
        userIdCode: 'KARB-1001',
        avatar: '🦊',
        avatarType: 'emoji',
        level: 5,
        totalCO2: 14.8,
        completedActions: 18,
        status: 'online',
        joinedDate: '3 ส.ค. 2026'
      },
      {
        id: 'f2',
        name: 'น้องนุ่น ทันตะปีสาม',
        userIdCode: 'KARB-1002',
        avatar: '🐼',
        avatarType: 'emoji',
        level: 4,
        totalCO2: 11.2,
        completedActions: 14,
        status: 'online',
        joinedDate: '1 ส.ค. 2026'
      },
      {
        id: 'f3',
        name: 'พี่โชเฟอร์บัสส้ม',
        userIdCode: 'KARB-1003',
        avatar: '🦁',
        avatarType: 'emoji',
        level: 3,
        totalCO2: 8.5,
        completedActions: 9,
        status: 'offline',
        joinedDate: '28 ก.ค. 2026'
      }
    ];
  });

  // Excel Database Manager Modal state
  const [showExcelModal, setShowExcelModal] = useState<boolean>(false);

  // Synchronize state when imported from Excel
  const handleUpdateExcelDatabaseState = (newState: Partial<DatabaseState>) => {
    if (newState.userStats) setUserStats(newState.userStats);
    if (newState.actions) setActions(newState.actions);
    if (newState.album) setAlbum(newState.album);
    if (newState.friends) {
      setFriends(newState.friends);
      localStorage.setItem('karb_friends_list', JSON.stringify(newState.friends));
    }
    if (newState.rewards) setRewards(newState.rewards);
    showNotification("ซิงค์ฐานข้อมูล Excel สำเร็จ! 💾", "อัปเดตข้อมูลชีตลงในระบบแอปพลิเคชันเรียบร้อยแล้ว", "📊");
  };

  // Initialize Firebase Auth and Real-time listeners
  useEffect(() => {
    let unsubStats: (() => void) | null = null;
    let unsubAlbum: (() => void) | null = null;

    ensureAuth().then((user) => {
      setUserId(user.uid);
      setIsFirebaseSynced(true);

      // Subscribe to userStats in Firestore
      unsubStats = subscribeUserStats(user.uid, userStats, (remoteStats) => {
        setUserStats(remoteStats);
      });

      // Subscribe to album in Firestore
      unsubAlbum = subscribeProofPhotos(user.uid, album, (remotePhotos) => {
        setAlbum(remotePhotos);
      });
    }).catch(err => {
      console.error("Firebase auth initialization failed:", err);
    });

    return () => {
      if (unsubStats) unsubStats();
      if (unsubAlbum) unsubAlbum();
    };
  }, []);

  const [wateredTiles, setWateredTiles] = useState<Record<number, boolean>>({});
  const [isSoundEnabled, setIsSoundEnabled] = useState<boolean>(true);
  
  // Custom Popups / Celebrations
  const [showLevelUpModal, setShowLevelUpModal] = useState<boolean>(false);
  const [appNotification, setAppNotification] = useState<{ title: string; body: string; icon: string } | null>(null);

  // Auto-save states to local storage and Firestore
  useEffect(() => {
    localStorage.setItem('eco_stats_v2', JSON.stringify(userStats));
    if (userId) {
      saveUserStatsToFirestore(userId, userStats);
    }
  }, [userStats, userId]);

  useEffect(() => {
    localStorage.setItem('eco_actions_v2', JSON.stringify(actions));
  }, [actions]);

  useEffect(() => {
    localStorage.setItem('eco_album_v2', JSON.stringify(album));
  }, [album]);

  // Dynamic ticking clock for top mockup frame bar
  const [timeFormatted, setTimeFormatted] = useState<string>('');
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      let hours = now.getHours();
      let minutes = now.getMinutes();
      const strHours = hours < 10 ? '0' + hours : hours;
      const strMins = minutes < 10 ? '0' + minutes : minutes;
      setTimeFormatted(`${strHours}:${strMins}`);
    };
    updateTime();
    const interval = setInterval(updateTime, 15000);
    return () => clearInterval(interval);
  }, []);

  // Simple Synthesizer Audio Trigger for satisfying gaming feedback
  const playBeepTone = (frequency: number, type: 'sine' | 'triangle' | 'sawtooth' | 'square', duration: number) => {
    if (!isSoundEnabled) return;
    try {
      const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      
      osc.type = type;
      osc.frequency.setValueAtTime(frequency, ctx.currentTime);
      
      gain.gain.setValueAtTime(0.12, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);
      
      osc.connect(gain);
      gain.connect(ctx.destination);
      
      osc.start();
      osc.stop(ctx.currentTime + duration);
    } catch (e) {
      // Ignored if audio blocked
    }
  };

  const playSuccessSound = () => {
    playBeepTone(440, 'sine', 0.15);
    setTimeout(() => {
      playBeepTone(659, 'sine', 0.2);
    }, 120);
    setTimeout(() => {
      playBeepTone(880, 'sine', 0.35);
    }, 240);
  };

  const playClaimRewardSound = () => {
    playBeepTone(587, 'triangle', 0.1);
    setTimeout(() => {
      playBeepTone(880, 'triangle', 0.1);
    }, 80);
    setTimeout(() => {
      playBeepTone(1174, 'sine', 0.3);
    }, 160);
  };

  const playLevelUpSound = () => {
    const tones = [261, 329, 392, 523, 659, 783, 1046];
    tones.forEach((tone, index) => {
      setTimeout(() => {
        playBeepTone(tone, 'sawtooth', 0.25);
      }, index * 100);
    });
  };

  const showNotification = (title: string, body: string, icon: string) => {
    setAppNotification({ title, body, icon });
    playSuccessSound();
    
    // Auto clear notification
    setTimeout(() => {
      setAppNotification(null);
    }, 3800);
  };

  // Transaction: Redeem Carbon Coin reward
  const handleRedeemReward = (rewardId: string, coinCost: number) => {
    const targetReward = rewards.find(r => r.id === rewardId);

    setUserStats(prev => ({
      ...prev,
      coins: Math.max(0, prev.coins - coinCost),
    }));

    // Increment redeemed counter inside store
    setRewards(prev => prev.map(reward => {
      if (reward.id === rewardId) {
        return { ...reward, redeemedCount: reward.redeemedCount + 1 };
      }
      return reward;
    }));

    if (userId && targetReward) {
      recordRedemptionInFirestore(
        userId, 
        rewardId, 
        targetReward.partnerName, 
        targetReward.title, 
        targetReward.promoCode
      );
    }

    playClaimRewardSound();
  };

  // Trigger Simple Action Tap
  const handleTriggerAction = (action: DailyAction, viaProof: boolean) => {
    playBeepTone(493, 'sine', 0.15);
    setTimeout(() => {
      playBeepTone(987, 'sine', 0.15);
    }, 100);

    // Increase XP and co2 savings
    setUserStats(prev => {
      const addedXP = 15;
      let newLevel = prev.level;
      let newXP = prev.experience + addedXP;
      let didLevelUp = false;

      const requiredForCurrent = getRequiredXP(newLevel);
      if (newXP >= requiredForCurrent) {
        newXP = newXP - requiredForCurrent;
        newLevel += 1;
        didLevelUp = true;
      }

      const calculatedTodayCO2 = prev.todayCO2 + action.baseCO2;
      
      // Calculate how many trees are earned:
      // In the game definition, let's say 2.4 kg CO2 = 1 tree planted.
      const calculatedTrees = Math.floor(calculatedTodayCO2 / 2.4);

      // Enforce 100 Carbon Coin daily cap
      const currentTodayCoins = prev.todayCoins || 0;
      const maxCoinsAllowed = Math.max(0, 100 - currentTodayCoins);
      const actualCoinsGained = Math.min(action.coinReward, maxCoinsAllowed);

      if (didLevelUp) {
        setTimeout(() => {
          setShowLevelUpModal(true);
          playLevelUpSound();
        }, 500);
      }

      return {
        ...prev,
        todayCO2: calculatedTodayCO2,
        totalCO2: prev.totalCO2 + action.baseCO2,
        todayCoins: currentTodayCoins + actualCoinsGained,
        coins: prev.coins + actualCoinsGained,
        experience: newXP,
        level: newLevel,
        treesPlanted: Math.max(prev.treesPlanted, calculatedTrees),
      };
    });
  };

  // Process camera photo submissions for double reward!
  const handleAddProofPhoto = (newPhoto: Omit<ProofPhoto, 'id' | 'date'>) => {
    const finalPhoto: ProofPhoto = {
      ...newPhoto,
      id: 'photo_' + Date.now(),
      date: 'วันนี้ ' + new Date().toLocaleTimeString('th-TH', { hour: '2-digit', minute: '2-digit' }),
    };

    setAlbum(prev => [finalPhoto, ...prev]);

    if (userId) {
      addProofPhotoToFirestore(userId, finalPhoto);
    }

    // Apply stats rewards
    setUserStats(prev => {
      const addedXP = 30; // Double XP for photo validation!
      let newLevel = prev.level;
      let newXP = prev.experience + addedXP;
      let didLevelUp = false;

      const requiredForCurrent = getRequiredXP(newLevel);
      if (newXP >= requiredForCurrent) {
        newXP = newXP - requiredForCurrent;
        newLevel += 1;
        didLevelUp = true;
      }

      const calculatedTodayCO2 = prev.todayCO2 + newPhoto.co2Saved;
      const calculatedTrees = Math.floor(calculatedTodayCO2 / 2.4);

      // Enforce 100 Carbon Coin daily cap
      const currentTodayCoins = prev.todayCoins || 0;
      const maxCoinsAllowed = Math.max(0, 100 - currentTodayCoins);
      const actualCoinsGained = Math.min(newPhoto.coinsEarned, maxCoinsAllowed);

      if (didLevelUp) {
        setTimeout(() => {
          setShowLevelUpModal(true);
          playLevelUpSound();
        }, 500);
      }

      return {
        ...prev,
        todayCO2: calculatedTodayCO2,
        totalCO2: prev.totalCO2 + newPhoto.co2Saved,
        todayCoins: currentTodayCoins + actualCoinsGained,
        coins: prev.coins + actualCoinsGained,
        experience: newXP,
        level: newLevel,
        treesPlanted: Math.max(prev.treesPlanted, calculatedTrees),
      };
    });
  };

  // Quick select an action element to send to proof screen
  const navigateToProof = (actionId: string) => {
    setTargetActionId(actionId);
    setActiveTab('proof');
    playBeepTone(329, 'sine', 0.1);
  };

  // Interact with tree tiles inside 3D / isometric view (watering visual delight - 0 coins awarded)
  const handleWaterTree = (tileIndex: number) => {
    playBeepTone(400, 'triangle', 0.15);
    setTimeout(() => {
      playBeepTone(800, 'sine', 0.2);
    }, 80);

    setWateredTiles(prev => ({ ...prev, [tileIndex]: !prev[tileIndex] }));

    if (!wateredTiles[tileIndex]) {
      showNotification("รดน้ำต้นไม้รักษ์โลกสดชื่น! 💧", "ต้นไม้ได้รับน้ำชุ่มฉ่ำและเติบโตอย่างสวยงามบนเกาะของคุณ", "🌱");
    }
  };

  // Selected pet changer
  const handleSelectPet = (id: string) => {
    setUserStats(prev => ({ ...prev, petId: id }));
    playBeepTone(523, 'sine', 0.12);
  };

  // Invite dynamic friend
  const handleAddFriend = (name: string) => {
    showNotification(
      "เชิญเพื่อนเล่นสำเร็จ! 🤝",
      `ชวน ${name} เข้าร่วมชุมชนเรียบร้อยแล้ว แข่งกันลดคาร์บอนเซฟ!`,
      "⭐"
    );
  };

  // Reset Photo album
  const handleClearAlbum = () => {
    if (confirm("คุณแน่ใจหรือไม่ที่จะทำการรีเซ็ตบันทึกใบเสร็จภาพถ่ายในอุปกรณ์นี้?")) {
      setAlbum(PRELOADED_ALBUM);
      setUserStats(prev => ({ ...prev, todayCO2: 2.4, treesPlanted: 1 }));
      if (userId) {
        clearUserPhotosFromFirestore(userId);
      }
      showNotification("รีเซ็ตคลังเรียบร้อยฮะ", "ข้อมูลบันทึกรีเซ็ตเข้าสู่สแตนดาร์ดเรียบร้อย!", "♻️");
    }
  };

  const handleLoginSuccess = (name?: string) => {
    setActiveTab('home');
    showNotification("ยินดีต้อนรับสู่ KARB! 🌱", `สวัสดี ${name || 'นิสิตนักศึกษา'}! เชื่อมต่อ Firebase Firestore เรียบร้อยแล้ว`, "✨");
  };

  const currentPet = INITIAL_PETS.find(p => p.id === userStats.petId) || INITIAL_PETS[0];

  return (
    <div className="min-h-screen bg-emerald-100 flex flex-col items-center justify-center py-6 px-4">
      
      {/* Upper Brand / Desktop instructions & Excel Database Quick Panel */}
      <div className="absolute top-4 left-6 hidden lg:block max-w-xs space-y-3">
        <div className="flex items-center gap-2">
          <Leaf className="w-6 h-6 text-emerald-600 animate-spin" style={{ animationDuration: '8s' }} />
          <h1 className="text-emerald-950 font-black text-lg tracking-tight">EcoQuest 2026</h1>
        </div>
        <p className="text-xs text-emerald-800/80 leading-relaxed">
          แอปเกมลดคาร์บอนสุดสนุกสำหรับนิสิต นักศึกษา นักคิดผลิตภัณฑ์ แตะควบคุมง่ายๆ ดูความก้าวหน้า ปลดล็อคโค้ดพาร์ทเนอร์ และเลี้ยงสัตว์เลี้ยงคู่หู!
        </p>
        
        {/* Excel Database Status & Controller Card */}
        <div className="bg-white/90 backdrop-blur-md rounded-2xl p-3 border border-emerald-300 shadow-sm space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5 text-xs font-black text-emerald-900">
              <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
              <span>ฐานข้อมูล Excel (.xlsx)</span>
            </div>
            <span className="bg-emerald-100 text-emerald-800 text-[9px] font-mono font-bold px-1.5 py-0.5 rounded">
              ONLINE
            </span>
          </div>
          <p className="text-[11px] text-slate-600 leading-tight">
            บันทึกและส่งออกข้อมูลทั้งหมด 5 ชีต (ผู้ใช้, ภารกิจ, รูปภาพ, เพื่อน, รางวัล)
          </p>
          <div className="flex gap-1.5 pt-1">
            <button
              onClick={() => setShowExcelModal(true)}
              className="flex-1 px-2.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[11px] rounded-xl shadow-xs transition flex items-center justify-center gap-1 cursor-pointer"
            >
              <Database className="w-3 h-3" />
              <span>เปิดจัดการ Excel</span>
            </button>
            <button
              onClick={() => {
                exportDatabaseToExcel({ userStats, actions, album, friends, rewards });
                showNotification("ดาวน์โหลด Excel สำเร็จ! 📥", "ส่งออกไฟล์ฐานข้อมูล .xlsx ครบทุกชีตแล้ว", "📊");
              }}
              className="px-2.5 py-1.5 bg-emerald-100 hover:bg-emerald-200 text-emerald-900 font-bold text-[11px] rounded-xl transition flex items-center justify-center gap-1 cursor-pointer"
              title="ดาวน์โหลด Excel ทันที"
            >
              <Download className="w-3 h-3 text-emerald-700" />
              <span>โหลด .xlsx</span>
            </button>
          </div>
        </div>

        {isFirebaseSynced && (
          <div className="flex items-center gap-1.5 text-[11px] font-bold text-emerald-800 bg-emerald-200/80 px-2.5 py-1 rounded-full w-fit border border-emerald-300">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
            <span>เชื่อมต่อ Firebase Firestore สำเร็จ ☁️</span>
          </div>
        )}
      </div>

      {/* Primary Mobile Phone Frame Simulator Container */}
      <div className="w-full max-w-md bg-slate-900 rounded-[50px] p-3.5 shadow-2xl border-4 border-slate-700/80 ring-12 ring-slate-950/20 relative">
        
        {/* Top Speaker / Dynamic Island notch visual */}
        <div className="absolute top-6 left-1/2 -translate-x-1/2 w-40 h-6 bg-slate-950 rounded-full z-40 flex items-center justify-between px-3.5 border border-white/5 shadow-inner">
          <span className="w-2.5 h-2.5 rounded-full bg-slate-900 border border-slate-800" />
          <span className="w-10 h-1.5 rounded-full bg-slate-800/60" />
          <span className="w-2 h-2 rounded-full bg-blue-500/20" />
        </div>

        {/* Outer buttons decorative */}
        <div className="absolute -left-1.5 top-28 w-1 h-12 bg-slate-700 rounded-r-lg" />
        <div className="absolute -left-1.5 top-44 w-1 h-12 bg-slate-700 rounded-r-lg" />
        <div className="absolute -right-1.5 top-32 w-1 h-16 bg-slate-700 rounded-l-lg" />

        {/* Screen layout nested with rounded inset */}
        <div className="bg-emerald-50 w-full rounded-[40px] overflow-hidden flex flex-col h-[740px] relative">
          
          {/* A. Status Frame Bar mockup top */}
          <div className="bg-emerald-600 text-white pt-6 pb-2.5 px-6 flex justify-between items-center text-xs select-none">
            {/* Left Dynamic Local clock */}
            <span className="font-extrabold tracking-wide flex items-center gap-1">
              <Clock className="w-3.5 h-3.5 text-brand-lime" />
              <span>{timeFormatted || '19:18'}</span>
            </span>

            {/* Right mock wireless network widgets, excel db quick button and sound toggler */}
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => setShowExcelModal(true)}
                className="text-[10px] bg-emerald-800 hover:bg-emerald-700 text-brand-lime px-2 py-0.5 rounded-full font-bold flex items-center gap-1 transition shadow-2xs cursor-pointer"
                title="เปิดจัดการฐานข้อมูล Excel (.xlsx)"
              >
                <FileSpreadsheet className="w-3 h-3 text-emerald-300" />
                <span>Excel DB</span>
              </button>

              {isFirebaseSynced && (
                <span className="text-[10px] bg-emerald-800 text-brand-lime px-1.5 py-0.5 rounded-full font-bold flex items-center gap-0.5" title="Firebase Live Sync Active">
                  ☁️ Live
                </span>
              )}
              <button
                onClick={() => setIsSoundEnabled(!isSoundEnabled)}
                className="p-1 rounded-md hover:bg-emerald-700 transition"
                title={isSoundEnabled ? 'ปิดเสียงเอฟเฟกต์' : 'เปิดเสียงเอฟเฟกต์'}
              >
                {isSoundEnabled ? <Volume2 className="w-3.5 h-3.5 text-brand-lime animate-pulse" /> : <VolumeX className="w-3.5 h-3.5 text-slate-300" />}
              </button>
              <span className="text-[10px] bg-emerald-800 px-1.5 py-0.5 rounded-full font-bold">
                5G ⚡
              </span>
              <span className="text-[10px] text-brand-lime font-black">99%🔋</span>
            </div>
          </div>

          {/* B. Sticky Compact header widget for immediate global coins counters */}
          <div className="bg-white px-5 py-3 border-b border-slate-100 flex justify-between items-center z-10 shadow-xs relative">
            <button 
              onClick={() => setActiveTab('login')} 
              className="flex items-center gap-1.5 text-left group hover:opacity-90 transition"
              title="กดเพื่อเปิดหน้าเข้าสู่ระบบ KARB"
            >
              <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-emerald-500 to-lime-400 flex items-center justify-center text-emerald-950 font-black shadow-sm group-hover:scale-105 transition-transform">
                🌱
              </div>
              <div>
                <h2 className="text-xs font-black text-slate-800 flex items-center gap-1">
                  <span>KARB</span>
                  <span className="text-[9px] bg-emerald-100 text-emerald-800 font-bold px-1.5 py-0.2 rounded-full border border-emerald-200">
                    {activeTab === 'login' ? 'หน้าล็อกอิน' : 'เข้าสู่ระบบ'}
                  </span>
                </h2>
                <span className="text-[9px] text-slate-400 font-mono block">Small Actions, Big Impact</span>
              </div>
            </button>

            <div className="flex items-center gap-2">
              {/* Carbon Coins total */}
              <div className="bg-yellow-100 border border-yellow-200/50 rounded-full py-1 px-3 flex items-center gap-1">
                <Coins className="w-3.5 h-3.5 text-amber-500 animate-bounce" />
                <span className="text-xs font-black text-slate-800 translate-y-0.5">{userStats.coins}</span>
              </div>

              {/* Home mini indicator indicator */}
              <div className="bg-orange-100 border border-orange-200/50 rounded-full py-1 px-2.5 flex items-center gap-1">
                <Flame className="w-3.5 h-3.5 text-brand-orange" />
                <span className="text-xs font-black text-slate-850 translate-y-0.5">{userStats.streak}วัน</span>
              </div>
            </div>
          </div>

          {/* C. Scrollable Inner main content with tabs render */}
          <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4">
            
            {/* View renders */}
            {activeTab === 'login' && (
              <LoginView
                onLoginSuccess={handleLoginSuccess}
              />
            )}

            {activeTab === 'home' && (
              <HomeView
                stats={userStats}
                currentPet={currentPet}
                allPets={INITIAL_PETS}
                onSelectPet={handleSelectPet}
                onWaterTree={handleWaterTree}
                wateredTiles={wateredTiles}
              />
            )}

            {activeTab === 'actions' && (
              <ActionsView
                actions={actions}
                onTriggerAction={handleTriggerAction}
                onAddProofPhoto={handleAddProofPhoto}
                onShowNotification={showNotification}
                stats={userStats}
              />
            )}

            {activeTab === 'island' && (
              <IslandView
                stats={userStats}
                currentPet={currentPet}
                userId={userId}
                onWaterTree={handleWaterTree}
                onDecorationsChange={(newDecor) => {
                  setUserStats(prev => ({ ...prev, islandDecorations: newDecor }));
                }}
              />
            )}

            {activeTab === 'store' && (
              <StoreView
                userCoins={userStats.coins}
                rewards={rewards}
                onRedeemReward={handleRedeemReward}
                onShowNotification={showNotification}
              />
            )}

            {activeTab === 'profile' && (
              <ProfileView
                stats={userStats}
                album={album}
                onAddFriend={handleAddFriend}
                onClearAlbum={handleClearAlbum}
                onGoToLogin={() => setActiveTab('login')}
                userId={userId}
                onOpenExcelDatabase={() => setShowExcelModal(true)}
              />
            )}

          </div>

          {/* D. Beautiful Tab-bar navigation bottom wrapper */}
          <div className="bg-white border-t border-slate-100 px-3 py-2 flex justify-between items-center select-none shadow-[0_-5px_15px_rgba(0,0,0,0.03)] z-10 rounded-b-[40px]">
            {/* 1. Home tab */}
            <button
              onClick={() => { setActiveTab('home'); playBeepTone(261, 'sine', 0.1); }}
              className={`flex-1 py-1 flex flex-col items-center justify-center transition-all ${
                activeTab === 'home' 
                  ? 'text-emerald-600 font-extrabold translate-y-[-2px]' 
                  : 'text-slate-400 font-medium hover:text-slate-650'
              }`}
            >
              <div className={`p-1.5 rounded-xl transition-all ${activeTab === 'home' ? 'bg-emerald-100 text-emerald-800' : 'bg-transparent'}`}>
                <Home className="w-5 h-5" />
              </div>
              <span className="text-[10px] mt-1">หน้าหลัก</span>
            </button>

            {/* 2. Actions tab */}
            <button
              onClick={() => { setActiveTab('actions'); playBeepTone(293, 'sine', 0.1); }}
              className={`flex-1 py-1 flex flex-col items-center justify-center transition-all ${
                activeTab === 'actions' 
                  ? 'text-emerald-600 font-extrabold translate-y-[-2px]' 
                  : 'text-slate-400 font-medium hover:text-slate-650'
              }`}
            >
              <div className={`p-1.5 rounded-xl transition-all ${activeTab === 'actions' ? 'bg-emerald-100 text-emerald-800' : 'bg-transparent'}`}>
                <Leaf className="w-5 h-5" />
              </div>
              <span className="text-[10px] mt-1">กิจกรรม</span>
            </button>

            {/* 3. Carbon Island 3D tab */}
            <button
              onClick={() => { setActiveTab('island'); playBeepTone(329, 'sine', 0.1); }}
              className={`flex-1 py-1 flex flex-col items-center justify-center transition-all ${
                activeTab === 'island' 
                  ? 'text-emerald-600 font-extrabold translate-y-[-2px]' 
                  : 'text-slate-400 font-medium hover:text-slate-650'
              }`}
            >
              <div className={`p-1.5 rounded-xl transition-all ${activeTab === 'island' ? 'bg-emerald-100 text-emerald-800' : 'bg-transparent'}`}>
                <Sparkles className="w-5 h-5" />
              </div>
              <span className="text-[10px] mt-1">เกาะ 3D</span>
            </button>

            {/* 4. Partner Store tab */}
            <button
              onClick={() => { setActiveTab('store'); playBeepTone(349, 'sine', 0.1); }}
              className={`flex-1 py-1 flex flex-col items-center justify-center transition-all ${
                activeTab === 'store' 
                  ? 'text-emerald-600 font-extrabold translate-y-[-2px]' 
                  : 'text-slate-400 font-medium hover:text-slate-650'
              }`}
            >
              <div className={`p-1.5 rounded-xl transition-all ${activeTab === 'store' ? 'bg-amber-100 text-amber-800' : 'bg-transparent'}`}>
                <Gift className="w-5 h-5" />
              </div>
              <span className="text-[10px] mt-1">แลกรางวัล</span>
            </button>

            {/* 5. Profile Tab */}
            <button
              onClick={() => { setActiveTab('profile'); playBeepTone(392, 'sine', 0.1); }}
              className={`flex-1 py-1 flex flex-col items-center justify-center transition-all ${
                activeTab === 'profile' 
                  ? 'text-emerald-600 font-extrabold translate-y-[-2px]' 
                  : 'text-slate-400 font-medium hover:text-slate-650'
              }`}
            >
              <div className={`p-1.5 rounded-xl transition-all ${activeTab === 'profile' ? 'bg-emerald-100 text-emerald-800' : 'bg-transparent'}`}>
                <User className="w-5 h-5" />
              </div>
              <span className="text-[10px] mt-1">โปรไฟล์</span>
            </button>
          </div>

          {/* E. Level up Celebration Success Popup Modal overlay */}
          {showLevelUpModal && (() => {
            const unlockInfo = getLevelUnlock(userStats.level);
            return (
              <div className="absolute inset-0 bg-slate-900/85 backdrop-blur-sm z-50 flex flex-col items-center justify-center p-5 animate-scale-up">
                <div className="bg-white rounded-3xl p-5 w-full max-w-sm text-center border-4 border-brand-lime shadow-2xl space-y-3.5 max-h-[90%] overflow-y-auto">
                  
                  {/* Graphics */}
                  <div className="relative pt-2">
                    <div className="text-6xl animate-bounce">{unlockInfo.icon} 🎉</div>
                    <div className="absolute -top-1 -right-2 text-2xl animate-pulse">🔥</div>
                    <div className="absolute -bottom-1 -left-2 text-2xl animate-pulse">🌱</div>
                  </div>

                  <div className="space-y-1">
                    <span className="text-[10px] font-black text-amber-600 uppercase tracking-widest bg-amber-100 px-2.5 py-0.5 rounded-full inline-block">
                      LEVEL UP CELEBRATION
                    </span>
                    <h3 className="text-xl font-black text-slate-900">ปลดล็อกระดับ {userStats.level}!</h3>
                    <p className="text-xs text-slate-600 font-bold">
                      {unlockInfo.title}
                    </p>
                  </div>

                  {/* Level Unlocked Item Card */}
                  <div className="bg-gradient-to-br from-emerald-500 to-teal-600 rounded-2xl p-3.5 text-white text-left shadow-sm relative overflow-hidden">
                    <div className="text-[9px] font-black uppercase text-emerald-100 tracking-wider">
                      ✨ ปลดล็อกใหม่บน Carbon Island 3D
                    </div>
                    <div className="flex items-center gap-2.5 mt-1">
                      <div className="text-3xl bg-white/20 p-2 rounded-xl shrink-0">
                        {unlockInfo.icon}
                      </div>
                      <div>
                        <h5 className="text-xs font-black text-white">{unlockInfo.unlockedItem}</h5>
                        <p className="text-[10px] text-emerald-100 leading-tight mt-0.5">{unlockInfo.description}</p>
                      </div>
                    </div>
                  </div>

                  {/* Level Up reward item card */}
                  <div className="bg-amber-50 rounded-2xl p-3 border border-amber-200 text-left flex items-center gap-3">
                    <div className="bg-amber-400 text-amber-950 p-2 rounded-xl text-lg font-black shrink-0">
                      +100🪙
                    </div>
                    <div>
                      <h5 className="text-xs font-bold text-slate-800">โบนัสเหรียญพิเศษ</h5>
                      <p className="text-[10px] text-slate-500">มอบเหรียญสะสม 100 Carbon Coin สำหรับพัฒนาเกาะอย่างมุ่งมั่น</p>
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      setUserStats(prev => ({ ...prev, coins: prev.coins + 100 }));
                      setShowLevelUpModal(false);
                      playBeepTone(523, 'sine', 0.15);
                    }}
                    className="w-full bg-slate-950 hover:bg-slate-800 text-white font-extrabold text-xs py-3.5 rounded-2xl transition-all shadow-md tactile-btn"
                  >
                    รับของขวัญ & ตรวจสอบเกาะ 3D 🚀
                  </button>
                </div>
              </div>
            );
          })()}

          {/* F. In-App Notifications Toast indicator overlay */}
          {appNotification && (
            <div className="absolute top-16 inset-x-4 bg-slate-900/95 backdrop-blur-md border border-white/10 rounded-2xl p-3.5 shadow-xl text-white z-50 animate-fade-in flex items-start gap-3">
              <div className="text-2xl pt-1">
                {appNotification.icon}
              </div>
              <div className="flex-1 min-w-0">
                <h5 className="text-xs font-black text-brand-lime">{appNotification.title}</h5>
                <p className="text-[11px] text-slate-200 leading-normal mt-0.5">{appNotification.body}</p>
              </div>
              <button 
                onClick={() => setAppNotification(null)}
                className="text-slate-400 hover:text-white p-0.5"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

        </div>
      </div>

      {/* Decorative footer credits for Thailand students */}
      <div className="mt-5 text-center space-y-1">
        <p className="text-[10.5px] text-emerald-900/60 font-semibold uppercase tracking-wider flex items-center justify-center gap-1.5 select-none">
          <span>CO₂ REDUCER CHIC & FUN 2026</span>
          <span>•</span>
          <span>THAILAND GREEN REVOLUTION</span>
        </p>
      </div>

      {/* Excel Database Manager Full Modal */}
      <ExcelDatabaseModal
        isOpen={showExcelModal}
        onClose={() => setShowExcelModal(false)}
        userStats={userStats}
        actions={actions}
        album={album}
        friends={friends}
        rewards={rewards}
        onUpdateState={handleUpdateExcelDatabaseState}
      />
    </div>
  );
}
