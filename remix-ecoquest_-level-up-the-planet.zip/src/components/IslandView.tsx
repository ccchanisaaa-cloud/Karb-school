import React, { useState } from 'react';
import { 
  Star, 
  Flame, 
  Coins, 
  Trees, 
  Sparkles, 
  ChevronRight, 
  Clock, 
  MapPin, 
  X, 
  Lock, 
  CheckCircle2, 
  Sun, 
  Moon, 
  Sunrise, 
  Sunset,
  Compass,
  Info,
  Layers,
  Award
} from 'lucide-react';
import { UserStats, Pet, PlacedDecoration } from '../types';
import CarbonIsland3D from './CarbonIsland3D';
import { getRequiredXP, getLevelUnlock } from '../utils/levelUtils';

interface IslandViewProps {
  stats: UserStats;
  currentPet: Pet;
  userId?: string | null;
  onWaterTree?: (index: number) => void;
  onDecorationsChange?: (decorations: PlacedDecoration[]) => void;
}

export default function IslandView({ 
  stats, 
  currentPet, 
  userId, 
  onWaterTree, 
  onDecorationsChange 
}: IslandViewProps) {
  const [showRoadmapModal, setShowRoadmapModal] = useState(false);

  // CO2 to trees calculation: 2.4 kg CO2 = 1 Tree (as requested in user prompt)
  const treesFromCO2 = Math.floor(stats.totalCO2 / 2.4);
  const requiredXP = getRequiredXP(stats.level);
  const progressPct = Math.min(100, Math.floor((stats.experience / requiredXP) * 100));

  const currentUnlock = getLevelUnlock(stats.level);
  const nextUnlock = getLevelUnlock(stats.level + 1);

  return (
    <div className="space-y-4 pb-4">
      
      {/* 1. Header HUD Summary Bar */}
      <div className="bg-gradient-to-br from-slate-900 via-teal-950 to-emerald-950 rounded-3xl p-4 text-white border border-emerald-500/30 shadow-2xl relative overflow-hidden">
        {/* Playful background glow */}
        <div className="absolute top-0 right-0 w-36 h-36 bg-emerald-500/10 rounded-full blur-2xl" />
        <div className="absolute bottom-0 left-0 w-28 h-28 bg-lime-400/10 rounded-full blur-xl" />

        <div className="flex items-center justify-between gap-2 relative z-10">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-500 to-lime-400 flex items-center justify-center text-emerald-950 font-black text-xl shadow-lg border border-white/20">
              🏝️
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h1 className="text-base font-black text-white">Carbon Island 3D</h1>
                <span className="text-[9px] font-black uppercase text-emerald-950 bg-brand-lime px-2 py-0.5 rounded-full">
                  LIVE WORLD
                </span>
              </div>
              <p className="text-[10px] text-emerald-200/80">
                เกาะลอยฟ้า 3D เติบโตตามปริมาณคาร์บอนที่ลดได้
              </p>
            </div>
          </div>

          {/* Level Badge button */}
          <button
            onClick={() => setShowRoadmapModal(true)}
            className="bg-brand-lime hover:bg-lime-400 text-emerald-950 font-bold px-3 py-1.5 rounded-2xl flex flex-col items-center justify-center border-b-4 border-emerald-700 shadow-md min-w-[64px] transition-transform active:scale-95 cursor-pointer"
            title="กดเพื่อดูแผนผังการปลดล็อกระดับ"
          >
            <span className="text-[8px] uppercase tracking-widest opacity-80 font-black">LEVEL</span>
            <span className="text-lg leading-none font-black">{stats.level}</span>
            <span className="text-[8px] bg-emerald-900/20 text-emerald-950 px-1 rounded mt-0.5 font-extrabold">Roadmap</span>
          </button>
        </div>

        {/* Level Progress Bar & Stats HUD Grid */}
        <div className="mt-3.5 pt-3 border-t border-emerald-500/20 space-y-2 relative z-10">
          {/* XP Progress */}
          <div className="space-y-1">
            <div className="flex justify-between text-[11px] font-medium text-emerald-100">
              <span className="flex items-center gap-1">
                <Star className="w-3.5 h-3.5 text-yellow-300 fill-yellow-300 animate-pulse" />
                <span>ความคืบหน้า Level {stats.level}</span>
              </span>
              <span className="font-mono font-bold text-yellow-200">
                {stats.experience} / {requiredXP} XP ({progressPct}%)
              </span>
            </div>
            <div className="w-full bg-black/40 h-2.5 rounded-full overflow-hidden p-0.5 border border-emerald-400/20">
              <div
                className="bg-gradient-to-r from-brand-lime via-emerald-400 to-yellow-300 h-full rounded-full transition-all duration-500 shadow-sm"
                style={{ width: `${progressPct}%` }}
              />
            </div>
          </div>

          {/* Core HUD Metrics Pill Grid */}
          <div className="grid grid-cols-3 gap-2 pt-1 text-center text-xs">
            {/* Total CO2 */}
            <div className="bg-white/5 border border-white/10 rounded-2xl p-2 backdrop-blur-sm">
              <span className="text-[9px] text-emerald-300 block font-semibold">คาร์บอนสะสม</span>
              <span className="text-sm font-black text-white">{stats.totalCO2.toFixed(1)}</span>
              <span className="text-[9px] text-emerald-200 block">kg CO₂</span>
            </div>

            {/* Trees Planted */}
            <div className="bg-white/5 border border-white/10 rounded-2xl p-2 backdrop-blur-sm">
              <span className="text-[9px] text-brand-lime block font-semibold">ต้นไม้บนเกาะ</span>
              <span className="text-sm font-black text-brand-lime">{treesFromCO2} ต้น</span>
              <span className="text-[9px] text-emerald-200 block">2.4kg = 1ต้น</span>
            </div>

            {/* Carbon Coins */}
            <div className="bg-white/5 border border-white/10 rounded-2xl p-2 backdrop-blur-sm">
              <span className="text-[9px] text-amber-300 block font-semibold">เหรียญสะสม</span>
              <span className="text-sm font-black text-amber-300">{stats.coins}</span>
              <span className="text-[9px] text-amber-200 block">Carbon Coin</span>
            </div>
          </div>
        </div>
      </div>

      {/* 2. Interactive Main 3D Canvas Container */}
      <div className="relative">
        <CarbonIsland3D 
          stats={stats} 
          currentPet={currentPet} 
          userId={userId}
          onWaterTree={onWaterTree} 
          onDecorationsChange={onDecorationsChange}
        />
      </div>

      {/* 3. Unlocked Decor Inventory Badge List */}
      <div className="bg-white rounded-3xl p-4 shadow-sm border border-slate-100 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-emerald-600" />
            <h3 className="text-xs font-black text-slate-800">
              ของตกแต่งที่เปิดใช้งานบนเกาะ (Level {stats.level})
            </h3>
          </div>
          <button
            onClick={() => setShowRoadmapModal(true)}
            className="text-[10px] text-emerald-600 font-extrabold flex items-center gap-0.5 hover:underline"
          >
            <span>ดูทั้งหมด</span>
            <ChevronRight className="w-3 h-3" />
          </button>
        </div>

        <div className="grid grid-cols-2 gap-2 text-xs">
          {/* Base Island */}
          <div className="bg-emerald-50 border border-emerald-200/80 rounded-2xl p-2.5 flex items-center gap-2">
            <span className="text-xl">🌱</span>
            <div className="min-w-0">
              <h5 className="text-xs font-bold text-emerald-950 truncate">ฐานเกาะ & Eco Pet</h5>
              <span className="text-[9px] text-emerald-700 font-medium block">ปลดล็อกแล้ว (Level 1)</span>
            </div>
          </div>

          {/* Wooden Bridge */}
          <div className={`border rounded-2xl p-2.5 flex items-center gap-2 ${
            stats.level >= 2 
              ? 'bg-emerald-50 border-emerald-200 text-emerald-950' 
              : 'bg-slate-50 border-slate-200 text-slate-400 opacity-60'
          }`}>
            <span className="text-xl">🌉</span>
            <div className="min-w-0">
              <h5 className="text-xs font-bold truncate">สะพานไม้ข้ามธาร</h5>
              <span className="text-[9px] block">
                {stats.level >= 2 ? 'ปลดล็อกแล้ว (Level 2)' : 'ปลดล็อกเมื่อ Level 2'}
              </span>
            </div>
          </div>

          {/* Treehouse */}
          <div className={`border rounded-2xl p-2.5 flex items-center gap-2 ${
            stats.level >= 3 
              ? 'bg-emerald-50 border-emerald-200 text-emerald-950' 
              : 'bg-slate-50 border-slate-200 text-slate-400 opacity-60'
          }`}>
            <span className="text-xl">🏡</span>
            <div className="min-w-0">
              <h5 className="text-xs font-bold truncate">บ้านบนต้นไม้ Treehouse</h5>
              <span className="text-[9px] block">
                {stats.level >= 3 ? 'ปลดล็อกแล้ว (Level 3)' : 'ปลดล็อกเมื่อ Level 3'}
              </span>
            </div>
          </div>

          {/* Wind Turbine */}
          <div className={`border rounded-2xl p-2.5 flex items-center gap-2 ${
            stats.level >= 4 
              ? 'bg-emerald-50 border-emerald-200 text-emerald-950' 
              : 'bg-slate-50 border-slate-200 text-slate-400 opacity-60'
          }`}>
            <span className="text-xl">💨</span>
            <div className="min-w-0">
              <h5 className="text-xs font-bold truncate">กังหันลมพลังสะอาด</h5>
              <span className="text-[9px] block">
                {stats.level >= 4 ? 'ปลดล็อกแล้ว (Level 4)' : 'ปลดล็อกเมื่อ Level 4'}
              </span>
            </div>
          </div>

          {/* Solar Panels */}
          <div className={`border rounded-2xl p-2.5 flex items-center gap-2 ${
            stats.level >= 5 
              ? 'bg-emerald-50 border-emerald-200 text-emerald-950' 
              : 'bg-slate-50 border-slate-200 text-slate-400 opacity-60'
          }`}>
            <span className="text-xl">☀️</span>
            <div className="min-w-0">
              <h5 className="text-xs font-bold truncate">แผงโซลาร์เซลล์</h5>
              <span className="text-[9px] block">
                {stats.level >= 5 ? 'ปลดล็อกแล้ว (Level 5)' : 'ปลดล็อกเมื่อ Level 5'}
              </span>
            </div>
          </div>

          {/* Waterfall Bench */}
          <div className={`border rounded-2xl p-2.5 flex items-center gap-2 ${
            stats.level >= 6 
              ? 'bg-emerald-50 border-emerald-200 text-emerald-950' 
              : 'bg-slate-50 border-slate-200 text-slate-400 opacity-60'
          }`}>
            <span className="text-xl">🪑</span>
            <div className="min-w-0">
              <h5 className="text-xs font-bold truncate">ม้านั่งธารน้ำตก</h5>
              <span className="text-[9px] block">
                {stats.level >= 6 ? 'ปลดล็อกแล้ว (Level 6)' : 'ปลดล็อกเมื่อ Level 6'}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* 4. Level Roadmap Modal */}
      {showRoadmapModal && (
        <div className="fixed inset-0 bg-slate-900/80 backdrop-blur-md z-50 flex flex-col items-center justify-center p-4 animate-scale-up">
          <div className="bg-white rounded-3xl w-full max-w-md max-h-[85vh] flex flex-col shadow-2xl border-4 border-emerald-500 overflow-hidden">
            
            {/* Modal Header */}
            <div className="bg-gradient-to-r from-emerald-600 to-teal-700 text-white p-4 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2">
                <div className="bg-brand-lime text-emerald-950 p-2 rounded-xl text-xl font-black">
                  🗺️
                </div>
                <div>
                  <h3 className="text-base font-extrabold text-white">แผนผังปลดล็อก Carbon Island 3D</h3>
                  <p className="text-[10px] text-emerald-100">
                    พัฒนาเกาะลอยฟ้าและสะสม XP แบบไม่จำกัด (Unlimited Levels)
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowRoadmapModal(false)}
                className="w-8 h-8 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Current Level Status Banner */}
            <div className="bg-emerald-50 p-3 border-b border-emerald-100 flex items-center justify-between text-xs font-bold text-emerald-950 shrink-0">
              <div className="flex items-center gap-2">
                <Star className="w-4 h-4 text-yellow-500 fill-yellow-500 animate-bounce" />
                <span>ระดับของคุณปัจจุบัน: <strong>Level {stats.level}</strong></span>
              </div>
              <span className="text-[10px] bg-emerald-200 text-emerald-900 px-2 py-0.5 rounded-full font-mono">
                {stats.experience} / {requiredXP} XP
              </span>
            </div>

            {/* Level Unlocks Roadmap List */}
            <div className="p-4 overflow-y-auto space-y-3 flex-1">
              {Array.from({ length: Math.max(10, stats.level + 2) }).map((_, index) => {
                const lvl = index + 1;
                const unlock = getLevelUnlock(lvl);
                const reqXP = getRequiredXP(lvl);
                const isUnlocked = stats.level >= lvl;
                const isCurrent = stats.level === lvl;

                return (
                  <div
                    key={lvl}
                    className={`rounded-2xl p-3.5 border transition-all flex items-center gap-3 relative ${
                      isCurrent
                        ? 'bg-amber-50 border-amber-400 shadow-md ring-2 ring-amber-300'
                        : isUnlocked
                        ? 'bg-emerald-50/70 border-emerald-200'
                        : 'bg-slate-50 border-slate-200 opacity-75'
                    }`}
                  >
                    {/* Icon & Level Badge */}
                    <div className="flex flex-col items-center justify-center shrink-0">
                      <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-2xl border shadow-sm ${
                        isCurrent
                          ? 'bg-amber-200 border-amber-400'
                          : isUnlocked
                          ? 'bg-emerald-200 border-emerald-300'
                          : 'bg-slate-200 border-slate-300 text-slate-400'
                      }`}>
                        {unlock.icon}
                      </div>
                      <span className="text-[10px] font-black text-slate-600 mt-1">
                        Level {lvl}
                      </span>
                    </div>

                    {/* Details */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <h4 className={`text-xs font-extrabold truncate ${
                          isCurrent ? 'text-amber-950' : isUnlocked ? 'text-emerald-950' : 'text-slate-700'
                        }`}>
                          {unlock.unlockedItem}
                        </h4>
                        
                        {isCurrent ? (
                          <span className="text-[9px] font-black bg-amber-400 text-amber-950 px-2 py-0.2 rounded-md animate-pulse">
                            กำลังสะสม ⭐
                          </span>
                        ) : isUnlocked ? (
                          <span className="text-[9px] font-extrabold text-emerald-700 bg-emerald-100 px-1.5 py-0.2 rounded-md flex items-center gap-0.5">
                            <CheckCircle2 className="w-2.5 h-2.5 text-emerald-600" />
                            ปลดล็อกแล้ว
                          </span>
                        ) : (
                          <span className="text-[9px] font-bold text-slate-500 bg-slate-200 px-1.5 py-0.2 rounded-md flex items-center gap-0.5">
                            <Lock className="w-2.5 h-2.5 text-slate-400" />
                            {reqXP} XP
                          </span>
                        )}
                      </div>

                      <p className="text-[10px] text-slate-500 mt-0.5 leading-snug">
                        {unlock.description}
                      </p>

                      <div className="text-[9px] font-mono text-slate-400 mt-1">
                        เกณฑ์ XP เพื่อปลดล็อก: {reqXP} XP
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Modal Footer */}
            <div className="p-3 bg-slate-50 border-t border-slate-200 shrink-0">
              <button
                onClick={() => setShowRoadmapModal(false)}
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs py-3 rounded-2xl transition-colors shadow-sm"
              >
                ปิดหน้าต่าง & ชมเกาะ 3D ต่อ 🚀
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
