import React, { useState, useRef, useEffect } from 'react';
import { 
  User, 
  Users, 
  Leaf, 
  Award, 
  Image as ImageIcon, 
  Trophy, 
  Heart, 
  Plus, 
  Sparkles, 
  Camera, 
  Upload, 
  Search, 
  Check, 
  X, 
  Trash2, 
  Eye, 
  Share2, 
  Copy, 
  Edit3, 
  UserPlus, 
  CheckCircle2, 
  Coins, 
  Flame, 
  Smile, 
  MessageCircle,
  Clock,
  Filter,
  ShieldCheck,
  ChevronRight,
  LogOut,
  ChevronDown,
  FileSpreadsheet,
  Download,
  Database
} from 'lucide-react';
import { ProofPhoto, UserStats, Friend, FriendRequest } from '../types';
import { getRequiredXP } from '../utils/levelUtils';
import { updateUserProfileInFirestore } from '../services/firebaseService';

interface ProfileViewProps {
  stats: UserStats;
  album: ProofPhoto[];
  onAddFriend?: (name: string) => void;
  onClearAlbum: () => void;
  onGoToLogin?: () => void;
  userId?: string | null;
  onOpenExcelDatabase?: () => void;
}

// Pre-defined Preset Cute Cartoon Avatars grouped by theme
const PRESET_AVATARS = [
  {
    category: 'สัตว์น้อยน่ารัก 🐾',
    items: [
      { emoji: '🦊', label: 'จิ้งจอกสายกรีน' },
      { emoji: '🐼', label: 'แพนด้ากินไผ่' },
      { emoji: '🦁', label: 'สิงโตเจ้าป่า' },
      { emoji: '🐰', label: 'กระต่ายน้อยป่าไม้' },
      { emoji: '🐱', label: 'แมวส้มโซล่าร์' },
      { emoji: '🐻', label: 'หมีขั้วโลก' },
      { emoji: '🐧', label: 'เพนกวินลดโลกร้อน' },
      { emoji: '🐨', label: 'โคอาล่ารักษ์ป่า' },
      { emoji: '🐬', label: 'โลมาทะเลสดใส' },
      { emoji: '🐹', label: 'แฮมสเตอร์ประหยัดไฟ' },
    ]
  },
  {
    category: 'ต้นไม้ & ธรรมชาติ 🌱',
    items: [
      { emoji: '🌱', label: 'ต้นกล้าแรกแย้ม' },
      { emoji: '🌳', label: 'ต้นไม้ใหญ่ร่มรื่น' },
      { emoji: '🌴', label: 'ต้นมะพร้าวชายหาด' },
      { emoji: '🌵', label: 'กระบองเพชรทนแล้ง' },
      { emoji: '🌻', label: 'ทานตะวันรับแสง' },
      { emoji: '🍄', label: 'เห็ดป่าสีสด' },
      { emoji: '🌺', label: 'ดอกชบาแดง' },
      { emoji: '🍀', label: 'คลอเวอร์โชคดี' },
    ]
  },
  {
    category: 'ตัวละคร & ฮีโร่รักษ์โลก 🦸‍♂️',
    items: [
      { emoji: '🧑‍🌾', label: 'เกษตรกรอินทรีย์' },
      { emoji: '🦸‍♀️', label: 'ฮีโร่สายกรีน' },
      { emoji: '🧙‍♂️', label: 'พ่อมดคุ้มครองป่า' },
      { emoji: '🤖', label: 'หุ่นยนต์แสงอาทิตย์' },
      { emoji: '🛸', label: 'ยานอวกาศอีโค่' },
      { emoji: '🧑‍🚀', label: 'นักบินอวกาศกรีน' },
      { emoji: '👩‍🔬', label: 'นักวิจัยสิ่งแวดล้อม' },
    ]
  }
];

// Initial default Friends for rich immediate interaction
const INITIAL_FRIENDS: Friend[] = [
  {
    id: 'f1',
    name: 'คุณวินน์ หอสตรี',
    userIdCode: 'KARB-1001',
    avatar: '🦊',
    avatarType: 'emoji',
    level: 5,
    totalCO2: 14.8,
    completedActions: 18,
    status: 'online',
    joinedDate: '3 ส.ค. 2026'
  },
  {
    id: 'f2',
    name: 'น้องนุ่น ทันตะปีสาม',
    userIdCode: 'KARB-1002',
    avatar: '🐼',
    avatarType: 'emoji',
    level: 4,
    totalCO2: 11.2,
    completedActions: 14,
    status: 'online',
    joinedDate: '1 ส.ค. 2026'
  },
  {
    id: 'f3',
    name: 'พี่โชเฟอร์บัสส้ม',
    userIdCode: 'KARB-1003',
    avatar: '🦁',
    avatarType: 'emoji',
    level: 3,
    totalCO2: 8.5,
    completedActions: 9,
    status: 'offline',
    joinedDate: '28 ก.ค. 2026'
  }
];

// Searchable directory of existing users to send requests
const ALL_SEARCHABLE_USERS: Omit<Friend, 'status' | 'joinedDate'>[] = [
  { id: 'u101', name: 'น้องมายด์ สายกรีน', userIdCode: 'KARB-1004', avatar: '🐰', avatarType: 'emoji', level: 6, totalCO2: 19.4, completedActions: 25 },
  { id: 'u102', name: 'ลุงสมชาย รีไซเคิล', userIdCode: 'KARB-1005', avatar: '🌳', avatarType: 'emoji', level: 7, totalCO2: 26.0, completedActions: 32 },
  { id: 'u103', name: 'ครูเพ็ญศรี พกแก้วเก็บเย็น', userIdCode: 'KARB-1006', avatar: '🌻', avatarType: 'emoji', level: 3, totalCO2: 7.4, completedActions: 8 },
  { id: 'u104', name: 'หมอต้อม จักรยานรักษ์เมือง', userIdCode: 'KARB-1007', avatar: '🦸‍♀️', avatarType: 'emoji', level: 5, totalCO2: 16.1, completedActions: 21 },
  { id: 'u105', name: 'น้องโฟกัส ปิดไฟทุกห้อง', userIdCode: 'KARB-1008', avatar: '🤖', avatarType: 'emoji', level: 2, totalCO2: 4.8, completedActions: 5 },
];

const INITIAL_REQUESTS: FriendRequest[] = [
  {
    id: 'req1',
    fromName: 'พี่ต้นไม้ ใหญ่มาก',
    fromUserIdCode: 'KARB-2001',
    fromAvatar: '🌳',
    fromLevel: 4,
    timestamp: 'เมื่อ 20 นาทีที่แล้ว'
  }
];

export default function ProfileView({
  stats,
  album,
  onAddFriend,
  onClearAlbum,
  onGoToLogin,
  userId,
  onOpenExcelDatabase
}: ProfileViewProps) {
  // User Profile States
  const [displayName, setDisplayName] = useState<string>(() => {
    return localStorage.getItem('karb_user_name') || stats.displayName || 'นักผจญภัยรักษ์ขอบฟ้า';
  });
  
  const [avatar, setAvatar] = useState<string>(() => {
    return localStorage.getItem('karb_user_avatar') || stats.avatarUrl || '🌱';
  });
  
  const [avatarType, setAvatarType] = useState<'emoji' | 'url'>(() => {
    const savedType = localStorage.getItem('karb_user_avatar_type');
    if (savedType === 'url') return 'url';
    const savedAv = localStorage.getItem('karb_user_avatar') || stats.avatarUrl;
    return (savedAv && (savedAv.startsWith('http') || savedAv.startsWith('data:'))) ? 'url' : 'emoji';
  });

  const [userIdCode] = useState<string>(() => {
    return stats.userIdCode || 'KARB-81203';
  });

  // UI Modals
  const [showAvatarPickerModal, setShowAvatarPickerModal] = useState(false);
  const [isEditingName, setIsEditingName] = useState(false);
  const [tempName, setTempName] = useState(displayName);
  const [copiedIdToast, setCopiedIdToast] = useState(false);
  
  // Friends System States
  const [friends, setFriends] = useState<Friend[]>(() => {
    const saved = localStorage.getItem('karb_friends_list');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { /* fallback */ }
    }
    return INITIAL_FRIENDS;
  });

  const [friendRequests, setFriendRequests] = useState<FriendRequest[]>(() => {
    const saved = localStorage.getItem('karb_friend_reqs');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { /* fallback */ }
    }
    return INITIAL_REQUESTS;
  });

  const [friendsSubTab, setFriendsSubTab] = useState<'list' | 'search' | 'requests'>('list');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFriendDetail, setSelectedFriendDetail] = useState<Friend | null>(null);
  const [sentRequestIds, setSentRequestIds] = useState<string[]>([]);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // My Gallery States
  const [galleryCategory, setGalleryCategory] = useState<string>('all');
  const [gallerySearchQuery, setGallerySearchQuery] = useState('');
  const [activePhotoDetail, setActivePhotoDetail] = useState<ProofPhoto | null>(null);

  // Hidden File input ref for phone gallery upload
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Save changes to localStorage & Firebase
  const handleSaveAvatar = (newAvatar: string, type: 'emoji' | 'url') => {
    setAvatar(newAvatar);
    setAvatarType(type);
    localStorage.setItem('karb_user_avatar', newAvatar);
    localStorage.setItem('karb_user_avatar_type', type);
    setShowAvatarPickerModal(false);
    
    if (userId) {
      updateUserProfileInFirestore(userId, displayName, newAvatar);
    }
    triggerToast('บันทึกรูปโปรไฟล์ใหม่เรียบร้อยแล้ว! ✨');
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          handleSaveAvatar(reader.result, 'url');
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveDisplayName = () => {
    if (!tempName.trim()) return;
    setDisplayName(tempName.trim());
    localStorage.setItem('karb_user_name', tempName.trim());
    setIsEditingName(false);
    
    if (userId) {
      updateUserProfileInFirestore(userId, tempName.trim(), avatar);
    }
    triggerToast('อัปเดตชื่อโปรไฟล์เรียบร้อยแล้ว!');
  };

  // Toast Helper
  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 2800);
  };

  // Copy User ID
  const handleCopyUserId = () => {
    navigator.clipboard.writeText(`#${userIdCode}`);
    setCopiedIdToast(true);
    setTimeout(() => setCopiedIdToast(false), 2000);
  };

  // Save Friends list to localStorage
  useEffect(() => {
    localStorage.setItem('karb_friends_list', JSON.stringify(friends));
  }, [friends]);

  useEffect(() => {
    localStorage.setItem('karb_friend_reqs', JSON.stringify(friendRequests));
  }, [friendRequests]);

  // Friend Actions
  const handleAcceptRequest = (req: FriendRequest) => {
    const newFriend: Friend = {
      id: `f_${Date.now()}`,
      name: req.fromName,
      userIdCode: req.fromUserIdCode,
      avatar: req.fromAvatar,
      avatarType: 'emoji',
      level: req.fromLevel,
      totalCO2: parseFloat((Math.random() * 10 + 2).toFixed(1)),
      completedActions: Math.floor(Math.random() * 12 + 3),
      status: 'online',
      joinedDate: 'วันนี้'
    };

    setFriends(prev => [newFriend, ...prev]);
    setFriendRequests(prev => prev.filter(r => r.id !== req.id));
    triggerToast(`ยอมรับคำขอเป็นเพื่อนจาก ${req.fromName} แล้ว! 🎉`);
  };

  const handleRejectRequest = (reqId: string) => {
    setFriendRequests(prev => prev.filter(r => r.id !== reqId));
    triggerToast('ปฏิเสธคำขอเป็นเพื่อนเรียบร้อย');
  };

  const handleSendFriendRequest = (targetUser: Omit<Friend, 'status' | 'joinedDate'>) => {
    if (friends.some(f => f.userIdCode === targetUser.userIdCode)) {
      triggerToast('คุณและผู้ใช้นี้เป็นเพื่อนกันอยู่แล้ว');
      return;
    }
    setSentRequestIds(prev => [...prev, targetUser.id]);
    if (onAddFriend) {
      onAddFriend(targetUser.name);
    }
    triggerToast(`ส่งคำขอเป็นเพื่อนไปยัง ${targetUser.name} แล้ว! 📩`);
  };

  const handleRemoveFriend = (friendId: string, friendName: string) => {
    setFriends(prev => prev.filter(f => f.id !== friendId));
    setSelectedFriendDetail(null);
    triggerToast(`ลบ ${friendName} ออกจากรายชื่อเพื่อนแล้ว`);
  };

  const handleSendCoinToFriend = (friendName: string) => {
    triggerToast(`ส่ง 🪙 5 Carbon Coins ให้คุณ ${friendName} แล้ว! 💚`);
  };

  // Calculation metrics
  const requiredXP = getRequiredXP(stats.level);
  const xpPercent = Math.min(100, Math.floor((stats.experience / requiredXP) * 100));
  const totalCompletedActions = album.length > 0 ? album.length : (stats.completedActionsCount || 12);

  // Gallery filtering
  const filteredAlbum = album.filter(photo => {
    const matchesSearch = photo.actionNameTh.toLowerCase().includes(gallerySearchQuery.toLowerCase()) ||
                          photo.caption.toLowerCase().includes(gallerySearchQuery.toLowerCase());
    
    if (galleryCategory === 'all') return matchesSearch;
    if (galleryCategory === 'food') return matchesSearch && (photo.actionId.includes('plate') || photo.actionId.includes('food') || photo.actionNameTh.includes('อาหาร'));
    if (galleryCategory === 'transport') return matchesSearch && (photo.actionId.includes('walk') || photo.actionId.includes('bike') || photo.actionNameTh.includes('เดิน') || photo.actionNameTh.includes('ปั่น'));
    if (galleryCategory === 'reusable') return matchesSearch && (photo.actionId.includes('cup') || photo.actionId.includes('bag') || photo.actionNameTh.includes('แก้ว') || photo.actionNameTh.includes('ถุง'));
    if (galleryCategory === 'appliance') return matchesSearch && (photo.actionId.includes('light') || photo.actionId.includes('ac') || photo.actionNameTh.includes('ไฟ') || photo.actionNameTh.includes('แอร์'));
    return matchesSearch;
  });

  return (
    <div className="space-y-5 pb-6">
      
      {/* Toast Floating Alert */}
      {toastMessage && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 bg-slate-900/90 text-white font-bold text-xs px-4 py-2.5 rounded-2xl shadow-xl backdrop-blur-md flex items-center gap-2 animate-bounce">
          <Sparkles className="w-4 h-4 text-brand-lime" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* HiddenFileInput for Album Image Upload */}
      <input 
        type="file" 
        ref={fileInputRef} 
        onChange={handleFileUpload} 
        accept="image/*" 
        className="hidden" 
      />

      {/* ========================================================================= */}
      {/* 1. USER PROFILE HEADER CARD (การ์ดแสดงข้อมูลส่วนตัวผู้ใช้) */}
      {/* ========================================================================= */}
      <div className="bg-gradient-to-br from-white via-emerald-50/50 to-sky-50/60 rounded-3xl p-5 border border-emerald-200/80 shadow-sm relative overflow-hidden">
        
        {/* Decorative background glows */}
        <div className="absolute top-0 right-0 w-36 h-36 bg-emerald-400/10 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-36 h-36 bg-sky-400/15 rounded-full blur-2xl pointer-events-none" />

        <div className="flex flex-col sm:flex-row items-center gap-4 relative z-10">
          
          {/* Profile Avatar Container with Change Button */}
          <div className="relative group shrink-0">
            <div className="w-24 h-24 rounded-3xl bg-gradient-to-tr from-emerald-500 via-teal-400 to-sky-400 p-1 shadow-md">
              <div className="w-full h-full rounded-[22px] bg-white flex items-center justify-center overflow-hidden relative">
                {avatarType === 'url' ? (
                  <img 
                    src={avatar} 
                    alt="User Profile Avatar" 
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <span className="text-5xl select-none">{avatar}</span>
                )}
              </div>
            </div>

            {/* Change Profile Picture Button */}
            <button
              onClick={() => setShowAvatarPickerModal(true)}
              className="absolute -bottom-1 -right-1 bg-emerald-600 hover:bg-emerald-700 text-white p-2 rounded-2xl shadow-md transition-transform active:scale-95 flex items-center justify-center border-2 border-white"
              title="เปลี่ยนรูปโปรไฟล์"
            >
              <Camera className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* User Information & Level Progress */}
          <div className="flex-1 min-w-0 text-center sm:text-left space-y-2">
            
            {/* Display Name Row */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                {isEditingName ? (
                  <div className="flex items-center gap-1.5">
                    <input
                      type="text"
                      value={tempName}
                      onChange={(e) => setTempName(e.target.value)}
                      className="bg-white border border-emerald-300 rounded-xl px-2.5 py-1 text-xs font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-400"
                      maxLength={24}
                    />
                    <button
                      onClick={handleSaveDisplayName}
                      className="p-1 bg-emerald-600 text-white rounded-lg text-xs hover:bg-emerald-700"
                    >
                      <Check className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => setIsEditingName(false)}
                      className="p-1 bg-slate-200 text-slate-600 rounded-lg text-xs hover:bg-slate-300"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <h2 className="text-base font-black text-slate-900 truncate">
                      {displayName}
                    </h2>
                    <button
                      onClick={() => { setTempName(displayName); setIsEditingName(true); }}
                      className="p-1 text-slate-400 hover:text-emerald-700 transition"
                      title="แก้ไขชื่อผู้ใช้"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}
              </div>

              {/* Login / Switch Account Button */}
              {onGoToLogin && (
                <button
                  onClick={onGoToLogin}
                  className="px-2.5 py-1 bg-white hover:bg-emerald-50 text-slate-700 hover:text-emerald-800 border border-slate-200 rounded-xl text-[11px] font-bold transition flex items-center gap-1.5 shadow-xs"
                >
                  <LogOut className="w-3 h-3 text-emerald-600" />
                  <span>บัญชี KARB</span>
                </button>
              )}
            </div>

            {/* User ID & Badges */}
            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
              <button
                onClick={handleCopyUserId}
                className="bg-white/80 border border-slate-200 rounded-lg px-2 py-0.5 text-[10px] font-mono text-slate-600 hover:text-emerald-700 flex items-center gap-1 shadow-2xs transition"
                title="คลิกเพื่อคัดลอก User ID"
              >
                <span>ID: #{userIdCode}</span>
                {copiedIdToast ? (
                  <Check className="w-2.5 h-2.5 text-emerald-600" />
                ) : (
                  <Copy className="w-2.5 h-2.5 text-slate-400" />
                )}
              </button>

              <span className="bg-emerald-100 text-emerald-900 border border-emerald-200 text-[10px] font-black px-2 py-0.5 rounded-full flex items-center gap-1">
                <ShieldCheck className="w-3 h-3 text-emerald-600" />
                สมาชิก KARB รักษ์โลก
              </span>
            </div>

            {/* Level & XP Progress Bar */}
            <div className="bg-white/90 border border-emerald-100/90 rounded-2xl p-2.5 space-y-1.5 shadow-2xs">
              <div className="flex justify-between items-center text-xs">
                <div className="flex items-center gap-1.5">
                  <span className="w-5 h-5 rounded-lg bg-emerald-600 text-white font-black text-[10px] flex items-center justify-center">
                    {stats.level}
                  </span>
                  <span className="font-extrabold text-slate-800 text-[11px]">
                    ระดับ {stats.level} (นักผจญภัยกรีน)
                  </span>
                </div>
                <span className="text-[10px] font-mono font-bold text-slate-500">
                  {stats.experience} / {requiredXP} XP ({xpPercent}%)
                </span>
              </div>

              {/* Progress track */}
              <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden p-0.5">
                <div 
                  className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 rounded-full transition-all duration-500 shadow-sm"
                  style={{ width: `${xpPercent}%` }}
                />
              </div>
            </div>

          </div>

        </div>

        {/* Change Avatar Action Bar */}
        <div className="mt-4 pt-3 border-t border-emerald-100/60 flex items-center justify-between text-xs">
          <span className="text-[11px] text-slate-500">
            ปรับเปลี่ยนรูปโปรไฟล์ของคุณได้ตลอดเวลา
          </span>
          <button
            onClick={() => setShowAvatarPickerModal(true)}
            className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-xs transition flex items-center gap-1.5 active:scale-95"
          >
            <Smile className="w-3.5 h-3.5" />
            <span>เลือกรูป / อวตาร์โปรไฟล์</span>
          </button>
        </div>

      </div>

      {/* ========================================================================= */}
      {/* 2. CORE STATISTICS CARDS GRID (การ์ดแสดงสถิติผู้ใช้) */}
      {/* ========================================================================= */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        
        {/* Card 1: Total Saved CO2 */}
        <div className="bg-white rounded-2xl p-3.5 border border-emerald-100 shadow-xs hover:shadow-md transition relative overflow-hidden group">
          <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center text-base mb-2 font-black">
            🌿
          </div>
          <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
            ลด CO₂ สะสม
          </span>
          <div className="flex items-baseline gap-1 mt-0.5">
            <span className="text-xl font-black text-slate-900">{stats.totalCO2.toFixed(1)}</span>
            <span className="text-xs font-bold text-emerald-700">kg</span>
          </div>
          <span className="text-[9px] text-slate-400 mt-1 block">
            เท่ากับปลูก {(stats.totalCO2 / 2.4).toFixed(1)} ต้น
          </span>
        </div>

        {/* Card 2: Completed Activities */}
        <div className="bg-white rounded-2xl p-3.5 border border-sky-100 shadow-xs hover:shadow-md transition relative overflow-hidden group">
          <div className="w-8 h-8 rounded-xl bg-sky-100 text-sky-800 flex items-center justify-center text-base mb-2 font-black">
            🏆
          </div>
          <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
            ภารกิจสำเร็จ
          </span>
          <div className="flex items-baseline gap-1 mt-0.5">
            <span className="text-xl font-black text-slate-900">{totalCompletedActions}</span>
            <span className="text-xs font-bold text-sky-700">ครั้ง</span>
          </div>
          <span className="text-[9px] text-slate-400 mt-1 block">
            กิจกรรมยืนยันความดี
          </span>
        </div>

        {/* Card 3: Friends Count */}
        <div className="bg-white rounded-2xl p-3.5 border border-teal-100 shadow-xs hover:shadow-md transition relative overflow-hidden group">
          <div className="w-8 h-8 rounded-xl bg-teal-100 text-teal-800 flex items-center justify-center text-base mb-2 font-black">
            👥
          </div>
          <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
            เพื่อนรักษ์โลก
          </span>
          <div className="flex items-baseline gap-1 mt-0.5">
            <span className="text-xl font-black text-slate-900">{friends.length}</span>
            <span className="text-xs font-bold text-teal-700">คน</span>
          </div>
          <span className="text-[9px] text-slate-400 mt-1 block">
            เครือข่ายสังคมสีเขียว
          </span>
        </div>

        {/* Card 4: Carbon Coins */}
        <div className="bg-white rounded-2xl p-3.5 border border-amber-100 shadow-xs hover:shadow-md transition relative overflow-hidden group">
          <div className="w-8 h-8 rounded-xl bg-amber-100 text-amber-900 flex items-center justify-center text-base mb-2 font-black">
            🪙
          </div>
          <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
            Carbon Coin
          </span>
          <div className="flex items-baseline gap-1 mt-0.5">
            <span className="text-xl font-black text-slate-900">{stats.coins}</span>
            <span className="text-xs font-bold text-amber-700">เหรียญ</span>
          </div>
          <span className="text-[9px] text-slate-400 mt-1 block">
            ใช้แลกรางวัลพันธมิตร
          </span>
        </div>

      </div>

      {/* ========================================================================= */}
      {/* 3. FRIENDS SYSTEM (ระบบเพื่อนใช้งานได้จริง) */}
      {/* ========================================================================= */}
      <div className="bg-white rounded-3xl p-5 border border-slate-200/80 shadow-xs space-y-4">
        
        {/* Friends Section Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center">
              <Users className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-black text-slate-900 flex items-center gap-1.5">
                <span>เพื่อนรักษ์โลก (Friends Network)</span>
                <span className="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2 py-0.5 rounded-full">
                  {friends.length} คน
                </span>
              </h3>
              <p className="text-[11px] text-slate-500">
                ค้นหา เพิ่มเพื่อน และติดตามพลังการลดคาร์บอนของกลุ่มเพื่อน
              </p>
            </div>
          </div>

          {/* Friends Navigation Sub-tabs */}
          <div className="flex bg-slate-100 p-1 rounded-2xl text-[11px] font-bold w-full sm:w-auto">
            <button
              onClick={() => setFriendsSubTab('list')}
              className={`flex-1 sm:flex-initial px-3 py-1 rounded-xl transition ${
                friendsSubTab === 'list'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              รายชื่อเพื่อน ({friends.length})
            </button>

            <button
              onClick={() => setFriendsSubTab('search')}
              className={`flex-1 sm:flex-initial px-3 py-1 rounded-xl transition ${
                friendsSubTab === 'search'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              ค้นหาผู้ใช้ 🔍
            </button>

            <button
              onClick={() => setFriendsSubTab('requests')}
              className={`flex-1 sm:flex-initial px-3 py-1 rounded-xl transition relative ${
                friendsSubTab === 'requests'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <span>คำขอเพื่อน</span>
              {friendRequests.length > 0 && (
                <span className="ml-1 bg-rose-500 text-white text-[9px] font-black px-1.5 py-0.2 rounded-full">
                  {friendRequests.length}
                </span>
              )}
            </button>
          </div>
        </div>

        {/* TAB 1: FRIENDS LIST */}
        {friendsSubTab === 'list' && (
          <div className="space-y-2">
            {friends.map((friend) => (
              <div 
                key={friend.id}
                onClick={() => setSelectedFriendDetail(friend)}
                className="flex items-center justify-between p-3 rounded-2xl border border-slate-100 bg-slate-50/50 hover:bg-emerald-50/50 hover:border-emerald-200 transition cursor-pointer group"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-white border border-slate-200 flex items-center justify-center text-xl shadow-2xs relative">
                    {friend.avatar}
                    <span className={`absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full border-2 border-white ${
                      friend.status === 'online' ? 'bg-emerald-500' : 'bg-slate-300'
                    }`} />
                  </div>

                  <div>
                    <div className="flex items-center gap-1.5">
                      <h4 className="text-xs font-extrabold text-slate-900 group-hover:text-emerald-700">
                        {friend.name}
                      </h4>
                      <span className="text-[9px] font-mono text-slate-400">
                        #{friend.userIdCode}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 text-[10px] text-slate-500 mt-0.5">
                      <span>ระดับ {friend.level}</span>
                      <span>•</span>
                      <span className="text-emerald-700 font-bold">-{friend.totalCO2.toFixed(1)} kg CO₂</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={(e) => { e.stopPropagation(); handleSendCoinToFriend(friend.name); }}
                    className="p-1.5 rounded-xl bg-amber-100 text-amber-900 hover:bg-amber-200 text-xs font-bold transition flex items-center gap-1"
                    title="ส่ง Carbon Coin ให้เพื่อน"
                  >
                    <span>🪙</span>
                    <span className="hidden sm:inline text-[10px]">+5 เหรียญ</span>
                  </button>

                  <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-emerald-600 group-hover:translate-x-0.5 transition" />
                </div>
              </div>
            ))}

            {friends.length === 0 && (
              <div className="py-8 text-center space-y-2">
                <span className="text-3xl">👥</span>
                <p className="text-xs text-slate-500">คุณยังไม่มีเพื่อนในรายชื่อ กดสลับไปที่เมนู <strong>ค้นหาผู้ใช้</strong> เพื่อเพิ่มเพื่อนใหม่ได้เลย!</p>
              </div>
            )}
          </div>
        )}

        {/* TAB 2: SEARCH & ADD FRIENDS */}
        {friendsSubTab === 'search' && (
          <div className="space-y-3">
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="ค้นหาตามชื่อผู้ใช้ หรือ User ID (เช่น KARB-1004)..."
                className="w-full bg-slate-50 border border-slate-200 rounded-2xl pl-9 pr-4 py-2 text-xs focus:ring-2 focus:ring-emerald-400 focus:outline-none"
              />
            </div>

            <div className="space-y-2 max-h-60 overflow-y-auto">
              {ALL_SEARCHABLE_USERS
                .filter(user => 
                  user.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                  user.userIdCode.toLowerCase().includes(searchQuery.toLowerCase())
                )
                .map((targetUser) => {
                  const isAlreadyFriend = friends.some(f => f.userIdCode === targetUser.userIdCode);
                  const isRequested = sentRequestIds.includes(targetUser.id);

                  return (
                    <div 
                      key={targetUser.id}
                      className="flex items-center justify-between p-3 rounded-2xl border border-slate-100 bg-white shadow-2xs"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-center justify-center text-xl">
                          {targetUser.avatar}
                        </div>
                        <div>
                          <div className="flex items-center gap-1.5">
                            <h4 className="text-xs font-bold text-slate-900">{targetUser.name}</h4>
                            <span className="text-[9px] font-mono text-slate-400">#{targetUser.userIdCode}</span>
                          </div>
                          <span className="text-[10px] text-slate-500 block">
                            ระดับ {targetUser.level} • ลด CO₂ แล้ว {targetUser.totalCO2} kg
                          </span>
                        </div>
                      </div>

                      {isAlreadyFriend ? (
                        <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-xl border border-emerald-200 flex items-center gap-1">
                          <Check className="w-3 h-3 text-emerald-600" /> เป็นเพื่อนแล้ว
                        </span>
                      ) : isRequested ? (
                        <span className="text-[10px] font-bold text-amber-700 bg-amber-50 px-2.5 py-1 rounded-xl border border-amber-200">
                          ส่งคำขอแล้ว 📩
                        </span>
                      ) : (
                        <button
                          onClick={() => handleSendFriendRequest(targetUser)}
                          className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs px-3 py-1.5 rounded-xl transition flex items-center gap-1 active:scale-95 shadow-2xs"
                        >
                          <UserPlus className="w-3.5 h-3.5" />
                          <span>+ เพิ่มเพื่อน</span>
                        </button>
                      )}
                    </div>
                  );
                })}
            </div>
          </div>
        )}

        {/* TAB 3: FRIEND REQUESTS */}
        {friendsSubTab === 'requests' && (
          <div className="space-y-2">
            {friendRequests.map((req) => (
              <div 
                key={req.id}
                className="flex items-center justify-between p-3 rounded-2xl border border-amber-200/80 bg-amber-50/40 shadow-2xs"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-white border border-slate-200 flex items-center justify-center text-xl">
                    {req.fromAvatar}
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-900">{req.fromName}</h4>
                    <span className="text-[10px] text-slate-500 block font-mono">
                      #{req.fromUserIdCode} • ระดับ {req.fromLevel}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => handleAcceptRequest(req)}
                    className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold px-3 py-1.5 rounded-xl shadow-2xs flex items-center gap-1"
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>ตอบรับ</span>
                  </button>
                  <button
                    onClick={() => handleRejectRequest(req.id)}
                    className="bg-slate-200 hover:bg-slate-300 text-slate-700 text-xs font-bold px-2.5 py-1.5 rounded-xl"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}

            {friendRequests.length === 0 && (
              <div className="py-6 text-center text-slate-400 text-xs">
                ไม่มีคำขอเป็นเพื่อนค้างอยู่ในขณะนี้
              </div>
            )}
          </div>
        )}

      </div>

      {/* ========================================================================= */}
      {/* 4. MY GALLERY (อัลบั้มกิจกรรมรูปภาพ) */}
      {/* ========================================================================= */}
      <div className="bg-white rounded-3xl p-5 border border-slate-200/80 shadow-xs space-y-4">
        
        {/* Gallery Section Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-sky-100 text-sky-700 flex items-center justify-center">
              <ImageIcon className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-black text-slate-900 flex items-center gap-1.5">
                <span>My Gallery (อัลบั้มกิจกรรมรักษ์โลก)</span>
                <span className="bg-sky-100 text-sky-800 text-[10px] font-bold px-2 py-0.5 rounded-full">
                  {album.length} รูปภาพ
                </span>
              </h3>
              <p className="text-[11px] text-slate-500">
                ประวัติตราประทับรูปถ่ายยืนยันการลดคาร์บอนจริงของคุณ
              </p>
            </div>
          </div>

          <button
            onClick={onClearAlbum}
            className="text-[10px] font-bold text-rose-500 hover:text-rose-700 bg-rose-50 hover:bg-rose-100 px-2.5 py-1 rounded-xl transition self-end sm:self-center"
          >
            รีเซ็ตอัลบั้มภาพ
          </button>
        </div>

        {/* Gallery Search & Filter Bar */}
        <div className="flex flex-col sm:flex-row gap-2">
          {/* Category Pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-[11px] font-bold">
            <button
              onClick={() => setGalleryCategory('all')}
              className={`px-3 py-1 rounded-xl whitespace-nowrap transition ${
                galleryCategory === 'all'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              ทั้งหมด ({album.length})
            </button>
            <button
              onClick={() => setGalleryCategory('food')}
              className={`px-3 py-1 rounded-xl whitespace-nowrap transition ${
                galleryCategory === 'food'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              🍽️ อาหาร
            </button>
            <button
              onClick={() => setGalleryCategory('transport')}
              className={`px-3 py-1 rounded-xl whitespace-nowrap transition ${
                galleryCategory === 'transport'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              🚲 เดินทาง
            </button>
            <button
              onClick={() => setGalleryCategory('reusable')}
              className={`px-3 py-1 rounded-xl whitespace-nowrap transition ${
                galleryCategory === 'reusable'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              🥤 พกแก้ว/ถุง
            </button>
          </div>

          {/* Quick Filter Search */}
          <div className="relative sm:w-48 shrink-0">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={gallerySearchQuery}
              onChange={(e) => setGallerySearchQuery(e.target.value)}
              placeholder="ค้นหารูป..."
              className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-8 pr-3 py-1 text-xs focus:ring-1 focus:ring-emerald-400 focus:outline-none"
            />
          </div>
        </div>

        {/* Photo Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {filteredAlbum.map((item) => (
            <button
              key={item.id}
              onClick={() => setActivePhotoDetail(item)}
              className="aspect-square bg-slate-100 rounded-2xl overflow-hidden relative group border border-slate-200 shadow-2xs cursor-pointer text-left"
            >
              <img
                src={item.imgUrl}
                alt={item.actionNameTh}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                referrerPolicy="no-referrer"
              />

              {/* Verified Ribbon Overlay */}
              <div className="absolute top-2 left-2 bg-emerald-600/90 backdrop-blur-xs text-white text-[9px] font-black px-2 py-0.5 rounded-full shadow-md flex items-center gap-1">
                <CheckCircle2 className="w-2.5 h-2.5" />
                <span>AI OK</span>
              </div>

              {/* Bottom Caption Overlay */}
              <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-slate-950/80 via-slate-950/40 to-transparent p-2 text-white">
                <p className="text-[10px] font-bold truncate">{item.actionNameTh}</p>
                <span className="text-[9px] text-emerald-300 font-mono block">-{item.co2Saved} kg CO₂</span>
              </div>
            </button>
          ))}

          {filteredAlbum.length === 0 && (
            <div className="col-span-full py-10 text-center text-slate-400 text-xs">
              😭 ไม่พบรูปภาพในอัลบั้มสำหรับเงื่อนไขนี้ ลองถ่ายภาพยืนยันกิจกรรมใน <strong>หน้ากิจกรรม</strong> เพื่อบันทึกรูปใหม่!
            </div>
          )}
        </div>

      </div>

      {/* ========================================================================= */}
      {/* 5. EXCEL DATABASE HUB (ศูนย์จัดการฐานข้อมูล Excel) */}
      {/* ========================================================================= */}
      <div className="bg-gradient-to-br from-emerald-800 via-teal-900 to-slate-900 text-white rounded-3xl p-5 border border-emerald-500/30 shadow-lg space-y-4 relative overflow-hidden">
        
        {/* Decorative Background Accent */}
        <div className="absolute -right-8 -bottom-8 w-32 h-32 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />
        
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-white/10 pb-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 border border-emerald-400/30 flex items-center justify-center text-emerald-300">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-black tracking-tight text-white">
                  ฐานข้อมูล Excel (Excel Database Hub)
                </h3>
                <span className="bg-emerald-500/30 text-emerald-200 text-[10px] font-mono font-bold px-2 py-0.5 rounded-full border border-emerald-400/30">
                  .XLSX
                </span>
              </div>
              <p className="text-[11px] text-emerald-100/80">
                รองรับการทำงานกับ Microsoft Excel, Google Sheets, และ CSV เต็มรูปแบบ
              </p>
            </div>
          </div>

          <button
            onClick={onOpenExcelDatabase}
            className="w-full sm:w-auto px-4 py-2 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs rounded-xl shadow-md transition flex items-center justify-center gap-2 active:scale-95 cursor-pointer"
          >
            <Database className="w-4 h-4" />
            <span>เปิดจัดการฐานข้อมูล Excel</span>
          </button>
        </div>

        {/* Quick Database Stats Pills */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center text-xs">
          <div className="bg-white/10 backdrop-blur-md rounded-xl p-2.5 border border-white/10">
            <span className="text-[10px] text-emerald-200 block font-mono">USERS SHEET</span>
            <span className="text-sm font-black text-white">1 ผู้ใช้</span>
          </div>
          <div className="bg-white/10 backdrop-blur-md rounded-xl p-2.5 border border-white/10">
            <span className="text-[10px] text-emerald-200 block font-mono">ACTIONS SHEET</span>
            <span className="text-sm font-black text-white">11 ภารกิจ</span>
          </div>
          <div className="bg-white/10 backdrop-blur-md rounded-xl p-2.5 border border-white/10">
            <span className="text-[10px] text-emerald-200 block font-mono">LOGS SHEET</span>
            <span className="text-sm font-black text-white">{album.length} ประวัติ</span>
          </div>
          <div className="bg-white/10 backdrop-blur-md rounded-xl p-2.5 border border-white/10">
            <span className="text-[10px] text-emerald-200 block font-mono">FRIENDS SHEET</span>
            <span className="text-sm font-black text-white">{friends.length} เพื่อน</span>
          </div>
        </div>

        <div className="flex items-center justify-between pt-1 text-[11px] text-emerald-200/90">
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>พร้อมส่งออกและนำเข้าข้อมูลได้ทันที</span>
          </span>
          <button
            onClick={onOpenExcelDatabase}
            className="text-white hover:text-emerald-200 underline font-bold flex items-center gap-1"
          >
            <span>ดูตารางสเปรดชีต</span>
            <ChevronRight className="w-3 h-3" />
          </button>
        </div>

      </div>

      {/* ========================================================================= */}
      {/* MODAL 1: CHOOSE PROFILE PICTURE / AVATAR PICKER */}
      {/* ========================================================================= */}
      {showAvatarPickerModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-white rounded-3xl max-w-md w-full border border-slate-200 shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
            
            {/* Modal Header */}
            <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-emerald-50/50">
              <div className="flex items-center gap-2">
                <Smile className="w-5 h-5 text-emerald-600" />
                <h4 className="text-sm font-black text-slate-900">เปลี่ยนรูปโปรไฟล์ของคุณ</h4>
              </div>
              <button
                onClick={() => setShowAvatarPickerModal(false)}
                className="p-1 rounded-xl text-slate-400 hover:text-slate-600 hover:bg-slate-100"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Content Scrollable */}
            <div className="p-4 overflow-y-auto space-y-5">
              
              {/* Option A: Upload from Device Album / Camera */}
              <div className="bg-gradient-to-r from-emerald-500 to-teal-600 text-white rounded-2xl p-4 text-center space-y-2 shadow-xs">
                <h5 className="text-xs font-black">📷 ถ่ายรูปใหม่ หรือ เลือกรูปจากโทรศัพท์</h5>
                <p className="text-[11px] text-emerald-100">
                  อัปโหลดรูปจริงจากกล้องถ่ายรูปหรืออัลบั้มภาพของคุณได้ทันที
                </p>
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="px-4 py-2 bg-white text-emerald-900 font-black text-xs rounded-xl shadow-md hover:bg-emerald-50 transition active:scale-95 inline-flex items-center gap-1.5"
                >
                  <Upload className="w-3.5 h-3.5 text-emerald-600" />
                  <span>เลือกรูปภาพจากเครื่อง</span>
                </button>
              </div>

              {/* Option B: Preset Cartoon Avatars */}
              <div className="space-y-4">
                <h5 className="text-xs font-black text-slate-800 flex items-center gap-1.5">
                  <span>🎨 หรือ เลือกชุดตัวการ์ตูนน่ารัก (Preset Avatars)</span>
                </h5>

                {PRESET_AVATARS.map((group) => (
                  <div key={group.category} className="space-y-2">
                    <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wide block">
                      {group.category}
                    </span>
                    <div className="grid grid-cols-4 sm:grid-cols-5 gap-2">
                      {group.items.map((item) => (
                        <button
                          key={item.emoji}
                          onClick={() => handleSaveAvatar(item.emoji, 'emoji')}
                          className={`aspect-square rounded-2xl border flex flex-col items-center justify-center p-1 transition-all group ${
                            avatar === item.emoji && avatarType === 'emoji'
                              ? 'bg-emerald-100 border-emerald-500 scale-105 shadow-xs'
                              : 'bg-slate-50 border-slate-200/80 hover:bg-emerald-50 hover:border-emerald-300'
                          }`}
                        >
                          <span className="text-3xl select-none group-hover:scale-110 transition-transform">
                            {item.emoji}
                          </span>
                          <span className="text-[8px] font-bold text-slate-600 truncate w-full text-center mt-1">
                            {item.label}
                          </span>
                        </button>
                      ))}
                    </div>
                  </div>
                ))}
              </div>

            </div>

            {/* Modal Footer */}
            <div className="p-3 bg-slate-50 border-t border-slate-100 text-right">
              <button
                onClick={() => setShowAvatarPickerModal(false)}
                className="px-4 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-700 text-xs font-bold rounded-xl"
              >
                ยกเลิก
              </button>
            </div>

          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 2: FRIEND PROFILE VIEW MODAL */}
      {/* ========================================================================= */}
      {selectedFriendDetail && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-white rounded-3xl max-w-sm w-full border border-slate-200 shadow-2xl overflow-hidden p-5 space-y-4">
            
            <div className="flex justify-between items-start">
              <div className="flex items-center gap-3">
                <div className="w-14 h-14 rounded-2xl bg-emerald-100 border border-emerald-300 flex items-center justify-center text-3xl shadow-xs">
                  {selectedFriendDetail.avatar}
                </div>
                <div>
                  <h4 className="text-sm font-black text-slate-900">{selectedFriendDetail.name}</h4>
                  <span className="text-[10px] font-mono text-slate-400">ID: #{selectedFriendDetail.userIdCode}</span>
                  <span className="text-[10px] text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.2 rounded-full block mt-1 w-fit font-bold">
                    ระดับ {selectedFriendDetail.level}
                  </span>
                </div>
              </div>
              <button
                onClick={() => setSelectedFriendDetail(null)}
                className="p-1 text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Friend Stats */}
            <div className="grid grid-cols-2 gap-2 text-center">
              <div className="bg-slate-50 p-2.5 rounded-2xl border border-slate-100">
                <span className="text-xs font-black text-slate-900 block">-{selectedFriendDetail.totalCO2} kg</span>
                <span className="text-[9px] text-slate-500 uppercase">ลด CO₂ รวม</span>
              </div>
              <div className="bg-slate-50 p-2.5 rounded-2xl border border-slate-100">
                <span className="text-xs font-black text-slate-900 block">{selectedFriendDetail.completedActions} ครั้ง</span>
                <span className="text-[9px] text-slate-500 uppercase">ภารกิจสำเร็จ</span>
              </div>
            </div>

            {/* Action buttons */}
            <div className="space-y-2 pt-2">
              <button
                onClick={() => handleSendCoinToFriend(selectedFriendDetail.name)}
                className="w-full py-2 bg-amber-400 hover:bg-amber-500 text-amber-950 font-black text-xs rounded-xl shadow-xs transition flex items-center justify-center gap-1"
              >
                <span>🪙</span>
                <span>ส่ง 5 Carbon Coins ให้เพื่อน</span>
              </button>

              <button
                onClick={() => handleRemoveFriend(selectedFriendDetail.id, selectedFriendDetail.name)}
                className="w-full py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-600 font-bold text-xs rounded-xl transition flex items-center justify-center gap-1"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>ลบออกจากเพื่อน</span>
              </button>
            </div>

          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 3: GALLERY FULLSIZE PHOTO VIEW MODAL */}
      {/* ========================================================================= */}
      {activePhotoDetail && (
        <div className="fixed inset-0 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-white rounded-3xl max-w-sm w-full border border-slate-200 shadow-2xl overflow-hidden">
            
            {/* Header info bar */}
            <div className="p-3.5 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 bg-emerald-500 rounded-xl flex items-center justify-center text-white">
                  <Leaf className="w-3.5 h-3.5" />
                </div>
                <div>
                  <h5 className="text-xs font-black text-slate-800">{activePhotoDetail.actionNameTh}</h5>
                  <span className="text-[9px] text-slate-400 font-mono block">{activePhotoDetail.date}</span>
                </div>
              </div>
              <button
                onClick={() => setActivePhotoDetail(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Photo core image */}
            <div className="aspect-square bg-slate-900 relative">
              <img
                src={activePhotoDetail.imgUrl}
                alt={activePhotoDetail.actionNameTh}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute bottom-3 right-3 bg-emerald-500 text-white text-[10px] font-black px-2.5 py-1 rounded-xl shadow-md border border-white">
                🌱 CO2 DEFENDER OK
              </div>
            </div>

            {/* Photo details */}
            <div className="p-4 space-y-3">
              <div className="p-3 bg-slate-50 border border-slate-100 rounded-2xl">
                <p className="text-xs text-slate-600 italic">
                  "{activePhotoDetail.caption || 'ยืนยันกิจกรรมลดมลพิษเพื่อโลกที่ดีขึ้น'}"
                </p>
              </div>

              <div className="flex items-center justify-between text-xs pt-1 border-t border-slate-100">
                <span className="text-[10px] font-bold text-slate-500">ลด CO₂ ได้:</span>
                <span className="font-extrabold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                  -{activePhotoDetail.co2Saved} kg CO₂
                </span>
              </div>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
