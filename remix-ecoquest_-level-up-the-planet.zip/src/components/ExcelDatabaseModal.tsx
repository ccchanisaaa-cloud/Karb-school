import React, { useState, useRef } from 'react';
import { 
  FileSpreadsheet, 
  Download, 
  Upload, 
  RefreshCw, 
  Database, 
  CheckCircle2, 
  AlertCircle, 
  Search, 
  Plus, 
  Trash2, 
  X, 
  Sparkles, 
  Table, 
  Layers, 
  FileText, 
  HardDrive,
  Users,
  Award,
  Leaf,
  Check,
  Edit2
} from 'lucide-react';
import { 
  DatabaseState, 
  exportDatabaseToExcel, 
  importDatabaseFromExcel, 
  exportTableToCSV 
} from '../services/excelDatabaseService';
import { DailyAction, Friend, PartnerReward, ProofPhoto, UserStats } from '../types';

interface ExcelDatabaseModalProps {
  isOpen: boolean;
  onClose: () => void;
  userStats: UserStats;
  actions: DailyAction[];
  album: ProofPhoto[];
  friends: Friend[];
  rewards: PartnerReward[];
  onUpdateState: (newState: Partial<DatabaseState>) => void;
}

type ActiveSheet = 'USERS' | 'ACTIONS_CATALOG' | 'COMPLETED_LOGS' | 'FRIENDS' | 'STORE_REWARDS';

export default function ExcelDatabaseModal({
  isOpen,
  onClose,
  userStats,
  actions,
  album,
  friends,
  rewards,
  onUpdateState,
}: ExcelDatabaseModalProps) {
  const [activeSheet, setActiveSheet] = useState<ActiveSheet>('USERS');
  const [searchQuery, setSearchQuery] = useState('');
  const [importStatus, setImportStatus] = useState<{ type: 'success' | 'error' | null; message: string }>({
    type: null,
    message: '',
  });
  const [isProcessing, setIsProcessing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const currentDatabaseState: DatabaseState = {
    userStats,
    actions,
    album,
    friends,
    rewards,
  };

  // Handle full Excel export
  const handleExportAll = () => {
    try {
      exportDatabaseToExcel(currentDatabaseState);
      setImportStatus({
        type: 'success',
        message: 'ส่งออกไฟล์ Excel (.xlsx) ครบ 5 ชีตเรียบร้อยแล้ว!',
      });
      setTimeout(() => setImportStatus({ type: null, message: '' }), 4000);
    } catch (err: any) {
      setImportStatus({
        type: 'error',
        message: `ไม่สามารถส่งออกไฟล์ได้: ${err?.message || 'ข้อผิดพลาด'}`,
      });
    }
  };

  // Handle Excel file import
  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsProcessing(true);
    setImportStatus({ type: null, message: '' });

    try {
      const res = await importDatabaseFromExcel(file);
      if (res.success && res.data) {
        onUpdateState(res.data);
        setImportStatus({
          type: 'success',
          message: `${res.message} (ผู้ใช้: ${res.statsSummary?.usersCount || 0}, ภารกิจ: ${res.statsSummary?.actionsCount || 0}, รูปภาพ: ${res.statsSummary?.photosCount || 0}, เพื่อน: ${res.statsSummary?.friendsCount || 0}, รางวัล: ${res.statsSummary?.rewardsCount || 0})`,
        });
      } else {
        setImportStatus({
          type: 'error',
          message: res.message,
        });
      }
    } catch (err: any) {
      setImportStatus({
        type: 'error',
        message: `เกิดข้อผิดพลาดในการนำเข้า: ${err?.message || 'โปรดลองใหม่'}`,
      });
    } finally {
      setIsProcessing(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  // Handle Single Table CSV Export
  const handleExportCurrentCSV = () => {
    if (activeSheet === 'USERS') {
      exportTableToCSV([userStats], 'USERS_TABLE');
    } else if (activeSheet === 'ACTIONS_CATALOG') {
      exportTableToCSV(actions, 'ACTIONS_CATALOG');
    } else if (activeSheet === 'COMPLETED_LOGS') {
      exportTableToCSV(album, 'COMPLETED_LOGS');
    } else if (activeSheet === 'FRIENDS') {
      exportTableToCSV(friends, 'FRIENDS_TABLE');
    } else if (activeSheet === 'STORE_REWARDS') {
      exportTableToCSV(rewards, 'STORE_REWARDS');
    }
    setImportStatus({
      type: 'success',
      message: `ดาวน์โหลดตาราง ${activeSheet} เป็นไฟล์ .CSV สำเร็จ!`,
    });
    setTimeout(() => setImportStatus({ type: null, message: '' }), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-3 sm:p-5 animate-fade-in">
      <div className="bg-white w-full max-w-5xl rounded-3xl shadow-2xl border border-emerald-200/80 flex flex-col max-h-[92vh] overflow-hidden">
        
        {/* Hidden File Input for Excel Import */}
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileChange}
          accept=".xlsx, .xls, .csv"
          className="hidden"
        />

        {/* 1. Header Toolbar */}
        <div className="bg-gradient-to-r from-emerald-700 via-teal-700 to-emerald-800 text-white p-4 sm:p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center border border-white/30 text-white">
              <FileSpreadsheet className="w-6 h-6 text-emerald-200" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base sm:text-lg font-black tracking-tight">
                  ระบบจัดการฐานข้อมูล Excel (Excel Database Manager)
                </h3>
                <span className="bg-emerald-500/40 text-emerald-100 text-[10px] font-mono font-bold px-2 py-0.5 rounded-full border border-emerald-300/30">
                  .XLSX ACTIVE
                </span>
              </div>
              <p className="text-xs text-emerald-100/90">
                แปลงและเชื่อมต่อข้อมูลแอปพลิเคชันทั้งหมดเป็นตาราง Excel แบบ Real-time
              </p>
            </div>
          </div>

          {/* Top Quick Actions */}
          <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
            <button
              onClick={handleExportAll}
              className="px-3.5 py-2 bg-white text-emerald-800 hover:bg-emerald-50 font-black text-xs rounded-xl shadow-md transition flex items-center gap-1.5 active:scale-95 cursor-pointer"
            >
              <Download className="w-4 h-4 text-emerald-600" />
              <span>ดาวน์โหลด Excel (.xlsx)</span>
            </button>

            <button
              onClick={() => fileInputRef.current?.click()}
              disabled={isProcessing}
              className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs rounded-xl shadow-md border border-emerald-400 transition flex items-center gap-1.5 active:scale-95 cursor-pointer disabled:opacity-50"
            >
              <Upload className="w-4 h-4" />
              <span>{isProcessing ? 'กำลังอ่านไฟล์...' : 'นำเข้า Excel (.xlsx)'}</span>
            </button>

            <button
              onClick={onClose}
              className="p-2 text-white/80 hover:text-white hover:bg-white/10 rounded-xl transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Status Alert Banner */}
        {importStatus.message && (
          <div
            className={`px-4 py-2.5 text-xs font-bold flex items-center justify-between border-b ${
              importStatus.type === 'success'
                ? 'bg-emerald-50 text-emerald-900 border-emerald-200'
                : 'bg-rose-50 text-rose-900 border-rose-200'
            }`}
          >
            <div className="flex items-center gap-2">
              {importStatus.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              ) : (
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              )}
              <span>{importStatus.message}</span>
            </div>
            <button
              onClick={() => setImportStatus({ type: null, message: '' })}
              className="text-slate-400 hover:text-slate-700"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* 2. Sheet Tabs & Filter Controls */}
        <div className="bg-slate-100/90 border-b border-slate-200 p-2 sm:px-4 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2 shrink-0">
          
          {/* Multi-Sheet Selector Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0 scrollbar-none">
            <button
              onClick={() => setActiveSheet('USERS')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                activeSheet === 'USERS'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-white text-slate-700 hover:bg-slate-200/80 border border-slate-200'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              <span>ชีต: USERS</span>
              <span className="text-[10px] opacity-80">(1)</span>
            </button>

            <button
              onClick={() => setActiveSheet('ACTIONS_CATALOG')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                activeSheet === 'ACTIONS_CATALOG'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-white text-slate-700 hover:bg-slate-200/80 border border-slate-200'
              }`}
            >
              <Leaf className="w-3.5 h-3.5" />
              <span>ชีต: ACTIONS_CATALOG</span>
              <span className="text-[10px] opacity-80">({actions.length})</span>
            </button>

            <button
              onClick={() => setActiveSheet('COMPLETED_LOGS')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                activeSheet === 'COMPLETED_LOGS'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-white text-slate-700 hover:bg-slate-200/80 border border-slate-200'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              <span>ชีต: COMPLETED_LOGS</span>
              <span className="text-[10px] opacity-80">({album.length})</span>
            </button>

            <button
              onClick={() => setActiveSheet('FRIENDS')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                activeSheet === 'FRIENDS'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-white text-slate-700 hover:bg-slate-200/80 border border-slate-200'
              }`}
            >
              <Table className="w-3.5 h-3.5" />
              <span>ชีต: FRIENDS</span>
              <span className="text-[10px] opacity-80">({friends.length})</span>
            </button>

            <button
              onClick={() => setActiveSheet('STORE_REWARDS')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                activeSheet === 'STORE_REWARDS'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-white text-slate-700 hover:bg-slate-200/80 border border-slate-200'
              }`}
            >
              <Award className="w-3.5 h-3.5" />
              <span>ชีต: STORE_REWARDS</span>
              <span className="text-[10px] opacity-80">({rewards.length})</span>
            </button>
          </div>

          {/* Search Table & Export Single CSV */}
          <div className="flex items-center gap-2">
            <div className="relative flex-1 sm:w-48">
              <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="ค้นหาในชีตนี้..."
                className="w-full bg-white border border-slate-200 rounded-xl pl-8 pr-2.5 py-1 text-xs focus:ring-1 focus:ring-emerald-400 focus:outline-none"
              />
            </div>

            <button
              onClick={handleExportCurrentCSV}
              className="px-2.5 py-1 bg-white hover:bg-slate-50 border border-slate-200 rounded-xl text-[11px] font-bold text-slate-700 hover:text-emerald-700 transition flex items-center gap-1 shadow-2xs cursor-pointer shrink-0"
              title="ส่งออกเฉพาะชีตนี้เป็น CSV"
            >
              <FileSpreadsheet className="w-3 h-3 text-emerald-600" />
              <span>ส่งออก CSV</span>
            </button>
          </div>

        </div>

        {/* 3. Live Spreadsheet Table View Area */}
        <div className="flex-1 overflow-auto p-4 bg-slate-50">
          
          {/* SHEET 1: USERS */}
          {activeSheet === 'USERS' && (
            <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
              <table className="w-full text-left text-xs border-collapse font-sans">
                <thead>
                  <tr className="bg-emerald-50/70 border-b border-slate-200 text-slate-700 font-bold text-[11px]">
                    <th className="p-3 border-r border-slate-200">User ID Code</th>
                    <th className="p-3 border-r border-slate-200">Display Name</th>
                    <th className="p-3 border-r border-slate-200">Avatar</th>
                    <th className="p-3 border-r border-slate-200">Level</th>
                    <th className="p-3 border-r border-slate-200">XP</th>
                    <th className="p-3 border-r border-slate-200">Total CO₂ (kg)</th>
                    <th className="p-3 border-r border-slate-200">Carbon Coins</th>
                    <th className="p-3 border-r border-slate-200">Streak (Days)</th>
                    <th className="p-3">Trees Planted</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-b border-slate-100 hover:bg-emerald-50/30">
                    <td className="p-3 font-mono font-bold text-emerald-700 border-r border-slate-200">
                      #{userStats.userIdCode || 'KARB-81203'}
                    </td>
                    <td className="p-3 font-bold text-slate-900 border-r border-slate-200">
                      {userStats.displayName || 'นักผจญภัยรักษ์ขอบฟ้า'}
                    </td>
                    <td className="p-3 text-center border-r border-slate-200 text-lg">
                      {userStats.avatarUrl || '🌱'}
                    </td>
                    <td className="p-3 font-bold text-slate-800 border-r border-slate-200">
                      {userStats.level}
                    </td>
                    <td className="p-3 font-mono text-slate-600 border-r border-slate-200">
                      {userStats.experience}
                    </td>
                    <td className="p-3 font-bold text-emerald-600 border-r border-slate-200">
                      {userStats.totalCO2.toFixed(1)}
                    </td>
                    <td className="p-3 font-bold text-amber-600 border-r border-slate-200">
                      {userStats.coins}
                    </td>
                    <td className="p-3 text-slate-700 border-r border-slate-200">
                      {userStats.streak}
                    </td>
                    <td className="p-3 font-bold text-emerald-800">
                      {userStats.treesPlanted} ต้น
                    </td>
                  </tr>
                </tbody>
              </table>
              <div className="p-3 bg-slate-50 border-t border-slate-200 text-[11px] text-slate-500 flex justify-between">
                <span>ตาราง USERS: ข้อมูลบัญชีผู้ใช้และค่าสถิติหลัก</span>
                <span className="font-mono text-emerald-700 font-bold">1 แถวในระบบ</span>
              </div>
            </div>
          )}

          {/* SHEET 2: ACTIONS_CATALOG */}
          {activeSheet === 'ACTIONS_CATALOG' && (
            <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
              <table className="w-full text-left text-xs border-collapse font-sans">
                <thead>
                  <tr className="bg-emerald-50/70 border-b border-slate-200 text-slate-700 font-bold text-[11px]">
                    <th className="p-2.5 border-r border-slate-200 w-12 text-center">#</th>
                    <th className="p-2.5 border-r border-slate-200">Action ID</th>
                    <th className="p-2.5 border-r border-slate-200">ชื่อกิจกรรม (ไทย)</th>
                    <th className="p-2.5 border-r border-slate-200">หมวดหมู่</th>
                    <th className="p-2.5 border-r border-slate-200">ลด CO₂ (kg)</th>
                    <th className="p-2.5 border-r border-slate-200">Carbon Coins</th>
                    <th className="p-2.5 border-r border-slate-200">ตรวจรูป (AI)</th>
                    <th className="p-2.5">คำอธิบายภารกิจ</th>
                  </tr>
                </thead>
                <tbody>
                  {actions
                    .filter(a => 
                      a.nameTh.toLowerCase().includes(searchQuery.toLowerCase()) ||
                      a.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
                      a.category.toLowerCase().includes(searchQuery.toLowerCase())
                    )
                    .map((act, index) => (
                      <tr key={act.id} className="border-b border-slate-100 hover:bg-emerald-50/30">
                        <td className="p-2.5 text-center text-slate-400 border-r border-slate-200">{index + 1}</td>
                        <td className="p-2.5 font-mono text-slate-700 border-r border-slate-200">{act.id}</td>
                        <td className="p-2.5 font-bold text-slate-900 border-r border-slate-200">
                          <span className="mr-1.5">{act.emoji || '🌱'}</span>
                          <span>{act.nameTh}</span>
                        </td>
                        <td className="p-2.5 border-r border-slate-200">
                          <span className="bg-slate-100 text-slate-700 px-2 py-0.5 rounded-md text-[10px] font-bold">
                            {act.category}
                          </span>
                        </td>
                        <td className="p-2.5 font-bold text-emerald-600 border-r border-slate-200">
                          -{act.baseCO2} kg
                        </td>
                        <td className="p-2.5 font-bold text-amber-600 border-r border-slate-200">
                          +{act.coinReward} 🪙
                        </td>
                        <td className="p-2.5 border-r border-slate-200 text-center">
                          {act.proofNeeded ? (
                            <span className="bg-emerald-100 text-emerald-800 text-[10px] font-black px-2 py-0.5 rounded-full">
                              YES
                            </span>
                          ) : (
                            <span className="text-slate-400 text-[10px]">NO</span>
                          )}
                        </td>
                        <td className="p-2.5 text-slate-600 text-[11px] truncate max-w-xs">{act.detailsTh}</td>
                      </tr>
                    ))}
                </tbody>
              </table>
              <div className="p-3 bg-slate-50 border-t border-slate-200 text-[11px] text-slate-500 flex justify-between">
                <span>ตาราง ACTIONS_CATALOG: รายการภารกิจรักษ์โลกประจำวัน</span>
                <span className="font-mono text-emerald-700 font-bold">{actions.length} แถว</span>
              </div>
            </div>
          )}

          {/* SHEET 3: COMPLETED_LOGS */}
          {activeSheet === 'COMPLETED_LOGS' && (
            <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
              <table className="w-full text-left text-xs border-collapse font-sans">
                <thead>
                  <tr className="bg-emerald-50/70 border-b border-slate-200 text-slate-700 font-bold text-[11px]">
                    <th className="p-2.5 border-r border-slate-200 w-12 text-center">#</th>
                    <th className="p-2.5 border-r border-slate-200">Photo ID</th>
                    <th className="p-2.5 border-r border-slate-200">วันที่</th>
                    <th className="p-2.5 border-r border-slate-200">ชื่อกิจกรรม</th>
                    <th className="p-2.5 border-r border-slate-200">ลด CO₂</th>
                    <th className="p-2.5 border-r border-slate-200">เหรียญที่ได้</th>
                    <th className="p-2.5 border-r border-slate-200">สถานะ AI</th>
                    <th className="p-2.5">คำบรรยาย (Caption)</th>
                  </tr>
                </thead>
                <tbody>
                  {album
                    .filter(p => 
                      p.actionNameTh.toLowerCase().includes(searchQuery.toLowerCase()) ||
                      p.caption.toLowerCase().includes(searchQuery.toLowerCase())
                    )
                    .map((item, index) => (
                      <tr key={item.id} className="border-b border-slate-100 hover:bg-emerald-50/30">
                        <td className="p-2.5 text-center text-slate-400 border-r border-slate-200">{index + 1}</td>
                        <td className="p-2.5 font-mono text-slate-600 border-r border-slate-200">{item.id}</td>
                        <td className="p-2.5 text-slate-600 border-r border-slate-200 whitespace-nowrap">{item.date}</td>
                        <td className="p-2.5 font-bold text-slate-900 border-r border-slate-200">{item.actionNameTh}</td>
                        <td className="p-2.5 font-bold text-emerald-600 border-r border-slate-200">-{item.co2Saved} kg</td>
                        <td className="p-2.5 font-bold text-amber-600 border-r border-slate-200">+{item.coinsEarned}</td>
                        <td className="p-2.5 border-r border-slate-200 text-center">
                          <span className="bg-emerald-100 text-emerald-800 text-[10px] font-black px-2 py-0.5 rounded-full">
                            VERIFIED
                          </span>
                        </td>
                        <td className="p-2.5 text-slate-600 text-[11px] truncate max-w-sm">{item.caption}</td>
                      </tr>
                    ))}
                  {album.length === 0 && (
                    <tr>
                      <td colSpan={8} className="p-6 text-center text-slate-400">
                        ยังไม่มีประวัติการทำภารกิจในตาราง COMPLETED_LOGS
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
              <div className="p-3 bg-slate-50 border-t border-slate-200 text-[11px] text-slate-500 flex justify-between">
                <span>ตาราง COMPLETED_LOGS: ประวัติหลักฐานภาพถ่ายการทำภารกิจ</span>
                <span className="font-mono text-emerald-700 font-bold">{album.length} แถว</span>
              </div>
            </div>
          )}

          {/* SHEET 4: FRIENDS */}
          {activeSheet === 'FRIENDS' && (
            <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
              <table className="w-full text-left text-xs border-collapse font-sans">
                <thead>
                  <tr className="bg-emerald-50/70 border-b border-slate-200 text-slate-700 font-bold text-[11px]">
                    <th className="p-2.5 border-r border-slate-200 w-12 text-center">#</th>
                    <th className="p-2.5 border-r border-slate-200">User Code</th>
                    <th className="p-2.5 border-r border-slate-200">ชื่อเพื่อน</th>
                    <th className="p-2.5 border-r border-slate-200">Avatar</th>
                    <th className="p-2.5 border-r border-slate-200">ระดับ (Level)</th>
                    <th className="p-2.5 border-r border-slate-200">ลด CO₂ สะสม</th>
                    <th className="p-2.5 border-r border-slate-200">ภารกิจสำเร็จ</th>
                    <th className="p-2.5">สถานะ</th>
                  </tr>
                </thead>
                <tbody>
                  {friends
                    .filter(f => 
                      f.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                      f.userIdCode.toLowerCase().includes(searchQuery.toLowerCase())
                    )
                    .map((friend, index) => (
                      <tr key={friend.id} className="border-b border-slate-100 hover:bg-emerald-50/30">
                        <td className="p-2.5 text-center text-slate-400 border-r border-slate-200">{index + 1}</td>
                        <td className="p-2.5 font-mono text-slate-700 border-r border-slate-200">#{friend.userIdCode}</td>
                        <td className="p-2.5 font-bold text-slate-900 border-r border-slate-200">{friend.name}</td>
                        <td className="p-2.5 text-center border-r border-slate-200 text-base">{friend.avatar}</td>
                        <td className="p-2.5 font-bold text-slate-800 border-r border-slate-200">{friend.level}</td>
                        <td className="p-2.5 font-bold text-emerald-600 border-r border-slate-200">-{friend.totalCO2} kg</td>
                        <td className="p-2.5 text-slate-700 border-r border-slate-200">{friend.completedActions} ครั้ง</td>
                        <td className="p-2.5">
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            friend.status === 'online' ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-600'
                          }`}>
                            {friend.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
              <div className="p-3 bg-slate-50 border-t border-slate-200 text-[11px] text-slate-500 flex justify-between">
                <span>ตาราง FRIENDS: บัญชีและสถิติของเพื่อนในเครือข่าย</span>
                <span className="font-mono text-emerald-700 font-bold">{friends.length} แถว</span>
              </div>
            </div>
          )}

          {/* SHEET 5: STORE_REWARDS */}
          {activeSheet === 'STORE_REWARDS' && (
            <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
              <table className="w-full text-left text-xs border-collapse font-sans">
                <thead>
                  <tr className="bg-emerald-50/70 border-b border-slate-200 text-slate-700 font-bold text-[11px]">
                    <th className="p-2.5 border-r border-slate-200 w-12 text-center">#</th>
                    <th className="p-2.5 border-r border-slate-200">Reward ID</th>
                    <th className="p-2.5 border-r border-slate-200">ชื่อของรางวัล</th>
                    <th className="p-2.5 border-r border-slate-200">พาร์ทเนอร์</th>
                    <th className="p-2.5 border-r border-slate-200">ราคา (Coins)</th>
                    <th className="p-2.5 border-r border-slate-200">รหัส PromoCode</th>
                    <th className="p-2.5">แลกแล้ว (ครั้ง)</th>
                  </tr>
                </thead>
                <tbody>
                  {rewards
                    .filter(r => 
                      r.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                      r.partnerName.toLowerCase().includes(searchQuery.toLowerCase())
                    )
                    .map((item, index) => (
                      <tr key={item.id} className="border-b border-slate-100 hover:bg-emerald-50/30">
                        <td className="p-2.5 text-center text-slate-400 border-r border-slate-200">{index + 1}</td>
                        <td className="p-2.5 font-mono text-slate-600 border-r border-slate-200">{item.id}</td>
                        <td className="p-2.5 font-bold text-slate-900 border-r border-slate-200">{item.title}</td>
                        <td className="p-2.5 text-slate-700 border-r border-slate-200">{item.partnerName}</td>
                        <td className="p-2.5 font-bold text-amber-600 border-r border-slate-200">{item.coinCost} 🪙</td>
                        <td className="p-2.5 font-mono font-bold text-emerald-700 border-r border-slate-200">{item.promoCode}</td>
                        <td className="p-2.5 text-slate-700">{item.redeemedCount}</td>
                      </tr>
                    ))}
                </tbody>
              </table>
              <div className="p-3 bg-slate-50 border-t border-slate-200 text-[11px] text-slate-500 flex justify-between">
                <span>ตาราง STORE_REWARDS: รายการคูปองและรางวัลพาร์ทเนอร์</span>
                <span className="font-mono text-emerald-700 font-bold">{rewards.length} แถว</span>
              </div>
            </div>
          )}

        </div>

        {/* 4. Footer Info Bar */}
        <div className="bg-white border-t border-slate-200 p-3 sm:px-5 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-slate-600 shrink-0">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span className="font-bold text-slate-800">
              สถานะฐานข้อมูล: เชื่อมต่อสมบูรณ์ (Excel Compatibility: 100%)
            </span>
          </div>

          <div className="flex items-center gap-3">
            <span className="text-[11px] text-slate-500 hidden sm:inline">
              รองรับ Microsoft Excel, Google Sheets, LibreOffice Calc และ Apple Numbers
            </span>
            <button
              onClick={onClose}
              className="px-4 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold rounded-xl transition cursor-pointer"
            >
              ปิดหน้าต่าง
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}
