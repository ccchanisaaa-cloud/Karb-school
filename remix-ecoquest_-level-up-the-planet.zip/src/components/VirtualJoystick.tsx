import React, { useEffect, useRef, useState, useCallback } from 'react';
import { 
  Smile, 
  Sparkles, 
  Armchair, 
  Hand, 
  Footprints, 
  Zap, 
  Compass,
  ArrowUp,
  ArrowDown,
  ArrowLeft,
  ArrowRight
} from 'lucide-react';

export interface JoystickVector {
  x: number; // -1 to 1 (Left/Right)
  y: number; // -1 to 1 (Up/Down in 2D, corresponds to -Z / +Z in 3D)
  distance: number; // 0 to 1
  isMoving: boolean;
  isRunning: boolean;
}

interface VirtualJoystickProps {
  onMove: (vector: JoystickVector) => void;
  onAction?: (action: 'wave' | 'cheer' | 'sit' | 'interact') => void;
  onSprintToggle?: (sprinting: boolean) => void;
  nearbyInteraction?: {
    type: 'sit' | 'pet' | 'cafe' | 'water' | 'tree' | null;
    title: string;
  } | null;
  disabled?: boolean;
}

export default function VirtualJoystick({
  onMove,
  onAction,
  onSprintToggle,
  nearbyInteraction,
  disabled = false,
}: VirtualJoystickProps) {
  const joystickBaseRef = useRef<HTMLDivElement>(null);
  const [touchPos, setTouchPos] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isActive, setIsActive] = useState(false);
  const [isSprintLocked, setIsSprintLocked] = useState(false);

  // Keyboard keys state
  const keysDownRef = useRef<{ [key: string]: boolean }>({});

  const maxRadius = 45; // Max drag radius in pixels

  // Process and emit joystick vector
  const emitVector = useCallback((dx: number, dy: number, isSprint = false) => {
    const rawDist = Math.hypot(dx, dy);
    const clampedDist = Math.min(rawDist, maxRadius);
    const normDist = clampedDist / maxRadius;

    if (normDist < 0.12) {
      onMove({ x: 0, y: 0, distance: 0, isMoving: false, isRunning: false });
      return;
    }

    const normX = dx / (rawDist || 1);
    const normY = dy / (rawDist || 1);
    const isRunning = isSprint || normDist > 0.82;

    onMove({
      x: normX * normDist,
      y: normY * normDist,
      distance: normDist,
      isMoving: true,
      isRunning,
    });
  }, [onMove]);

  // Pointer / Touch Handlers
  const handlePointerDown = (e: React.PointerEvent) => {
    if (disabled) return;
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
    setIsActive(true);

    if (!joystickBaseRef.current) return;
    const rect = joystickBaseRef.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;

    const dx = e.clientX - centerX;
    const dy = e.clientY - centerY;
    const dist = Math.hypot(dx, dy);
    const clampedDist = Math.min(dist, maxRadius);
    const angle = Math.atan2(dy, dx);

    const stickX = Math.cos(angle) * clampedDist;
    const stickY = Math.sin(angle) * clampedDist;

    setTouchPos({ x: stickX, y: stickY });
    emitVector(stickX, stickY, isSprintLocked);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isActive || disabled || !joystickBaseRef.current) return;

    const rect = joystickBaseRef.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;

    const dx = e.clientX - centerX;
    const dy = e.clientY - centerY;
    const dist = Math.hypot(dx, dy);
    const clampedDist = Math.min(dist, maxRadius);
    const angle = Math.atan2(dy, dx);

    const stickX = Math.cos(angle) * clampedDist;
    const stickY = Math.sin(angle) * clampedDist;

    setTouchPos({ x: stickX, y: stickY });
    emitVector(stickX, stickY, isSprintLocked);
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    try {
      (e.target as HTMLElement).releasePointerCapture(e.pointerId);
    } catch (_) {}
    setIsActive(false);
    setTouchPos({ x: 0, y: 0 });
    onMove({ x: 0, y: 0, distance: 0, isMoving: false, isRunning: false });
  };

  // Keyboard WASD / Arrow Keys Support
  useEffect(() => {
    if (disabled) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      // Ignore if typing in input field
      if (['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement)?.tagName)) return;

      const key = e.key.toLowerCase();
      if (['w', 'a', 's', 'd', 'arrowup', 'arrowdown', 'arrowleft', 'arrowright', 'shift'].includes(key)) {
        keysDownRef.current[key] = true;
        updateKeyboardMovement();
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      const key = e.key.toLowerCase();
      if (['w', 'a', 's', 'd', 'arrowup', 'arrowdown', 'arrowleft', 'arrowright', 'shift'].includes(key)) {
        keysDownRef.current[key] = false;
        updateKeyboardMovement();
      }
    };

    const updateKeyboardMovement = () => {
      const keys = keysDownRef.current;
      let dx = 0;
      let dy = 0;

      if (keys['w'] || keys['arrowup']) dy -= 1;
      if (keys['s'] || keys['arrowdown']) dy += 1;
      if (keys['a'] || keys['arrowleft']) dx -= 1;
      if (keys['d'] || keys['arrowright']) dx += 1;

      const isRunning = keys['shift'] || isSprintLocked;

      if (dx === 0 && dy === 0) {
        if (!isActive) {
          onMove({ x: 0, y: 0, distance: 0, isMoving: false, isRunning: false });
        }
      } else {
        const length = Math.hypot(dx, dy);
        const normX = dx / length;
        const normY = dy / length;
        onMove({
          x: normX,
          y: normY,
          distance: 1,
          isMoving: true,
          isRunning,
        });
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [disabled, isSprintLocked, onMove, isActive]);

  if (disabled) return null;

  return (
    <div className="flex items-end justify-between w-full pointer-events-none px-2 select-none">
      
      {/* 1. Left: Virtual Joystick Pad */}
      <div className="flex flex-col items-center gap-1.5 pointer-events-auto">
        <div
          ref={joystickBaseRef}
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          onPointerCancel={handlePointerUp}
          className="relative w-28 h-28 rounded-full bg-slate-900/60 backdrop-blur-md border-2 border-emerald-400/40 shadow-xl flex items-center justify-center touch-none cursor-grab active:cursor-grabbing group ring-2 ring-emerald-500/20 active:ring-emerald-400/50 transition-shadow"
          style={{ touchAction: 'none' }}
          title="ลากเพื่อบังคับทิศทางการเดิน (หรือใช้แป้น W A S D / ลูกศร)"
        >
          {/* Subtle Crosshair Guide Lines */}
          <div className="absolute inset-0 flex items-center justify-center opacity-30 pointer-events-none">
            <div className="w-full h-0.5 bg-emerald-300" />
            <div className="h-full w-0.5 bg-emerald-300 absolute" />
          </div>

          {/* Directional Chevron Hints */}
          <div className="absolute top-1 text-emerald-400/60 text-[9px] font-black pointer-events-none">▲</div>
          <div className="absolute bottom-1 text-emerald-400/60 text-[9px] font-black pointer-events-none">▼</div>
          <div className="absolute left-1 text-emerald-400/60 text-[9px] font-black pointer-events-none">◀</div>
          <div className="absolute right-1 text-emerald-400/60 text-[9px] font-black pointer-events-none">▶</div>

          {/* Inner Moveable Thumb Stick */}
          <div
            className={`w-12 h-12 rounded-full bg-gradient-to-tr from-emerald-600 via-emerald-400 to-lime-300 shadow-lg border-2 border-white flex items-center justify-center transition-transform ${
              isActive ? 'scale-110 shadow-emerald-400/50' : 'group-hover:scale-105'
            }`}
            style={{
              transform: `translate(${touchPos.x}px, ${touchPos.y}px)`,
              transition: isActive ? 'none' : 'transform 0.15s ease-out',
            }}
          >
            <Footprints className="w-5 h-5 text-emerald-950" />
          </div>
        </div>

        {/* Small Sprint Toggle button below Joystick */}
        <button
          onClick={() => {
            const next = !isSprintLocked;
            setIsSprintLocked(next);
            if (onSprintToggle) onSprintToggle(next);
          }}
          className={`px-2.5 py-1 rounded-xl text-[10px] font-bold border transition flex items-center gap-1 shadow-md cursor-pointer ${
            isSprintLocked
              ? 'bg-amber-400 text-slate-950 border-amber-300 font-black ring-2 ring-amber-400/40'
              : 'bg-black/50 text-slate-200 border-white/20 hover:bg-black/70'
          }`}
          title="สลับโหมดวิ่งเร็ว / วิ่งต่อเนื่อง (หรือกด Shift บนคีย์บอร์ด)"
        >
          <Zap className={`w-3 h-3 ${isSprintLocked ? 'fill-slate-950' : 'text-amber-400'}`} />
          <span>{isSprintLocked ? 'วิ่งเร็ว (ON)' : 'วิ่ง (OFF)'}</span>
        </button>
      </div>

      {/* 2. Right: Action & Reaction Buttons */}
      <div className="flex flex-col items-end gap-2 pointer-events-auto">
        
        {/* Dynamic Contextual Interaction Button (appears when near bench, pet, cafe, etc.) */}
        {nearbyInteraction && (
          <button
            onClick={() => onAction && onAction('interact')}
            className="px-3.5 py-2 bg-gradient-to-r from-emerald-400 via-teal-400 to-cyan-400 text-slate-950 font-black text-xs rounded-2xl shadow-xl border-2 border-white flex items-center gap-1.5 animate-bounce transition-transform active:scale-95 cursor-pointer"
            title="กดเพื่อทำกิจกรรมกับวัตถุใกล้เคียง"
          >
            <Sparkles className="w-4 h-4 fill-slate-950" />
            <span>{nearbyInteraction.title}</span>
          </button>
        )}

        <div className="flex items-center gap-1.5">
          {/* Sit / Rest Button */}
          <button
            onClick={() => onAction && onAction('sit')}
            className="w-11 h-11 rounded-2xl bg-slate-900/80 hover:bg-slate-800 text-amber-300 border border-amber-400/30 backdrop-blur-md shadow-lg flex flex-col items-center justify-center transition active:scale-90 cursor-pointer"
            title="นั่งพักผ่อน"
          >
            <Armchair className="w-4 h-4" />
            <span className="text-[9px] font-bold mt-0.5">นั่งพัก</span>
          </button>

          {/* Wave / Greet Button */}
          <button
            onClick={() => onAction && onAction('wave')}
            className="w-11 h-11 rounded-2xl bg-slate-900/80 hover:bg-slate-800 text-pink-300 border border-pink-400/30 backdrop-blur-md shadow-lg flex flex-col items-center justify-center transition active:scale-90 cursor-pointer"
            title="โบกมือทักทาย"
          >
            <Hand className="w-4 h-4" />
            <span className="text-[9px] font-bold mt-0.5">โบกมือ</span>
          </button>

          {/* Cheer / Jump Button */}
          <button
            onClick={() => onAction && onAction('cheer')}
            className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-emerald-500 to-lime-400 hover:from-emerald-400 hover:to-lime-300 text-slate-950 border border-white backdrop-blur-md shadow-lg flex flex-col items-center justify-center transition active:scale-90 cursor-pointer font-black"
            title="ดีใจกระโดด"
          >
            <Smile className="w-4 h-4" />
            <span className="text-[9px] font-black mt-0.5">ดีใจ</span>
          </button>
        </div>

      </div>

    </div>
  );
}
