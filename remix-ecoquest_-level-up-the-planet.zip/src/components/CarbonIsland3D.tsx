import React, { useEffect, useRef, useState, useMemo } from 'react';
import * as THREE from 'three';
import { Pet, UserStats, PlacedDecoration, DecorCatalogItem, DecorCategory } from '../types';
import { DECOR_CATALOG, DEFAULT_ISLAND_DECORATIONS } from '../data/islandDecorCatalog';
import { createDecorMesh } from '../utils/island3DModels';
import { saveIslandDecorationsToFirestore } from '../services/firebaseService';
import {
  createExplorerCharacter,
  animateExplorerCharacter,
  checkPositionCollision,
  findNearbyInteractions,
  updateBubbleTexture,
  CharacterControllerState,
  CharacterMeshes
} from '../utils/character3D';
import VirtualJoystick, { JoystickVector } from './VirtualJoystick';
import { 
  Sun, 
  Moon, 
  Sunrise, 
  Sunset, 
  Clock, 
  RefreshCw, 
  Sparkles, 
  Plus, 
  Trash2, 
  RotateCw, 
  RotateCcw, 
  Check, 
  Lock, 
  Layers, 
  Eye, 
  Compass, 
  ArrowUp, 
  ArrowDown, 
  ArrowLeft, 
  ArrowRight,
  ZoomIn,
  ZoomOut,
  HelpCircle,
  Trees,
  CheckCircle2,
  Undo2,
  Footprints,
  Navigation,
  Video,
  Smile,
  Hand,
  Armchair
} from 'lucide-react';

interface CarbonIsland3DProps {
  stats: UserStats;
  currentPet: Pet;
  userId?: string | null;
  onWaterTree?: (index: number) => void;
  onDecorationsChange?: (decorations: PlacedDecoration[]) => void;
}

export default function CarbonIsland3D({ 
  stats, 
  currentPet, 
  userId,
  onWaterTree,
  onDecorationsChange 
}: CarbonIsland3DProps) {
  const mountRef = useRef<HTMLDivElement>(null);

  // Player Level based on stats
  const playerLevel = stats.level || 1;

  // Time of day mode: 'auto' | 'morning' | 'day' | 'sunset' | 'night'
  const [timeMode, setTimeMode] = useState<'auto' | 'morning' | 'day' | 'sunset' | 'night'>('auto');
  const [activePeriod, setActivePeriod] = useState<'morning' | 'day' | 'sunset' | 'night'>('day');

  // Edit Mode state vs Explore Mode
  const [isEditMode, setIsEditMode] = useState<boolean>(false);
  const [selectedDecorId, setSelectedDecorId] = useState<string | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<DecorCategory>('trees');
  const [cameraViewPreset, setCameraViewPreset] = useState<'iso' | 'top' | 'side'>('iso');
  const [isCameraFollow, setIsCameraFollow] = useState<boolean>(true);

  // Nearby interactive object prompt (e.g. sit on bench, pet eco buddy, order cafe)
  const [nearbyInteraction, setNearbyInteraction] = useState<{
    type: 'sit' | 'pet' | 'cafe' | 'water' | 'tree' | null;
    title: string;
    targetPos?: THREE.Vector3;
    rotation?: number;
  } | null>(null);

  // Placement boundary feedback
  const [isBoundaryWarning, setIsBoundaryWarning] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Reset confirmation modal
  const [showResetConfirm, setShowResetConfirm] = useState<boolean>(false);

  // Placed decorations state (initialized from UserStats, LocalStorage, or Default)
  const [decorations, setDecorations] = useState<PlacedDecoration[]>(() => {
    if (stats.islandDecorations && stats.islandDecorations.length > 0) {
      return stats.islandDecorations;
    }
    const saved = localStorage.getItem('karb_island_decorations_v2');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      } catch (e) {
        console.error('Error parsing saved decorations:', e);
      }
    }
    return DEFAULT_ISLAND_DECORATIONS;
  });

  // Character controller states ref (persisted across render frames)
  const charStateRef = useRef<CharacterControllerState>({
    x: 0,
    z: 1.2,
    y: 1.5,
    rotationY: 0,
    targetRotationY: 0,
    isMoving: false,
    isRunning: false,
    speed: 3.2,
    targetPosition: null,
    currentAction: 'idle',
    actionTimer: 0,
    idleAutonomyTimer: 0,
    nearbyInteraction: null,
    bubbleText: null,
    bubbleTimer: 0,
  });

  const joystickVectorRef = useRef<JoystickVector>({
    x: 0,
    y: 0,
    distance: 0,
    isMoving: false,
    isRunning: false,
  });

  const isCameraFollowRef = useRef<boolean>(isCameraFollow);
  isCameraFollowRef.current = isCameraFollow;

  const charMeshesRef = useRef<CharacterMeshes | null>(null);

  // Calculate Carbon Trees available from CO2 reduction (1 tree per 2.4 kg CO2)
  const totalCarbonTreesEarned = useMemo(() => {
    return Math.max(1, Math.floor(stats.totalCO2 / 2.4));
  }, [stats.totalCO2]);

  // Count currently placed tree items
  const placedTreesCount = useMemo(() => {
    return decorations.filter(d => {
      const cat = DECOR_CATALOG.find(c => c.id === d.type);
      return cat?.isCarbonTree;
    }).length;
  }, [decorations]);

  const remainingTreesToPlace = Math.max(0, totalCarbonTreesEarned - placedTreesCount);

  // Show Toast feedback
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, 2800);
  };

  // Determine real time period
  const getRealTimePeriod = (): 'morning' | 'day' | 'sunset' | 'night' => {
    const hour = new Date().getHours();
    if (hour >= 6 && hour < 11) return 'morning';
    if (hour >= 11 && hour < 17) return 'day';
    if (hour >= 17 && hour < 19) return 'sunset';
    return 'night';
  };

  const currentPeriod = timeMode === 'auto' ? activePeriod : timeMode;

  useEffect(() => {
    if (timeMode === 'auto') {
      setActivePeriod(getRealTimePeriod());
      const interval = setInterval(() => {
        setActivePeriod(getRealTimePeriod());
      }, 60000);
      return () => clearInterval(interval);
    }
  }, [timeMode]);

  // Auto-persist decorations on change
  const saveDecorations = (newDecorations: PlacedDecoration[]) => {
    setDecorations(newDecorations);
    localStorage.setItem('karb_island_decorations_v2', JSON.stringify(newDecorations));
    if (userId) {
      saveIslandDecorationsToFirestore(userId, newDecorations);
    }
    if (onDecorationsChange) {
      onDecorationsChange(newDecorations);
    }
  };

  // Keep ref to state for Three.js event handlers to access latest without re-instantiating scene
  const decorRef = useRef<PlacedDecoration[]>(decorations);
  decorRef.current = decorations;

  const isEditModeRef = useRef<boolean>(isEditMode);
  isEditModeRef.current = isEditMode;

  const selectedDecorIdRef = useRef<string | null>(selectedDecorId);
  selectedDecorIdRef.current = selectedDecorId;

  // Scene Refs for direct manipulation
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const decorGroupRef = useRef<THREE.Group | null>(null);
  const selectionRingRef = useRef<THREE.Mesh | null>(null);
  const boundaryGridRef = useRef<THREE.Group | null>(null);
  const islandGroupRef = useRef<THREE.Group | null>(null);

  // =========================================================================
  // 1. THREE.JS SCENE SETUP & RENDER LOOP
  // =========================================================================
  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const width = container.clientWidth || 360;
    const height = container.clientHeight || 380;

    // A. Scene, Camera, Renderer
    const scene = new THREE.Scene();
    sceneRef.current = scene;

    // Background & Atmosphere by Time of Day
    if (currentPeriod === 'morning') {
      scene.background = new THREE.Color(0xfef3c7);
      scene.fog = new THREE.FogExp2(0xfef3c7, 0.012);
    } else if (currentPeriod === 'day') {
      scene.background = new THREE.Color(0xbae6fd);
      scene.fog = new THREE.FogExp2(0xbae6fd, 0.010);
    } else if (currentPeriod === 'sunset') {
      scene.background = new THREE.Color(0xfda4af);
      scene.fog = new THREE.FogExp2(0xfda4af, 0.015);
    } else {
      scene.background = new THREE.Color(0x0f172a);
      scene.fog = new THREE.FogExp2(0x0f172a, 0.020);
    }

    const camera = new THREE.PerspectiveCamera(42, width / height, 0.1, 1000);
    camera.position.set(0, 14, 22);
    camera.lookAt(0, 1.5, 0);
    cameraRef.current = camera;

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    // B. Island Main Root Group
    const islandGroup = new THREE.Group();
    scene.add(islandGroup);
    islandGroupRef.current = islandGroup;

    // C. Natural Soft 3D Lighting (Hemisphere + Directional + Warm Cozy PointLights)
    let hemiSky = 0xe0f2fe;
    let hemiGround = 0x4ade80;
    let hemiIntensity = 0.95;

    let dirColor = 0xfffbeb;
    let dirIntensity = 1.35;
    let dirPos = new THREE.Vector3(12, 22, 10);

    if (currentPeriod === 'morning') {
      hemiSky = 0xffedd5;
      hemiGround = 0x86efac;
      hemiIntensity = 0.9;
      dirColor = 0xfde047;
      dirIntensity = 1.25;
      dirPos.set(14, 14, 12);
    } else if (currentPeriod === 'sunset') {
      hemiSky = 0xfbcfe8;
      hemiGround = 0xfef08a;
      hemiIntensity = 0.85;
      dirColor = 0xf97316;
      dirIntensity = 1.25;
      dirPos.set(-14, 12, -10);
    } else if (currentPeriod === 'night') {
      hemiSky = 0x1e1b4b;
      hemiGround = 0x064e3b;
      hemiIntensity = 0.45;
      dirColor = 0x93c5fd;
      dirIntensity = 0.4;
      dirPos.set(-10, 16, -10);
    }

    const hemisphereLight = new THREE.HemisphereLight(hemiSky, hemiGround, hemiIntensity);
    scene.add(hemisphereLight);

    const dirLight = new THREE.DirectionalLight(dirColor, dirIntensity);
    dirLight.position.copy(dirPos);
    dirLight.castShadow = true;
    dirLight.shadow.mapSize.width = 2048;
    dirLight.shadow.mapSize.height = 2048;
    dirLight.shadow.camera.near = 0.5;
    dirLight.shadow.camera.far = 60;
    dirLight.shadow.camera.left = -11;
    dirLight.shadow.camera.right = 11;
    dirLight.shadow.camera.top = 11;
    dirLight.shadow.camera.bottom = -11;
    dirLight.shadow.bias = -0.0006;
    scene.add(dirLight);

    // Warm Cozy PointLights at Night
    if (currentPeriod === 'night') {
      // 1. Center Village Warm Hearth
      const centralWarmLight = new THREE.PointLight(0xf59e0b, 1.2, 11, 2);
      centralWarmLight.position.set(0, 2.8, 0);
      scene.add(centralWarmLight);

      // 2. North-West Cottage Lantern Glow
      const cottageWarmLight = new THREE.PointLight(0xfde047, 0.9, 8, 2);
      cottageWarmLight.position.set(-3.0, 2.2, -2.5);
      scene.add(cottageWarmLight);

      // 3. South-East Riverside Glow
      const riverWarmLight = new THREE.PointLight(0xf97316, 0.85, 8, 2);
      riverWarmLight.position.set(2.0, 2.0, 2.0);
      scene.add(riverWarmLight);
    }

    // D. Soft Rounded Floating Land Base (Pastel Emerald Grass + Warm Sand Rim + Clay Soil)
    const landGeo = new THREE.CylinderGeometry(7.8, 6.8, 3, 16);
    const landMat = new THREE.MeshStandardMaterial({
      color: 0x4ade80, // Lush Pastel Emerald Green
      roughness: 0.65,
      flatShading: true,
    });
    const mainLand = new THREE.Mesh(landGeo, landMat);
    mainLand.position.y = 0;
    mainLand.receiveShadow = true;
    mainLand.castShadow = true;
    mainLand.name = 'islandBaseGround';
    islandGroup.add(mainLand);

    // Warm Sandy Shore Rim
    const sandRimGeo = new THREE.RingGeometry(7.5, 7.82, 32);
    const sandRimMat = new THREE.MeshStandardMaterial({
      color: 0xfef08a,
      roughness: 0.7,
      side: THREE.DoubleSide,
    });
    const sandRim = new THREE.Mesh(sandRimGeo, sandRimMat);
    sandRim.rotation.x = -Math.PI / 2;
    sandRim.position.y = 1.51;
    sandRim.receiveShadow = true;
    islandGroup.add(sandRim);

    // Underground cliff & fertile earthy base
    const cliffGeo = new THREE.CylinderGeometry(6.8, 2.8, 3.8, 16);
    const cliffMat = new THREE.MeshStandardMaterial({ color: 0x78350f, roughness: 0.85, flatShading: true });
    const cliff = new THREE.Mesh(cliffGeo, cliffMat);
    cliff.position.y = -3.0;
    cliff.receiveShadow = true;
    cliff.castShadow = true;
    islandGroup.add(cliff);

    // Surrounding Soft Water Ring with subtle reflections
    const waterGeo = new THREE.CylinderGeometry(13.8, 13.8, 0.25, 36);
    const waterMat = new THREE.MeshStandardMaterial({
      color: currentPeriod === 'night' ? 0x0369a1 : 0x38bdf8,
      transparent: true,
      opacity: 0.82,
      roughness: 0.08,
      metalness: 0.18,
    });
    const water = new THREE.Mesh(waterGeo, waterMat);
    water.position.y = -1.2;
    water.receiveShadow = true;
    islandGroup.add(water);

    // Animated Natural River
    const riverGeo = new THREE.BoxGeometry(1.8, 0.08, 9.2);
    const riverMat = new THREE.MeshStandardMaterial({ 
      color: currentPeriod === 'night' ? 0x0284c7 : 0x0ea5e9, 
      roughness: 0.1, 
      metalness: 0.25 
    });
    const river = new THREE.Mesh(riverGeo, riverMat);
    river.position.set(1.1, 1.515, 1.0);
    river.rotation.y = 0.3;
    river.receiveShadow = true;
    islandGroup.add(river);

    // Waterfall cascading
    const waterfallGeo = new THREE.BoxGeometry(1.6, 3.2, 0.1);
    const waterfall = new THREE.Mesh(waterfallGeo, riverMat);
    waterfall.position.set(3.8, -0.1, 4.4);
    waterfall.rotation.y = 0.3;
    islandGroup.add(waterfall);

    // E. Visual Grid & Placement Boundary Indicators (Shown in Edit Mode)
    const boundaryGridGroup = new THREE.Group();
    boundaryGridGroup.visible = isEditMode;
    boundaryGridRef.current = boundaryGridGroup;

    // Glowing outer boundary ring (Radius 6.8 - max placeable radius)
    const ringGeo = new THREE.RingGeometry(6.65, 6.85, 48);
    const ringMat = new THREE.MeshBasicMaterial({ 
      color: 0x34d399, 
      side: THREE.DoubleSide, 
      transparent: true, 
      opacity: 0.75 
    });
    const boundaryRing = new THREE.Mesh(ringGeo, ringMat);
    boundaryRing.rotation.x = -Math.PI / 2;
    boundaryRing.position.y = 1.52;
    boundaryGridGroup.add(boundaryRing);

    [2.2, 4.4].forEach(r => {
      const innerRing = new THREE.Mesh(
        new THREE.RingGeometry(r - 0.04, r + 0.04, 36),
        new THREE.MeshBasicMaterial({ color: 0x6ee7b7, side: THREE.DoubleSide, transparent: true, opacity: 0.35 })
      );
      innerRing.rotation.x = -Math.PI / 2;
      innerRing.position.y = 1.52;
      boundaryGridGroup.add(innerRing);
    });

    const gridHelper = new THREE.GridHelper(13.6, 14, 0x10b981, 0x059669);
    gridHelper.position.y = 1.52;
    (gridHelper.material as THREE.Material).transparent = true;
    (gridHelper.material as THREE.Material).opacity = 0.25;
    boundaryGridGroup.add(gridHelper);

    islandGroup.add(boundaryGridGroup);

    // F. Selected Item Highlight Ring
    const selRingGeo = new THREE.RingGeometry(0.8, 1.05, 24);
    const selRingMat = new THREE.MeshBasicMaterial({ color: 0xfacc15, side: THREE.DoubleSide, transparent: true, opacity: 0.85 });
    const selectionRing = new THREE.Mesh(selRingGeo, selRingMat);
    selectionRing.rotation.x = -Math.PI / 2;
    selectionRing.position.y = 1.53;
    selectionRing.visible = false;
    islandGroup.add(selectionRing);
    selectionRingRef.current = selectionRing;

    // G. Mascot Pet on Island (Cute Rounded KARB Buddy with Roaming Animation)
    const petGroup = new THREE.Group();
    petGroup.position.set(0, 1.5, -0.5);

    const petBody = new THREE.Mesh(
      new THREE.SphereGeometry(0.65, 16, 16),
      new THREE.MeshStandardMaterial({ color: 0x2dd4bf, roughness: 0.3, flatShading: true })
    );
    petBody.position.y = 0.65;
    petBody.castShadow = true;
    petGroup.add(petBody);

    // Pet Eyes with catchlights
    const eyeMat = new THREE.MeshBasicMaterial({ color: 0x0f172a });
    const leftEye = new THREE.Mesh(new THREE.SphereGeometry(0.09, 8, 8), eyeMat);
    leftEye.position.set(-0.22, 0.75, 0.55);
    petGroup.add(leftEye);

    const rightEye = new THREE.Mesh(new THREE.SphereGeometry(0.09, 8, 8), eyeMat);
    rightEye.position.set(0.22, 0.75, 0.55);
    petGroup.add(rightEye);

    // Cute pink blush cheeks on pet
    const petBlushMat = new THREE.MeshBasicMaterial({ color: 0xf472b6 });
    [-0.32, 0.32].forEach(x => {
      const blush = new THREE.Mesh(new THREE.SphereGeometry(0.08, 6, 6), petBlushMat);
      blush.position.set(x, 0.62, 0.5);
      petGroup.add(blush);
    });

    // Pet Sprout
    const sprout = new THREE.Mesh(
      new THREE.ConeGeometry(0.14, 0.38, 5),
      new THREE.MeshStandardMaterial({ color: 0x4ade80 })
    );
    sprout.position.set(0, 1.35, 0);
    sprout.rotation.z = -0.2;
    petGroup.add(sprout);

    // Level 7+ Flower / Leaf Crown on Pet
    if (playerLevel >= 7 && playerLevel < 10) {
      const flowerCrownGroup = new THREE.Group();
      flowerCrownGroup.position.set(0, 1.15, 0);
      const wreathGeo = new THREE.TorusGeometry(0.35, 0.04, 6, 16);
      const wreathMat = new THREE.MeshStandardMaterial({ color: 0x22c55e, roughness: 0.5 });
      const wreath = new THREE.Mesh(wreathGeo, wreathMat);
      wreath.rotation.x = Math.PI / 2;
      flowerCrownGroup.add(wreath);

      const fColors = [0xf472b6, 0xfde047, 0x60a5fa, 0xf43f5e];
      for (let fi = 0; fi < 5; fi++) {
        const ang = (fi / 5) * Math.PI * 2;
        const floret = new THREE.Mesh(
          new THREE.SphereGeometry(0.06, 6, 6),
          new THREE.MeshStandardMaterial({ color: fColors[fi % fColors.length] })
        );
        floret.position.set(Math.cos(ang) * 0.36, 0.03, Math.sin(ang) * 0.36);
        flowerCrownGroup.add(floret);
      }
      petGroup.add(flowerCrownGroup);
    }

    // Level 10 Royal Golden Master Crown on Eco Pet 👑
    let goldenCrownGroup: THREE.Group | null = null;
    if (playerLevel >= 10) {
      goldenCrownGroup = new THREE.Group();
      goldenCrownGroup.position.set(0, 1.3, 0);

      const goldMat = new THREE.MeshStandardMaterial({
        color: 0xfacc15,
        metalness: 0.85,
        roughness: 0.2,
      });

      const crownBase = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.28, 0.1, 16), goldMat);
      crownBase.position.y = 0.05;
      crownBase.castShadow = true;
      goldenCrownGroup.add(crownBase);

      [-0.18, 0, 0.18].forEach((xPos, idx) => {
        const spireHeight = idx === 1 ? 0.32 : 0.22;
        const spire = new THREE.Mesh(new THREE.ConeGeometry(0.07, spireHeight, 5), goldMat);
        spire.position.set(xPos, 0.1 + spireHeight / 2, 0.22);
        spire.rotation.x = 0.15;
        goldenCrownGroup!.add(spire);
      });

      const gemMat = new THREE.MeshStandardMaterial({
        color: 0x10b981,
        emissive: 0x059669,
        emissiveIntensity: 0.6,
        roughness: 0.1,
      });
      const crownGem = new THREE.Mesh(new THREE.SphereGeometry(0.07, 8, 8), gemMat);
      crownGem.position.set(0, 0.16, 0.27);
      goldenCrownGroup.add(crownGem);

      petGroup.add(goldenCrownGroup);
    }

    petGroup.name = 'ecoPet';
    islandGroup.add(petGroup);

    // =========================================================================
    // LEVEL 9 & 10 STARLIGHT PARTICLES & FLOATING MASTER ECO CRYSTAL
    // =========================================================================
    const starlightParticles: { mesh: THREE.Mesh; orbitRadius: number; speed: number; yBase: number; phase: number }[] = [];
    if (playerLevel >= 9) {
      const starGeo = new THREE.OctahedronGeometry(0.1, 0);
      const starColors = [0xfef08a, 0x67e8f9, 0xa7f3d0, 0xfbcfe8];

      for (let si = 0; si < 32; si++) {
        const sMat = new THREE.MeshStandardMaterial({
          color: starColors[si % starColors.length],
          emissive: starColors[si % starColors.length],
          emissiveIntensity: 0.8,
          roughness: 0.2,
        });
        const starMesh = new THREE.Mesh(starGeo, sMat);
        scene.add(starMesh);

        starlightParticles.push({
          mesh: starMesh,
          orbitRadius: 4.5 + (si % 5) * 1.4,
          speed: 0.3 + (si % 4) * 0.15,
          yBase: 1.8 + (si % 7) * 0.8,
          phase: (si / 32) * Math.PI * 2,
        });
      }
    }

    let masterCrystalGroup: THREE.Group | null = null;
    let crystalInnerRing: THREE.Mesh | null = null;
    let crystalOuterRing: THREE.Mesh | null = null;

    if (playerLevel >= 10) {
      masterCrystalGroup = new THREE.Group();
      masterCrystalGroup.position.set(0, 7.2, 0);

      const crystalGeo = new THREE.OctahedronGeometry(0.55, 0);
      const crystalMat = new THREE.MeshStandardMaterial({
        color: 0x34d399,
        emissive: 0x10b981,
        emissiveIntensity: 0.65,
        roughness: 0.15,
        metalness: 0.2,
        transparent: true,
        opacity: 0.9,
      });
      const coreCrystal = new THREE.Mesh(crystalGeo, crystalMat);
      masterCrystalGroup.add(coreCrystal);

      const ringGoldMat = new THREE.MeshStandardMaterial({ color: 0xfacc15, metalness: 0.8, roughness: 0.2 });
      crystalInnerRing = new THREE.Mesh(new THREE.TorusGeometry(0.85, 0.03, 6, 24), ringGoldMat);
      crystalInnerRing.rotation.x = Math.PI / 4;
      masterCrystalGroup.add(crystalInnerRing);

      crystalOuterRing = new THREE.Mesh(new THREE.TorusGeometry(1.05, 0.025, 6, 24), ringGoldMat);
      crystalOuterRing.rotation.y = Math.PI / 3;
      masterCrystalGroup.add(crystalOuterRing);

      const crystalLight = new THREE.PointLight(0x6ee7b7, 1.2, 14);
      masterCrystalGroup.add(crystalLight);

      scene.add(masterCrystalGroup);

      const auraRingGeo = new THREE.RingGeometry(7.7, 8.4, 48);
      const auraRingMat = new THREE.MeshBasicMaterial({
        color: 0x6ee7b7,
        side: THREE.DoubleSide,
        transparent: true,
        opacity: 0.45,
      });
      const auraRing = new THREE.Mesh(auraRingGeo, auraRingMat);
      auraRing.rotation.x = -Math.PI / 2;
      auraRing.position.y = 1.48;
      islandGroup.add(auraRing);
    }

    // =========================================================================
    // NIGHT FIREFLIES SYSTEM (หิ่งห้อยเรืองแสงอ่อนละมุนยามราตรี)
    // =========================================================================
    const fireflyList: { mesh: THREE.Mesh; seed: number; radius: number; speed: number; yBase: number }[] = [];
    if (currentPeriod === 'night') {
      const fireflyGeo = new THREE.SphereGeometry(0.045, 6, 6);
      const fireflyMat = new THREE.MeshBasicMaterial({ color: 0xfde047 });

      for (let fi = 0; fi < 24; fi++) {
        const firefly = new THREE.Mesh(fireflyGeo, fireflyMat);
        scene.add(firefly);
        fireflyList.push({
          mesh: firefly,
          seed: fi * 1.37,
          radius: 2.0 + (fi % 6) * 0.8,
          speed: 0.4 + (fi % 3) * 0.2,
          yBase: 1.6 + (fi % 4) * 0.4,
        });
      }
    }

    // =========================================================================
    // H. LIVING CRITTERS (Cute Bunny 🐰, Flying Birds 🕊️, Fluttering Butterflies 🦋, Squirrel 🐿️)
    // =========================================================================
    
    // 1. Cute Hopping Bunny (กระต่ายน้อย)
    const bunnyGroup = new THREE.Group();
    bunnyGroup.name = 'islandBunny';
    
    const bunnyWhiteMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.4, flatShading: true });
    const bunnyPinkMat = new THREE.MeshBasicMaterial({ color: 0xfbcfe8 });
    
    const bBody = new THREE.Mesh(new THREE.SphereGeometry(0.24, 10, 10), bunnyWhiteMat);
    bBody.position.y = 0.22;
    bBody.castShadow = true;
    bunnyGroup.add(bBody);

    const bHead = new THREE.Mesh(new THREE.SphereGeometry(0.18, 10, 10), bunnyWhiteMat);
    bHead.position.set(0.12, 0.34, 0);
    bunnyGroup.add(bHead);

    [-0.05, 0.05].forEach(z => {
      const ear = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.05, 0.24, 6), bunnyWhiteMat);
      ear.position.set(0.12, 0.52, z);
      ear.rotation.z = -0.15;
      bunnyGroup.add(ear);

      const innerEar = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.025, 0.16, 6), bunnyPinkMat);
      innerEar.position.set(0.13, 0.52, z);
      innerEar.rotation.z = -0.15;
      bunnyGroup.add(innerEar);
    });

    [-0.08, 0.08].forEach(z => {
      const bEye = new THREE.Mesh(new THREE.SphereGeometry(0.028, 6, 6), eyeMat);
      bEye.position.set(0.24, 0.38, z);
      bunnyGroup.add(bEye);
    });

    const bTail = new THREE.Mesh(new THREE.SphereGeometry(0.08, 6, 6), bunnyWhiteMat);
    bTail.position.set(-0.2, 0.22, 0);
    bunnyGroup.add(bTail);

    bunnyGroup.position.set(-1.8, 1.5, -1.2);
    islandGroup.add(bunnyGroup);

    // 2. Flying Birds (นกน้อยรักษ์โลก 2 ตัว บินวนบนท้องฟ้า)
    const birdList: { group: THREE.Group; leftWing: THREE.Mesh; rightWing: THREE.Mesh; orbitRadius: number; speed: number; height: number; phase: number }[] = [];
    
    [0, 1].forEach(i => {
      const bGroup = new THREE.Group();
      const birdMat = new THREE.MeshStandardMaterial({ color: i === 0 ? 0x38bdf8 : 0xfbcfe8, roughness: 0.4, flatShading: true });
      
      const birdBody = new THREE.Mesh(new THREE.ConeGeometry(0.1, 0.35, 5), birdMat);
      birdBody.rotation.x = Math.PI / 2;
      bGroup.add(birdBody);

      const bBeak = new THREE.Mesh(new THREE.ConeGeometry(0.04, 0.12, 4), new THREE.MeshBasicMaterial({ color: 0xf97316 }));
      bBeak.position.set(0, 0, 0.22);
      bBeak.rotation.x = Math.PI / 2;
      bGroup.add(bBeak);

      const wingGeo = new THREE.BoxGeometry(0.35, 0.03, 0.16);
      const leftWing = new THREE.Mesh(wingGeo, birdMat);
      leftWing.position.set(-0.2, 0.02, 0);
      bGroup.add(leftWing);

      const rightWing = new THREE.Mesh(wingGeo, birdMat);
      rightWing.position.set(0.2, 0.02, 0);
      bGroup.add(rightWing);

      scene.add(bGroup);
      birdList.push({
        group: bGroup,
        leftWing,
        rightWing,
        orbitRadius: 5.5 + i * 2.2,
        speed: 0.6 + i * 0.2,
        height: 6.5 + i * 1.5,
        phase: i * Math.PI,
      });
    });

    // 3. Fluttering Colorful Butterflies (ผีเสื้อ 3 ตัว บินรอบแปลงดอกไม้)
    const butterflyList: { group: THREE.Group; leftWing: THREE.Mesh; rightWing: THREE.Mesh; centerX: number; centerZ: number; speed: number; phase: number }[] = [];
    const bFlyColors = [0xf472b6, 0xfde047, 0xa78bfa];

    [
      { cx: -1.0, cz: 1.8 },
      { cx: 3.6, cz: -1.0 },
      { cx: 1.8, cz: -2.8 },
    ].forEach((pos, idx) => {
      const bfGroup = new THREE.Group();
      const wingMat = new THREE.MeshStandardMaterial({ color: bFlyColors[idx], side: THREE.DoubleSide, roughness: 0.3 });

      const lWing = new THREE.Mesh(new THREE.CircleGeometry(0.12, 8), wingMat);
      lWing.position.set(-0.1, 0, 0);
      bfGroup.add(lWing);

      const rWing = new THREE.Mesh(new THREE.CircleGeometry(0.12, 8), wingMat);
      rWing.position.set(0.1, 0, 0);
      bfGroup.add(rWing);

      bfGroup.position.set(pos.cx, 2.0, pos.cz);
      islandGroup.add(bfGroup);

      butterflyList.push({
        group: bfGroup,
        leftWing: lWing,
        rightWing: rWing,
        centerX: pos.cx,
        centerZ: pos.cz,
        speed: 1.5 + idx * 0.4,
        phase: idx * 2,
      });
    });

    // 4. Cute Squirrel (กระรอกน้อย)
    const squirrelGroup = new THREE.Group();
    squirrelGroup.name = 'islandSquirrel';
    const sqMat = new THREE.MeshStandardMaterial({ color: 0xd97706, roughness: 0.6, flatShading: true });
    
    const sqBody = new THREE.Mesh(new THREE.SphereGeometry(0.18, 8, 8), sqMat);
    sqBody.position.y = 0.18;
    sqBody.castShadow = true;
    squirrelGroup.add(sqBody);

    const sqHead = new THREE.Mesh(new THREE.SphereGeometry(0.14, 8, 8), sqMat);
    sqHead.position.set(0.1, 0.28, 0);
    squirrelGroup.add(sqHead);

    const sqTail = new THREE.Mesh(new THREE.TorusGeometry(0.16, 0.08, 6, 12, Math.PI * 1.2), sqMat);
    sqTail.position.set(-0.16, 0.28, 0);
    sqTail.rotation.y = Math.PI / 2;
    squirrelGroup.add(sqTail);

    squirrelGroup.position.set(2.2, 1.5, -2.2);
    squirrelGroup.rotation.y = -0.8;
    islandGroup.add(squirrelGroup);

    // I. Sky Clouds
    const cloudsGroup = new THREE.Group();
    for (let i = 0; i < 5; i++) {
      const cloud = new THREE.Group();
      const cloudMat = new THREE.MeshStandardMaterial({ color: 0xffffff, transparent: true, opacity: 0.85, roughness: 0.9 });
      [0, 0.5, 1].forEach((dx) => {
        const puff = new THREE.Mesh(new THREE.DodecahedronGeometry(0.8 + Math.random() * 0.4, 1), cloudMat);
        puff.position.set(dx * 0.9, Math.random() * 0.3, 0);
        cloud.add(puff);
      });
      cloud.position.set(-15 + i * 7, 8 + Math.random() * 3, -10 + (i % 3) * 6);
      cloudsGroup.add(cloud);
    }
    scene.add(cloudsGroup);

    // J. Decor Items Group
    const decorGroup = new THREE.Group();
    islandGroup.add(decorGroup);
    decorGroupRef.current = decorGroup;

    const rebuildDecorMeshes = () => {
      while (decorGroup.children.length > 0) {
        decorGroup.remove(decorGroup.children[0]);
      }

      decorRef.current.forEach(item => {
        const mesh = createDecorMesh(item.type, currentPeriod === 'night');
        mesh.position.set(item.x, 1.5, item.z);
        mesh.rotation.y = item.rotationY;
        mesh.scale.set(item.scale, item.scale, item.scale);
        mesh.name = `decor_${item.id}`;
        mesh.userData = { decorId: item.id, itemType: item.type };
        decorGroup.add(mesh);
      });
    };

    rebuildDecorMeshes();

    // K. Cute 3D Explorer Character & Target Ripple Marker
    const charMeshes = createExplorerCharacter(currentPeriod === 'night');
    charMeshesRef.current = charMeshes;
    islandGroup.add(charMeshes.rootGroup);
    islandGroup.add(charMeshes.targetMarker);

    // =========================================================================
    // 2. INTERACTIVE CONTROLS & RAYCASTING (Rotate, Drag, Select, Character Move)
    // =========================================================================
    let isOrbitDragging = false;
    let isItemDragging = false;
    let draggedDecorId: string | null = null;
    let previousX = 0;
    let previousY = 0;
    let targetRotationY = 0;
    let targetRotationX = 0;

    const raycaster = new THREE.Raycaster();
    const mouse = new THREE.Vector2();
    const planeIntersect = new THREE.Vector3();
    const groundMathPlane = new THREE.Plane(new THREE.Vector3(0, 1, 0), -1.5); // Y = 1.5 ground level

    const getPointerPos = (e: MouseEvent | TouchEvent) => {
      const clientX = 'touches' in e && e.touches.length > 0 ? e.touches[0].clientX : (e as MouseEvent).clientX;
      const clientY = 'touches' in e && e.touches.length > 0 ? e.touches[0].clientY : (e as MouseEvent).clientY;
      return { clientX, clientY };
    };

    const updateMouseCoords = (clientX: number, clientY: number) => {
      const rect = renderer.domElement.getBoundingClientRect();
      mouse.x = ((clientX - rect.left) / rect.width) * 2 - 1;
      mouse.y = -((clientY - rect.top) / rect.height) * 2 + 1;
    };

    const onPointerDown = (e: MouseEvent | TouchEvent) => {
      const { clientX, clientY } = getPointerPos(e);
      updateMouseCoords(clientX, clientY);
      previousX = clientX;
      previousY = clientY;

      if (isEditModeRef.current) {
        raycaster.setFromCamera(mouse, camera);
        const intersects = raycaster.intersectObjects(decorGroup.children, true);

        if (intersects.length > 0) {
          let topMesh: THREE.Object3D | null = intersects[0].object;
          while (topMesh && !topMesh.userData?.decorId && topMesh.parent !== decorGroup) {
            topMesh = topMesh.parent;
          }

          if (topMesh && topMesh.userData?.decorId) {
            const decorId = topMesh.userData.decorId;
            setSelectedDecorId(decorId);
            draggedDecorId = decorId;
            isItemDragging = true;
            isOrbitDragging = false;

            const item = decorRef.current.find(d => d.id === decorId);
            const catalog = DECOR_CATALOG.find(c => c.id === item?.type);
            showToast(`✨ กำลังเลือก: ${catalog?.nameTh || 'ของตกแต่ง'} (ลากเพื่อย้าย)`);
            return;
          }
        }
      }

      isOrbitDragging = true;
      isItemDragging = false;
    };

    const onPointerMove = (e: MouseEvent | TouchEvent) => {
      const { clientX, clientY } = getPointerPos(e);
      const deltaX = clientX - previousX;
      const deltaY = clientY - previousY;

      if (isItemDragging && draggedDecorId && isEditModeRef.current) {
        updateMouseCoords(clientX, clientY);
        raycaster.setFromCamera(mouse, camera);

        if (raycaster.ray.intersectPlane(groundMathPlane, planeIntersect)) {
          const invMatrix = new THREE.Matrix4().copy(islandGroup.matrixWorld).invert();
          const localPoint = planeIntersect.clone().applyMatrix4(invMatrix);

          const maxRadius = 6.8;
          let clampedX = localPoint.x;
          let clampedZ = localPoint.z;
          const currentRadius = Math.sqrt(clampedX * clampedX + clampedZ * clampedZ);

          if (currentRadius > maxRadius) {
            const angle = Math.atan2(clampedZ, clampedX);
            clampedX = Math.cos(angle) * maxRadius;
            clampedZ = Math.sin(angle) * maxRadius;
            setIsBoundaryWarning(true);
          } else {
            setIsBoundaryWarning(false);
          }

          const targetMesh = decorGroup.getObjectByName(`decor_${draggedDecorId}`);
          if (targetMesh) {
            targetMesh.position.x = clampedX;
            targetMesh.position.z = clampedZ;
          }

          if (selectionRing.visible) {
            selectionRing.position.x = clampedX;
            selectionRing.position.z = clampedZ;
          }

          const updated = decorRef.current.map(item => {
            if (item.id === draggedDecorId) {
              return {
                ...item,
                x: Number(clampedX.toFixed(2)),
                z: Number(clampedZ.toFixed(2)),
              };
            }
            return item;
          });
          saveDecorations(updated);
        }

        previousX = clientX;
        previousY = clientY;
      } else if (isOrbitDragging) {
        targetRotationY += deltaX * 0.008;
        targetRotationX += deltaY * 0.004;
        targetRotationX = Math.max(-0.45, Math.min(0.65, targetRotationX));

        previousX = clientX;
        previousY = clientY;
      }
    };

    const onPointerUp = () => {
      if (isItemDragging && draggedDecorId) {
        setIsBoundaryWarning(false);
      }
      isOrbitDragging = false;
      isItemDragging = false;
      draggedDecorId = null;
    };

    // Click handler for viewing mode (tap-to-move character, pet jump, watering tree, etc.)
    const handleCanvasClick = (e: MouseEvent) => {
      if (isEditModeRef.current) return;
      const { clientX, clientY } = getPointerPos(e);
      updateMouseCoords(clientX, clientY);

      raycaster.setFromCamera(mouse, camera);

      // 1. Raycast onto ground plane for character tap-to-move
      if (raycaster.ray.intersectPlane(groundMathPlane, planeIntersect)) {
        const invMatrix = new THREE.Matrix4().copy(islandGroup.matrixWorld).invert();
        const localPoint = planeIntersect.clone().applyMatrix4(invMatrix);
        const distFromCenter = Math.hypot(localPoint.x, localPoint.z);

        if (distFromCenter <= 6.35) {
          const col = checkPositionCollision(localPoint.x, localPoint.z, decorRef.current);
          charStateRef.current.targetPosition = new THREE.Vector3(col.slideX, 1.5, col.slideZ);
          charStateRef.current.idleAutonomyTimer = 0;
          if (charStateRef.current.currentAction === 'sit') {
            charStateRef.current.currentAction = 'idle';
          }
        }
      }

      // 2. Interactive Object Tap Responses
      const intersects = raycaster.intersectObjects(islandGroup.children, true);
      if (intersects.length > 0) {
        let obj: THREE.Object3D | null = intersects[0].object;
        while (obj && !obj.name && obj.parent !== islandGroup) {
          obj = obj.parent;
        }

        if (obj) {
          if (obj.name === 'ecoPet') {
            petGroup.position.y = 2.8;
            showToast('🐾 Eco Pet สดชื่นและร่าเริง!');
          } else if (obj.name === 'islandBunny') {
            bunnyGroup.position.y = 2.4;
            showToast('🐰 กระต่ายน้อยกระโดดดุ๊กดิ๊กทักทาย!');
          } else if (obj.name === 'islandSquirrel') {
            squirrelGroup.position.y = 2.0;
            showToast('🐿️ กระรอกน้อยกำลังเพลิดเพลินกับร่มเงา!');
          } else if (obj.name?.startsWith('decor_')) {
            const decorId = obj.name.replace('decor_', '');
            const item = decorRef.current.find(d => d.id === decorId);
            const catalog = DECOR_CATALOG.find(c => c.id === item?.type);
            if (catalog) {
              if (catalog.isCarbonTree) {
                showToast(`🌳 ${catalog.nameTh} (รดน้ำสดชื่น!)`);
                if (onWaterTree) onWaterTree(0);
              } else {
                showToast(`${catalog.emoji} ${catalog.nameTh}`);
              }
            }
          }
        }
      }
    };

    const domElem = renderer.domElement;
    domElem.addEventListener('mousedown', onPointerDown);
    domElem.addEventListener('mousemove', onPointerMove);
    window.addEventListener('mouseup', onPointerUp);

    domElem.addEventListener('touchstart', onPointerDown, { passive: true });
    domElem.addEventListener('touchmove', onPointerMove, { passive: true });
    window.addEventListener('touchend', onPointerUp);

    domElem.addEventListener('click', handleCanvasClick);

    // Resize Handler
    const handleResize = () => {
      if (!container) return;
      const newW = container.clientWidth;
      const newH = container.clientHeight;
      camera.aspect = newW / newH;
      camera.updateProjectionMatrix();
      renderer.setSize(newW, newH);
    };
    window.addEventListener('resize', handleResize);

    // =========================================================================
    // 3. ANIMATION LOOP (60FPS - Living Creatures & Dynamic Effects)
    // =========================================================================
    let animationFrameId: number;
    const clock = new THREE.Clock();

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      const elapsedTime = clock.getElapsedTime();

      // Smooth rotation damping for island
      islandGroup.rotation.y += (targetRotationY - islandGroup.rotation.y) * 0.06;
      islandGroup.rotation.x += (targetRotationX - islandGroup.rotation.x) * 0.06;

      // 1. Animate Wind Turbine Blades & Windmill Sails & Campfire
      decorGroup.traverse((child) => {
        if (child.name === 'turbineBlades') {
          child.rotation.z += 0.04;
        } else if (child.name === 'windmillSails') {
          child.rotation.z += 0.02;
        } else if (child.name === 'campfireFlame') {
          child.scale.y = 0.9 + Math.sin(elapsedTime * 8) * 0.2;
          child.scale.x = 0.9 + Math.cos(elapsedTime * 8) * 0.1;
        } else if (child.name === 'floatingDuck') {
          child.position.y = 0.28 + Math.sin(elapsedTime * 2.5) * 0.03;
          child.rotation.y = Math.sin(elapsedTime * 1.2) * 0.2;
        }
      });

      // 2. Gentle Plant & Flower Swaying in the breeze
      decorGroup.children.forEach((mesh, idx) => {
        const itemType = mesh.userData?.itemType;
        if (itemType?.startsWith('tree_') || itemType?.startsWith('flowers_') || itemType?.includes('bush')) {
          mesh.rotation.z = Math.sin(elapsedTime * 1.5 + idx) * 0.03;
        }
      });

      // 3. Water Ripple Animation
      riverMat.roughness = 0.12 + Math.sin(elapsedTime * 2.2) * 0.06;

      // 4. Mascot Eco Pet Roaming & Idle Animation (Roaming between 3 cozy waypoints)
      const petCycle = (elapsedTime * 0.15) % 3;
      let targetPetX = 0;
      let targetPetZ = -0.5;
      let targetPetRot = 0;

      if (petCycle < 1) {
        // Spot 1: Center Village Hearth
        targetPetX = 0;
        targetPetZ = -0.5;
        targetPetRot = 0;
      } else if (petCycle < 2) {
        // Spot 2: Cottage Garden Path (North-West)
        targetPetX = -2.2;
        targetPetZ = -1.2;
        targetPetRot = Math.PI / 4;
      } else {
        // Spot 3: Riverside Breeze Deck (East)
        targetPetX = 2.0;
        targetPetZ = 0.8;
        targetPetRot = -Math.PI / 3;
      }

      // Smooth walk towards target waypoint
      petGroup.position.x += (targetPetX - petGroup.position.x) * 0.02;
      petGroup.position.z += (targetPetZ - petGroup.position.z) * 0.02;
      petGroup.rotation.y += (targetPetRot - petGroup.rotation.y) * 0.04;

      // Happy hop & bounce
      const petHop = Math.abs(Math.sin(elapsedTime * 3.5)) * 0.15;
      petGroup.position.y = 1.5 + petHop;
      sprout.rotation.z = Math.sin(elapsedTime * 4) * 0.18;

      // 5. Bouncing Bunny Path & Hop Animation
      const bunnyAngle = elapsedTime * 0.4;
      const bunnyRadius = 3.8;
      const hopY = Math.abs(Math.sin(elapsedTime * 4)) * 0.35;
      
      if (bunnyGroup.position.y > 1.5 + hopY + 0.05) {
        bunnyGroup.position.y = Math.max(1.5, bunnyGroup.position.y - 0.08);
      } else {
        bunnyGroup.position.x = Math.cos(bunnyAngle) * bunnyRadius;
        bunnyGroup.position.z = Math.sin(bunnyAngle) * bunnyRadius;
        bunnyGroup.position.y = 1.5 + hopY;
        bunnyGroup.rotation.y = -bunnyAngle + Math.PI / 2;
      }

      // 6. Flying Birds Flapping Wings & Orbiting Sky
      birdList.forEach(bird => {
        const bAngle = elapsedTime * bird.speed + bird.phase;
        bird.group.position.x = Math.cos(bAngle) * bird.orbitRadius;
        bird.group.position.z = Math.sin(bAngle) * bird.orbitRadius;
        bird.group.position.y = bird.height + Math.sin(elapsedTime * 2 + bird.phase) * 0.4;
        bird.group.rotation.y = -bAngle - Math.PI / 2;
        
        const wingFlap = Math.sin(elapsedTime * 12 + bird.phase) * 0.6;
        bird.leftWing.rotation.z = wingFlap;
        bird.rightWing.rotation.z = -wingFlap;
      });

      // 7. Fluttering Butterflies
      butterflyList.forEach(bf => {
        const bTime = elapsedTime * bf.speed + bf.phase;
        bf.group.position.x = bf.centerX + Math.sin(bTime) * 0.45;
        bf.group.position.z = bf.centerZ + Math.cos(bTime * 0.8) * 0.45;
        bf.group.position.y = 2.0 + Math.sin(bTime * 2) * 0.25;

        const flap = Math.sin(elapsedTime * 18 + bf.phase) * 0.7;
        bf.leftWing.rotation.y = flap;
        bf.rightWing.rotation.y = -flap;
      });

      // 8. Squirrel idle head bob
      squirrelGroup.position.y = 1.5 + Math.sin(elapsedTime * 2) * 0.02;

      // 9. Clouds drift
      cloudsGroup.children.forEach((cloud) => {
        cloud.position.x += 0.008;
        if (cloud.position.x > 18) cloud.position.x = -18;
      });

      // 10. Selected Object Highlight Ring pulsation
      if (selectionRing.visible) {
        selectionRing.scale.setScalar(1 + Math.sin(elapsedTime * 5) * 0.06);
      }

      // 11. Night Fireflies Glowing & Drifting
      fireflyList.forEach(ff => {
        const ffAngle = elapsedTime * ff.speed + ff.seed;
        ff.mesh.position.x = Math.cos(ffAngle) * ff.radius;
        ff.mesh.position.z = Math.sin(ffAngle * 1.3) * ff.radius;
        ff.mesh.position.y = ff.yBase + Math.sin(elapsedTime * 2.5 + ff.seed) * 0.4;
        
        // Gentle pulse glow
        const ffScale = 0.8 + Math.sin(elapsedTime * 4 + ff.seed) * 0.35;
        ff.mesh.scale.setScalar(Math.max(0.2, ffScale));
      });

      // 12. Animate Starlight Particles (Level 9 & 10)
      starlightParticles.forEach(star => {
        const starAngle = elapsedTime * star.speed + star.phase;
        star.mesh.position.x = Math.cos(starAngle) * star.orbitRadius;
        star.mesh.position.z = Math.sin(starAngle) * star.orbitRadius;
        star.mesh.position.y = star.yBase + Math.sin(elapsedTime * 2 + star.phase) * 0.35;
        star.mesh.rotation.y += 0.03;
        star.mesh.rotation.x += 0.02;
      });

      // 13. Animate Floating Master Eco Crystal (Level 10)
      if (masterCrystalGroup) {
        masterCrystalGroup.position.y = 7.2 + Math.sin(elapsedTime * 2) * 0.25;
        masterCrystalGroup.rotation.y = elapsedTime * 0.6;

        if (crystalInnerRing) {
          crystalInnerRing.rotation.z += 0.03;
          crystalInnerRing.rotation.x += 0.02;
        }
        if (crystalOuterRing) {
          crystalOuterRing.rotation.y += 0.02;
          crystalOuterRing.rotation.z -= 0.015;
        }
      }

      // 14. Golden Crown Sparkle pulse on Eco Pet (Level 10)
      if (goldenCrownGroup) {
        goldenCrownGroup.rotation.y = Math.sin(elapsedTime * 2) * 0.1;
      }

      // 15. Dynamic 3D Explorer Character Movement & Animation Rig
      const delta = Math.min(clock.getDelta(), 0.1);
      const charState = charStateRef.current;
      const joyVec = joystickVectorRef.current;

      if (!isEditModeRef.current) {
        // A. Manual Virtual Joystick / Keyboard control
        if (joyVec.isMoving) {
          charState.idleAutonomyTimer = 0;
          charState.targetPosition = null;
          if (charState.currentAction === 'sit') {
            charState.currentAction = 'idle';
          }

          const moveSpeed = joyVec.isRunning ? 5.2 : 3.4;
          charState.isRunning = joyVec.isRunning;
          charState.isMoving = true;
          charState.currentAction = joyVec.isRunning ? 'run' : 'walk';

          // Movement vector in world space
          const moveDirX = joyVec.x;
          const moveDirZ = joyVec.y;
          charState.targetRotationY = Math.atan2(moveDirX, moveDirZ);

          const nextX = charState.x + moveDirX * moveSpeed * delta;
          const nextZ = charState.z + moveDirZ * moveSpeed * delta;

          const col = checkPositionCollision(nextX, nextZ, decorRef.current);
          charState.x = col.slideX;
          charState.z = col.slideZ;
        } else if (charState.targetPosition) {
          // B. Click-to-Move Pathing
          charState.idleAutonomyTimer = 0;
          if (charState.currentAction === 'sit') {
            charState.currentAction = 'idle';
          }

          const tx = charState.targetPosition.x;
          const tz = charState.targetPosition.z;
          const dist = Math.hypot(tx - charState.x, tz - charState.z);

          if (dist < 0.2) {
            charState.x = tx;
            charState.z = tz;
            charState.targetPosition = null;
            charState.isMoving = false;
            charState.isRunning = false;
            charState.currentAction = 'idle';
          } else {
            charState.isMoving = true;
            charState.currentAction = 'walk';
            const walkSpeed = 3.6;
            const dirX = (tx - charState.x) / dist;
            const dirZ = (tz - charState.z) / dist;

            charState.targetRotationY = Math.atan2(dirX, dirZ);

            const nextX = charState.x + dirX * walkSpeed * delta;
            const nextZ = charState.z + dirZ * walkSpeed * delta;

            const col = checkPositionCollision(nextX, nextZ, decorRef.current);
            charState.x = col.slideX;
            charState.z = col.slideZ;

            if (col.isBlocked && Math.hypot(col.slideX - charState.x, col.slideZ - charState.z) < 0.015) {
              charState.targetPosition = null;
              charState.isMoving = false;
              charState.currentAction = 'idle';
            }
          }
        } else {
          // C. Autonomous Cozy Idle Behavior (when player isn't providing input)
          charState.idleAutonomyTimer += delta;

          if (charState.idleAutonomyTimer > 6.5 && charState.currentAction === 'idle') {
            charState.idleAutonomyTimer = 0;
            const autoActions = ['wander', 'gaze_water', 'wave_pet', 'cozy_stretch'];
            const chosen = autoActions[Math.floor(Math.random() * autoActions.length)];

            if (chosen === 'wander') {
              const randAng = Math.random() * Math.PI * 2;
              const randRad = 1.0 + Math.random() * 3.6;
              const wanderX = Math.cos(randAng) * randRad;
              const wanderZ = Math.sin(randAng) * randRad;
              const col = checkPositionCollision(wanderX, wanderZ, decorRef.current);
              if (!col.isBlocked) {
                charState.targetPosition = new THREE.Vector3(wanderX, 1.5, wanderZ);
              }
            } else if (chosen === 'gaze_water') {
              charState.currentAction = 'gaze';
              charState.actionTimer = 3.0;
              charState.targetRotationY = Math.atan2(1.2 - charState.x, 1.0 - charState.z);
            } else if (chosen === 'wave_pet') {
              charState.currentAction = 'wave';
              charState.actionTimer = 2.0;
              charState.bubbleText = '🐾';
              charState.bubbleTimer = 2.0;
              updateBubbleTexture(charMeshes.bubbleCanvas, charMeshes.bubbleTexture, '🐾');
            } else {
              charState.currentAction = 'cheer';
              charState.actionTimer = 1.8;
              charState.bubbleText = '🌿';
              charState.bubbleTimer = 1.8;
              updateBubbleTexture(charMeshes.bubbleCanvas, charMeshes.bubbleTexture, '🌿');
            }
          }

          if (charState.actionTimer > 0) {
            charState.actionTimer -= delta;
            if (charState.actionTimer <= 0) {
              charState.currentAction = 'idle';
            }
          }

          if (charState.currentAction !== 'sit' && charState.currentAction !== 'wave' && charState.currentAction !== 'cheer') {
            charState.isMoving = false;
          }
        }

        // D. Speech Bubble Expiry
        if (charState.bubbleTimer > 0) {
          charState.bubbleTimer -= delta;
          if (charState.bubbleTimer <= 0) {
            charState.bubbleText = null;
            updateBubbleTexture(charMeshes.bubbleCanvas, charMeshes.bubbleTexture, null);
          }
        }

        // E. Detect Nearby Interactive Objects
        const nearby = findNearbyInteractions(charState.x, charState.z, decorRef.current, {
          x: petGroup.position.x,
          z: petGroup.position.z
        });
        setNearbyInteraction(nearby);

        // F. Smooth Camera Follow in Explore Mode
        if (isCameraFollowRef.current) {
          const desiredCamX = charState.x * 0.35;
          camera.position.x += (desiredCamX - camera.position.x) * 0.04;
          camera.lookAt(charState.x * 0.45, 1.5, charState.z * 0.45);
        }
      }

      // G. Animate Character Skeleton / Meshes
      animateExplorerCharacter(charMeshes, charState, delta, elapsedTime);

      renderer.render(scene, camera);
    };

    animate();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('mouseup', onPointerUp);
      window.removeEventListener('touchend', onPointerUp);
      if (container) container.innerHTML = '';
      renderer.dispose();
    };
  }, [currentPeriod, playerLevel]); // Re-run if sky period or level changes

  // =========================================================================
  // 4. SYNC DECORATIONS MESHES WITH STATE
  // =========================================================================
  useEffect(() => {
    if (!decorGroupRef.current) return;
    const decorGroup = decorGroupRef.current;

    while (decorGroup.children.length > 0) {
      decorGroup.remove(decorGroup.children[0]);
    }

    decorations.forEach(item => {
      const mesh = createDecorMesh(item.type, currentPeriod === 'night');
      mesh.position.set(item.x, 1.5, item.z);
      mesh.rotation.y = item.rotationY;
      mesh.scale.set(item.scale, item.scale, item.scale);
      mesh.name = `decor_${item.id}`;
      mesh.userData = { decorId: item.id, itemType: item.type };
      decorGroup.add(mesh);
    });

    if (selectionRingRef.current) {
      if (selectedDecorId) {
        const selItem = decorations.find(d => d.id === selectedDecorId);
        if (selItem) {
          selectionRingRef.current.position.set(selItem.x, 1.53, selItem.z);
          selectionRingRef.current.visible = isEditMode;
        } else {
          selectionRingRef.current.visible = false;
        }
      } else {
        selectionRingRef.current.visible = false;
      }
    }
  }, [decorations, selectedDecorId, isEditMode, currentPeriod]);

  // Sync boundary grid visibility
  useEffect(() => {
    if (boundaryGridRef.current) {
      boundaryGridRef.current.visible = isEditMode;
    }
  }, [isEditMode]);

  // =========================================================================
  // 5. CAMERA PRESET VIEWS & ZOOM CONTROLS
  // =========================================================================
  const applyCameraPreset = (preset: 'iso' | 'top' | 'side') => {
    if (!cameraRef.current || !islandGroupRef.current) return;
    const camera = cameraRef.current;
    setCameraViewPreset(preset);

    if (preset === 'top') {
      camera.position.set(0, 24, 0.1);
      camera.lookAt(0, 1.5, 0);
      islandGroupRef.current.rotation.x = 0;
      islandGroupRef.current.rotation.y = 0;
    } else if (preset === 'side') {
      camera.position.set(16, 7, 14);
      camera.lookAt(0, 1.5, 0);
      islandGroupRef.current.rotation.x = 0;
    } else {
      camera.position.set(0, 14, 22);
      camera.lookAt(0, 1.5, 0);
    }
  };

  const handleZoom = (direction: 'in' | 'out') => {
    if (!cameraRef.current) return;
    const camera = cameraRef.current;
    const factor = direction === 'in' ? 0.85 : 1.15;
    camera.position.x *= factor;
    camera.position.y *= factor;
    camera.position.z *= factor;
  };

  // =========================================================================
  // 6. OBJECT EDITING ACTIONS (Rotate, Scale, Nudge, Stash, Add)
  // =========================================================================
  const selectedDecor = useMemo(() => {
    return decorations.find(d => d.id === selectedDecorId);
  }, [decorations, selectedDecorId]);

  const selectedCatalogInfo = useMemo(() => {
    if (!selectedDecor) return null;
    return DECOR_CATALOG.find(c => c.id === selectedDecor.type);
  }, [selectedDecor]);

  // Rotate selected object by delta angle
  const handleRotateSelected = (deltaAngle: number) => {
    if (!selectedDecorId) return;
    const updated = decorations.map(d => {
      if (d.id === selectedDecorId) {
        return { ...d, rotationY: Number((d.rotationY + deltaAngle).toFixed(2)) };
      }
      return d;
    });
    saveDecorations(updated);
  };

  // Scale selected object
  const handleScaleSelected = (scaleMultiplier: number) => {
    if (!selectedDecorId) return;
    const updated = decorations.map(d => {
      if (d.id === selectedDecorId) {
        return { ...d, scale: Math.max(0.6, Math.min(1.6, Number((d.scale * scaleMultiplier).toFixed(2)))) };
      }
      return d;
    });
    saveDecorations(updated);
  };

  // Fine Nudge D-Pad positioning
  const handleNudgeSelected = (dx: number, dz: number) => {
    if (!selectedDecorId) return;
    const updated = decorations.map(d => {
      if (d.id === selectedDecorId) {
        let newX = d.x + dx;
        let newZ = d.z + dz;
        const dist = Math.sqrt(newX * newX + newZ * newZ);
        if (dist > 6.8) {
          const angle = Math.atan2(newZ, newX);
          newX = Math.cos(angle) * 6.8;
          newZ = Math.sin(angle) * 6.8;
        }
        return { ...d, x: Number(newX.toFixed(2)), z: Number(newZ.toFixed(2)) };
      }
      return d;
    });
    saveDecorations(updated);
  };

  // Remove/Stash item back into inventory
  const handleRemoveSelected = () => {
    if (!selectedDecorId) return;
    const itemToRemove = decorations.find(d => d.id === selectedDecorId);
    const cat = DECOR_CATALOG.find(c => c.id === itemToRemove?.type);
    const updated = decorations.filter(d => d.id !== selectedDecorId);
    saveDecorations(updated);
    setSelectedDecorId(null);
    showToast(`📦 เก็บ ${cat?.nameTh || 'ของตกแต่ง'} เข้าคลังเรียบร้อย`);
  };

  // Add new item from inventory onto island
  const handlePlaceNewItem = (itemCatalog: DecorCatalogItem) => {
    // Check level unlock
    if (playerLevel < itemCatalog.unlockLevel) {
      showToast(`🔒 ต้องมีระดับ Level ${itemCatalog.unlockLevel} ขึ้นไปเพื่อปลดล็อก`);
      return;
    }

    // Check tree limit if carbon tree
    if (itemCatalog.isCarbonTree && remainingTreesToPlace <= 0) {
      showToast(`🌳 คุณใช้โควตาต้นไม้จากคาร์บอนครบแล้ว (${totalCarbonTreesEarned} ต้น) ลด CO₂ เพิ่มอีก 2.4kg เพื่อรับต้นไม้ใหม่!`);
      return;
    }

    // Find open spot on island
    const angle = Math.random() * Math.PI * 2;
    const radius = 1.5 + Math.random() * 3.5;
    const newX = Number((Math.cos(angle) * radius).toFixed(2));
    const newZ = Number((Math.sin(angle) * radius).toFixed(2));

    const newDecor: PlacedDecoration = {
      id: `decor_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      type: itemCatalog.id,
      x: newX,
      z: newZ,
      rotationY: Number((Math.random() * Math.PI * 2).toFixed(2)),
      scale: itemCatalog.defaultScale,
      placedAt: Date.now(),
    };

    const updated = [...decorations, newDecor];
    saveDecorations(updated);
    setSelectedDecorId(newDecor.id);
    showToast(`✨ วาง ${itemCatalog.nameTh} บนเกาะแล้ว! ลากเพื่อย้ายตำแหน่งได้ทันที`);
  };

  // Reset to default layout
  const handleResetToDefault = () => {
    saveDecorations(DEFAULT_ISLAND_DECORATIONS);
    setSelectedDecorId(null);
    setShowResetConfirm(false);
    showToast('🔄 รีเซ็ตการจัดวางเกาะกลับสู่ค่าเริ่มต้นเรียบร้อย');
  };

  // Player action dispatch for character animations & interaction
  const handlePlayerAction = (action: 'wave' | 'cheer' | 'sit' | 'interact') => {
    const char = charStateRef.current;
    char.idleAutonomyTimer = 0;
    char.targetPosition = null;

    if (action === 'wave') {
      char.currentAction = 'wave';
      char.actionTimer = 2.5;
      char.bubbleText = '👋';
      char.bubbleTimer = 2.5;
      if (charMeshesRef.current) {
        updateBubbleTexture(charMeshesRef.current.bubbleCanvas, charMeshesRef.current.bubbleTexture, '👋');
      }
      showToast('👋 ทักทายธรรมชาติและเพื่อน ๆ บนเกาะ!');
    } else if (action === 'cheer') {
      char.currentAction = 'cheer';
      char.actionTimer = 2.2;
      char.bubbleText = '🎉';
      char.bubbleTimer = 2.2;
      if (charMeshesRef.current) {
        updateBubbleTexture(charMeshesRef.current.bubbleCanvas, charMeshesRef.current.bubbleTexture, '🎉');
      }
      showToast('🎉 สดชื่นและมีความสุขกับพลังงานสะอาด!');
    } else if (action === 'sit') {
      if (char.currentAction === 'sit') {
        char.currentAction = 'idle';
        char.bubbleText = null;
        if (charMeshesRef.current) {
          updateBubbleTexture(charMeshesRef.current.bubbleCanvas, charMeshesRef.current.bubbleTexture, null);
        }
        showToast('🚶‍♂️ ลุกขึ้นยืนพร้อมเดินสำรวจต่อ');
      } else {
        char.currentAction = 'sit';
        char.bubbleText = '🪑';
        char.bubbleTimer = 4.0;
        if (charMeshesRef.current) {
          updateBubbleTexture(charMeshesRef.current.bubbleCanvas, charMeshesRef.current.bubbleTexture, '🪑');
        }
        showToast('🪑 นั่งพักผ่อนรับลมธรรมชาติเย็นสบาย');
      }
    } else if (action === 'interact') {
      if (nearbyInteraction) {
        if (nearbyInteraction.type === 'pet') {
          char.currentAction = 'wave';
          char.actionTimer = 2.5;
          char.bubbleText = '🐾';
          char.bubbleTimer = 2.5;
          if (charMeshesRef.current) {
            updateBubbleTexture(charMeshesRef.current.bubbleCanvas, charMeshesRef.current.bubbleTexture, '🐾');
          }
          showToast('🐾 เล่นกับน้อง Eco Pet อย่างอบอุ่นและมีความสุข!');
        } else if (nearbyInteraction.type === 'cafe') {
          char.currentAction = 'wave';
          char.actionTimer = 2.5;
          char.bubbleText = '☕';
          char.bubbleTimer = 3.0;
          if (charMeshesRef.current) {
            updateBubbleTexture(charMeshesRef.current.bubbleCanvas, charMeshesRef.current.bubbleTexture, '☕');
          }
          showToast('☕ จิบเครื่องดื่มออร์แกนิกในสวนร่มรื่น');
        } else if (nearbyInteraction.type === 'sit') {
          char.currentAction = 'sit';
          char.bubbleText = '🔥';
          char.bubbleTimer = 4.0;
          if (charMeshesRef.current) {
            updateBubbleTexture(charMeshesRef.current.bubbleCanvas, charMeshesRef.current.bubbleTexture, '🔥');
          }
          showToast('🔥 นั่งพักผ่อนข้างกองไฟแคมป์ปิ้ง');
        }
      }
    }
  };

  return (
    <div className="bg-gradient-to-b from-slate-900 via-teal-950 to-emerald-950 rounded-3xl p-3.5 text-white shadow-2xl border border-emerald-500/30 relative overflow-hidden space-y-3">
      
      {/* Top Header Bar: Mode & Time Switchers */}
      <div className="flex flex-wrap items-center justify-between gap-2 bg-black/40 backdrop-blur-md p-2 rounded-2xl border border-white/10 text-xs font-bold">
        
        {/* Left: Mode Title & Edit Island Toggle Button */}
        <div className="flex items-center gap-1.5 flex-wrap">
          <button
            onClick={() => {
              setIsEditMode(prev => !prev);
              if (!isEditMode) {
                showToast('🛠️ เข้าสู่โหมดตกแต่ง! แตะเลือกของเพื่อลาก หมุน และจัดวางได้อิสระ');
              } else {
                setSelectedDecorId(null);
                showToast('💾 บันทึกรูปแบบเกาะของคุณเรียบร้อยแล้ว!');
              }
            }}
            className={`px-3 py-1.5 rounded-xl font-black text-xs transition-all flex items-center gap-1.5 shadow-md active:scale-95 cursor-pointer ${
              isEditMode 
                ? 'bg-gradient-to-r from-amber-400 to-yellow-400 text-slate-950 border-2 border-yellow-200 animate-pulse' 
                : 'bg-gradient-to-r from-emerald-500 to-teal-400 text-slate-950 hover:from-emerald-400 hover:to-teal-300'
            }`}
          >
            {isEditMode ? (
              <>
                <Check className="w-4 h-4 text-slate-950" />
                <span>เสร็จสิ้น (Done)</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 text-slate-950" />
                <span>ตกแต่งเกาะ (Edit Island)</span>
              </>
            )}
          </button>

          {isEditMode && (
            <button
              onClick={() => setShowResetConfirm(true)}
              className="text-[11px] bg-red-950/60 hover:bg-red-900/80 text-red-300 px-2 py-1 rounded-xl border border-red-500/30 transition flex items-center gap-1 cursor-pointer"
              title="รีเซ็ตเกาะเป็นค่าเริ่มต้น"
            >
              <Undo2 className="w-3 h-3" />
              <span>รีเซ็ต</span>
            </button>
          )}
        </div>

        {/* Right: Time of Day Selector */}
        <div className="flex items-center gap-1 overflow-x-auto no-scrollbar">
          <button
            onClick={() => setTimeMode('auto')}
            className={`px-2 py-1 rounded-xl transition flex items-center gap-1 text-[11px] cursor-pointer ${
              timeMode === 'auto'
                ? 'bg-emerald-500 text-slate-950 font-extrabold'
                : 'text-slate-300 hover:bg-white/10'
            }`}
            title="เปลี่ยนตามเวลาจริง"
          >
            <Clock className="w-3 h-3" />
            <span className="hidden sm:inline">เวลาจริง</span>
          </button>

          <button
            onClick={() => setTimeMode('morning')}
            className={`p-1.5 sm:px-2 sm:py-1 rounded-xl transition flex items-center gap-1 text-[11px] cursor-pointer ${
              timeMode === 'morning' ? 'bg-amber-400 text-slate-950 font-extrabold' : 'text-amber-200 hover:bg-white/10'
            }`}
            title="เช้า (06:00 - 11:00)"
          >
            <Sunrise className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">เช้า</span>
          </button>

          <button
            onClick={() => setTimeMode('day')}
            className={`p-1.5 sm:px-2 sm:py-1 rounded-xl transition flex items-center gap-1 text-[11px] cursor-pointer ${
              timeMode === 'day' ? 'bg-sky-400 text-slate-950 font-extrabold' : 'text-sky-200 hover:bg-white/10'
            }`}
            title="กลางวัน (11:00 - 17:00)"
          >
            <Sun className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">กลางวัน</span>
          </button>

          <button
            onClick={() => setTimeMode('sunset')}
            className={`p-1.5 sm:px-2 sm:py-1 rounded-xl transition flex items-center gap-1 text-[11px] cursor-pointer ${
              timeMode === 'sunset' ? 'bg-pink-500 text-white font-extrabold' : 'text-pink-200 hover:bg-white/10'
            }`}
            title="เย็น (17:00 - 19:00)"
          >
            <Sunset className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">เย็น</span>
          </button>

          <button
            onClick={() => setTimeMode('night')}
            className={`p-1.5 sm:px-2 sm:py-1 rounded-xl transition flex items-center gap-1 text-[11px] cursor-pointer ${
              timeMode === 'night' ? 'bg-indigo-600 text-white font-extrabold' : 'text-indigo-200 hover:bg-white/10'
            }`}
            title="ค่ำ (19:00 - 06:00)"
          >
            <Moon className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">ค่ำ</span>
          </button>
        </div>

      </div>

      {/* ========================================================================= */}
      {/* 3D WEBGL CANVAS STAGE */}
      {/* ========================================================================= */}
      <div 
        className={`relative w-full rounded-2xl overflow-hidden border border-white/20 shadow-inner bg-gradient-to-b from-sky-400/20 to-teal-900/40 transition-all duration-300 ${
          isEditMode ? 'h-[360px] sm:h-[400px] ring-2 ring-amber-400/50' : 'h-[360px] sm:h-[400px]'
        }`}
      >
        {/* Three.js canvas mounts here */}
        <div ref={mountRef} className="w-full h-full cursor-grab active:cursor-grabbing" />

        {/* Top Floating Toast Message */}
        {toastMessage && (
          <div className="absolute top-2.5 left-1/2 -translate-x-1/2 bg-slate-900/90 text-brand-lime border border-brand-lime/50 px-3.5 py-1.5 rounded-full text-xs font-bold shadow-xl flex items-center gap-2 animate-bounce z-20 pointer-events-none text-center">
            <Sparkles className="w-4 h-4 text-yellow-300 shrink-0" />
            <span>{toastMessage}</span>
          </div>
        )}

        {/* Boundary Warning Banner */}
        {isBoundaryWarning && isEditMode && (
          <div className="absolute top-10 left-1/2 -translate-x-1/2 bg-amber-500/90 text-slate-950 px-3 py-1 rounded-full text-[11px] font-black shadow-lg flex items-center gap-1.5 z-20 animate-pulse pointer-events-none">
            <HelpCircle className="w-3.5 h-3.5" />
            <span>ถึงขอบเกาะแล้ว! วัตถุจะถูกตรึงไว้บนพื้นผิวเกาะอย่างปลอดภัย</span>
          </div>
        )}

        {/* Explore Mode Helper Badge */}
        {!isEditMode && !toastMessage && (
          <div className="absolute top-2.5 left-1/2 -translate-x-1/2 bg-slate-950/75 backdrop-blur-md text-emerald-300 border border-emerald-500/30 px-3 py-1 rounded-full text-[11px] font-bold shadow-md flex items-center gap-1.5 z-10 pointer-events-none whitespace-nowrap">
            <Footprints className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            <span>แตะบนเกาะ หรือใช้ปุ่มควบคุมเพื่อเดินสำรวจ</span>
          </div>
        )}

        {/* HUD: Camera Angle & Zoom & Follow Controls */}
        <div className="absolute top-2.5 left-2.5 flex flex-col gap-1.5 z-10">
          <div className="bg-black/60 backdrop-blur-md p-1 rounded-2xl border border-white/10 flex flex-col gap-1">
            <button
              onClick={() => applyCameraPreset('iso')}
              className={`p-1.5 rounded-xl text-[10px] font-bold flex items-center justify-center transition cursor-pointer ${
                cameraViewPreset === 'iso' ? 'bg-emerald-500 text-slate-950' : 'text-slate-200 hover:bg-white/10'
              }`}
              title="มุมมองเฉียง 3D (Isometric)"
            >
              <Compass className="w-3.5 h-3.5" />
            </button>

            <button
              onClick={() => applyCameraPreset('top')}
              className={`p-1.5 rounded-xl text-[10px] font-bold flex items-center justify-center transition cursor-pointer ${
                cameraViewPreset === 'top' ? 'bg-amber-400 text-slate-950' : 'text-slate-200 hover:bg-white/10'
              }`}
              title="มุมมองด้านบน (Top-Down) สำหรับจัดวางแม่นยำ"
            >
              <Layers className="w-3.5 h-3.5" />
            </button>

            <button
              onClick={() => applyCameraPreset('side')}
              className={`p-1.5 rounded-xl text-[10px] font-bold flex items-center justify-center transition cursor-pointer ${
                cameraViewPreset === 'side' ? 'bg-sky-400 text-slate-950' : 'text-slate-200 hover:bg-white/10'
              }`}
              title="มุมมองข้าง (Side Angle)"
            >
              <Eye className="w-3.5 h-3.5" />
            </button>

            {!isEditMode && (
              <button
                onClick={() => {
                  const next = !isCameraFollow;
                  setIsCameraFollow(next);
                  showToast(next ? '🎥 กล้องติดตามตัวละคร: เปิด' : '🎥 กล้องอิสระ: เปิด');
                }}
                className={`p-1.5 rounded-xl text-[10px] font-bold flex items-center justify-center transition cursor-pointer ${
                  isCameraFollow ? 'bg-teal-400 text-slate-950 font-black' : 'text-slate-300 hover:bg-white/10'
                }`}
                title={isCameraFollow ? 'กล้องกำลังติดตามตัวละคร' : 'เปิดโหมดกล้องติดตามตัวละคร'}
              >
                <Video className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          <div className="bg-black/60 backdrop-blur-md p-1 rounded-2xl border border-white/10 flex flex-col gap-1">
            <button
              onClick={() => handleZoom('in')}
              className="p-1.5 rounded-xl text-slate-200 hover:bg-white/10 transition cursor-pointer"
              title="ซูมเข้า (+)"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => handleZoom('out')}
              className="p-1.5 rounded-xl text-slate-200 hover:bg-white/10 transition cursor-pointer"
              title="ซูมออก (-)"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Live Tree & Items Counter Badge */}
        <div className="absolute top-2.5 right-2.5 bg-emerald-950/85 backdrop-blur-md px-3 py-1.5 rounded-2xl text-[11px] font-bold text-lime-300 border border-lime-400/30 flex items-center gap-1.5 shadow-lg z-10">
          <Trees className="w-3.5 h-3.5 text-emerald-400" />
          <span>บนเกาะ:</span>
          <span className="text-white bg-emerald-800 px-1.5 py-0.5 rounded-lg font-mono">
            {decorations.length} ชิ้น
          </span>
        </div>

        {/* Virtual Joystick & Explorer Action Controls in Explore Mode */}
        {!isEditMode && (
          <VirtualJoystick
            onMove={(vec) => {
              joystickVectorRef.current = vec;
            }}
            onAction={handlePlayerAction}
            nearbyInteraction={nearbyInteraction}
            disabled={isEditMode}
          />
        )}

      </div>

      {/* ========================================================================= */}
      {/* 7. SELECTED OBJECT CONTROL TOOLBAR (When in Edit Mode & Object Selected) */}
      {/* ========================================================================= */}
      {isEditMode && selectedDecor && selectedCatalogInfo && (
        <div className="bg-gradient-to-r from-slate-900 to-teal-950 rounded-2xl p-3 border-2 border-amber-400/70 shadow-xl space-y-2 animate-scale-up">
          
          <div className="flex items-center justify-between border-b border-white/10 pb-2">
            <div className="flex items-center gap-2">
              <span className="text-2xl">{selectedCatalogInfo.emoji}</span>
              <div>
                <h4 className="text-xs font-black text-white flex items-center gap-1.5">
                  <span>{selectedCatalogInfo.nameTh}</span>
                  <span className="text-[9px] bg-amber-400/30 text-amber-200 px-1.5 py-0.2 rounded font-mono">
                    ({selectedDecor.x}, {selectedDecor.z})
                  </span>
                </h4>
                <p className="text-[10px] text-emerald-200/80">กำลังเลือกปรับแต่งตำแหน่งและการหมุน</p>
              </div>
            </div>

            <div className="flex items-center gap-1">
              <button
                onClick={handleRemoveSelected}
                className="bg-red-500/20 hover:bg-red-500/30 text-red-300 border border-red-400/30 px-2.5 py-1 rounded-xl text-[10px] font-bold flex items-center gap-1 transition cursor-pointer"
                title="เก็บกลับเข้าคลังของตกแต่ง"
              >
                <Trash2 className="w-3.5 h-3.5 text-red-400" />
                <span>เก็บเข้าคลัง</span>
              </button>

              <button
                onClick={() => setSelectedDecorId(null)}
                className="text-slate-400 hover:text-white p-1 rounded-lg cursor-pointer"
                title="ยกเลิกการเลือก"
              >
                ✕
              </button>
            </div>
          </div>

          {/* Quick Action Buttons Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1">
            {/* Rotation Controls */}
            <div className="bg-white/5 rounded-xl p-2 border border-white/10 flex flex-col items-center justify-center gap-1.5">
              <span className="text-[9px] text-slate-300 font-bold uppercase">หมุนวัตถุ (Rotate)</span>
              <div className="flex gap-1.5">
                <button
                  onClick={() => handleRotateSelected(-Math.PI / 4)}
                  className="p-1.5 bg-white/10 hover:bg-white/20 rounded-lg text-emerald-300 transition active:scale-90 cursor-pointer"
                  title="หมุนซ้าย 45°"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => handleRotateSelected(Math.PI / 4)}
                  className="p-1.5 bg-white/10 hover:bg-white/20 rounded-lg text-emerald-300 transition active:scale-90 cursor-pointer"
                  title="หมุนขวา 45°"
                >
                  <RotateCw className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Scale Controls */}
            <div className="bg-white/5 rounded-xl p-2 border border-white/10 flex flex-col items-center justify-center gap-1.5">
              <span className="text-[9px] text-slate-300 font-bold uppercase">ขนาด (Scale)</span>
              <div className="flex gap-1.5">
                <button
                  onClick={() => handleScaleSelected(0.9)}
                  className="px-2 py-1 bg-white/10 hover:bg-white/20 rounded-lg text-xs font-black text-slate-200 transition active:scale-90 cursor-pointer"
                  title="ย่อขนาด"
                >
                  -
                </button>
                <span className="text-xs font-mono font-bold text-amber-300 self-center">
                  {selectedDecor.scale.toFixed(1)}x
                </span>
                <button
                  onClick={() => handleScaleSelected(1.1)}
                  className="px-2 py-1 bg-white/10 hover:bg-white/20 rounded-lg text-xs font-black text-slate-200 transition active:scale-90 cursor-pointer"
                  title="ขยายขนาด"
                >
                  +
                </button>
              </div>
            </div>

            {/* Fine D-Pad Nudge Controls */}
            <div className="col-span-2 bg-white/5 rounded-xl p-2 border border-white/10 flex items-center justify-between gap-2">
              <div className="text-left">
                <span className="text-[9px] text-slate-300 font-bold uppercase block">ขยับละเอียด (D-Pad)</span>
                <span className="text-[9px] text-emerald-200/70">กดเลื่อนทีละ 0.4 หน่วย</span>
              </div>
              <div className="grid grid-cols-3 gap-1 w-24">
                <div />
                <button
                  onClick={() => handleNudgeSelected(0, -0.4)}
                  className="p-1 bg-white/10 hover:bg-emerald-500 hover:text-slate-950 rounded flex items-center justify-center transition active:scale-90 cursor-pointer"
                  title="เลื่อนขึ้นเหนือ"
                >
                  <ArrowUp className="w-3 h-3" />
                </button>
                <div />
                <button
                  onClick={() => handleNudgeSelected(-0.4, 0)}
                  className="p-1 bg-white/10 hover:bg-emerald-500 hover:text-slate-950 rounded flex items-center justify-center transition active:scale-90 cursor-pointer"
                  title="เลื่อนซ้าย"
                >
                  <ArrowLeft className="w-3 h-3" />
                </button>
                <button
                  onClick={() => handleNudgeSelected(0, 0.4)}
                  className="p-1 bg-white/10 hover:bg-emerald-500 hover:text-slate-950 rounded flex items-center justify-center transition active:scale-90 cursor-pointer"
                  title="เลื่อนลงใต้"
                >
                  <ArrowDown className="w-3 h-3" />
                </button>
                <button
                  onClick={() => handleNudgeSelected(0.4, 0)}
                  className="p-1 bg-white/10 hover:bg-emerald-500 hover:text-slate-950 rounded flex items-center justify-center transition active:scale-90 cursor-pointer"
                  title="เลื่อนขวา"
                >
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>
            </div>
          </div>

        </div>
      )}

      {/* ========================================================================= */}
      {/* 8. INVENTORY DRAWER & DECOR CATALOG (In Edit Mode) */}
      {/* ========================================================================= */}
      {isEditMode && (
        <div className="bg-slate-900/90 rounded-2xl p-3 border border-white/10 space-y-3">
          
          {/* Inventory Category Tabs */}
          <div className="flex items-center justify-between gap-1 overflow-x-auto no-scrollbar pb-1 border-b border-white/10">
            {[
              { key: 'trees' as DecorCategory, label: 'ต้นไม้ (Trees)', icon: '🌲' },
              { key: 'nature' as DecorCategory, label: 'ธรรมชาติ (Nature)', icon: '🌺' },
              { key: 'structures' as DecorCategory, label: 'สิ่งปลูกสร้าง (Build)', icon: '🏡' },
              { key: 'clean_energy' as DecorCategory, label: 'พลังงานสะอาด (Energy)', icon: '⚡' },
              { key: 'outdoor' as DecorCategory, label: 'กลางแจ้ง (Outdoor)', icon: '🪑' },
            ].map(tab => (
              <button
                key={tab.key}
                onClick={() => setSelectedCategory(tab.key)}
                className={`px-2.5 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition flex items-center gap-1.5 cursor-pointer ${
                  selectedCategory === tab.key
                    ? 'bg-emerald-500 text-slate-950 shadow-md font-black'
                    : 'text-slate-300 hover:bg-white/10'
                }`}
              >
                <span>{tab.icon}</span>
                <span>{tab.label}</span>
              </button>
            ))}
          </div>

          {/* Special Carbon Trees Progress Banner for Trees Category */}
          {selectedCategory === 'trees' && (
            <div className="bg-emerald-950/60 p-2.5 rounded-xl border border-emerald-500/30 flex items-center justify-between text-xs">
              <div className="flex items-center gap-2">
                <Trees className="w-4 h-4 text-emerald-400" />
                <div>
                  <span className="font-bold text-white text-[11px] block">
                    ต้นไม้จากการลดคาร์บอน (ทุก 2.4 kg CO₂ = 1 ต้น)
                  </span>
                  <span className="text-[10px] text-emerald-200">
                    สะสมได้ {totalCarbonTreesEarned} ต้น • วางแล้ว {placedTreesCount} ต้น • ว่างในคลัง {remainingTreesToPlace} ต้น
                  </span>
                </div>
              </div>

              <span className="bg-brand-lime text-emerald-950 text-[10px] font-black px-2 py-0.5 rounded-md">
                ว่าง {remainingTreesToPlace} ต้น
              </span>
            </div>
          )}

          {/* Items Catalog Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-56 overflow-y-auto pr-1">
            {DECOR_CATALOG.filter(c => c.category === selectedCategory).map(item => {
              const isUnlocked = stats.level >= item.unlockLevel;
              const isCarbonTree = item.isCarbonTree;
              const canPlace = isUnlocked && (!isCarbonTree || remainingTreesToPlace > 0);

              return (
                <div
                  key={item.id}
                  className={`p-2.5 rounded-xl border transition flex flex-col justify-between gap-1.5 ${
                    isUnlocked
                      ? 'bg-white/5 border-white/15 hover:border-emerald-400/50 hover:bg-white/10'
                      : 'bg-slate-950/40 border-white/5 opacity-55'
                  }`}
                >
                  <div className="flex items-start gap-2">
                    <div className="w-9 h-9 rounded-xl bg-black/40 border border-white/10 flex items-center justify-center text-xl shrink-0">
                      {item.emoji}
                    </div>
                    <div className="min-w-0 flex-1">
                      <h5 className="text-[11px] font-extrabold text-white truncate leading-tight">
                        {item.nameTh}
                      </h5>
                      <span className="text-[9px] text-slate-400 block truncate">
                        {item.descriptionTh}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-1 border-t border-white/5">
                    {isUnlocked ? (
                      <span className="text-[9px] text-emerald-300 font-bold flex items-center gap-0.5">
                        <CheckCircle2 className="w-2.5 h-2.5 text-emerald-400" />
                        <span>Level {item.unlockLevel}</span>
                      </span>
                    ) : (
                      <span className="text-[9px] text-amber-300 font-bold flex items-center gap-0.5">
                        <Lock className="w-2.5 h-2.5 text-amber-400" />
                        <span>ปลดล็อกเมื่อ Lv.{item.unlockLevel}</span>
                      </span>
                    )}

                    <button
                      onClick={() => handlePlaceNewItem(item)}
                      disabled={!canPlace}
                      className={`px-2 py-1 rounded-lg text-[10px] font-black transition flex items-center gap-1 ${
                        canPlace
                          ? 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 cursor-pointer shadow-xs active:scale-95'
                          : 'bg-slate-700 text-slate-400 cursor-not-allowed'
                      }`}
                    >
                      <Plus className="w-3 h-3" />
                      <span>วางบนเกาะ</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

        </div>
      )}

      {/* ========================================================================= */}
      {/* 9. RESET CONFIRMATION MODAL */}
      {/* ========================================================================= */}
      {showResetConfirm && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border-2 border-red-500/50 rounded-3xl p-5 max-w-sm w-full space-y-4 text-white shadow-2xl animate-scale-up">
            <div className="w-12 h-12 rounded-2xl bg-red-500/20 text-red-400 border border-red-500/30 flex items-center justify-center text-2xl mx-auto">
              ⚠️
            </div>
            <div className="text-center space-y-1">
              <h3 className="text-base font-black">รีเซ็ตการจัดเกาะเป็นค่าเริ่มต้น?</h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                ตำแหน่งของตกแต่งทั้งหมดจะถูกจัดวางใหม่ตามโครงสร้างเริ่มต้นของ Carbon Island
              </p>
            </div>
            <div className="flex gap-2 pt-2">
              <button
                onClick={() => setShowResetConfirm(false)}
                className="flex-1 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-xl transition cursor-pointer"
              >
                ยกเลิก
              </button>
              <button
                onClick={handleResetToDefault}
                className="flex-1 py-2.5 bg-red-600 hover:bg-red-500 text-white text-xs font-black rounded-xl transition cursor-pointer shadow-md"
              >
                ยืนยันรีเซ็ต
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
