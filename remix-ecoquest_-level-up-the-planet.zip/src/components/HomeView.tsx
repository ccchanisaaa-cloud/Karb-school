import React, { useState, useEffect } from 'react';
import { 
  Star, 
  Flame, 
  Coins, 
  Trees, 
  Plus, 
  RefreshCw, 
  Trophy, 
  Heart, 
  Box, 
  MapPin, 
  Sparkles, 
  X, 
  ChevronRight, 
  Lock, 
  CheckCircle2,
  Wind,
  Thermometer,
  Cloud,
  Globe,
  TrendingDown,
  Activity,
  Award,
  ShieldCheck,
  Zap
} from 'lucide-react';
import { UserStats, Pet } from '../types';
import { getRequiredXP, getLevelUnlock, LEVEL_UNLOCKS_MAP } from '../utils/levelUtils';

interface HomeViewProps {
  stats: UserStats;
  currentPet: Pet;
  allPets: Pet[];
  onSelectPet: (id: string) => void;
  onWaterTree: (tileIndex: number) => void;
  wateredTiles: Record<number, boolean>;
}

export default function HomeView({
  stats,
  currentPet,
  allPets,
  onSelectPet,
  onWaterTree,
  wateredTiles,
}: HomeViewProps) {
  const [showLevelRoadmapModal, setShowLevelRoadmapModal] = useState(false);
  const [isRefreshingDashboard, setIsRefreshingDashboard] = useState(false);
  const [lastUpdatedTime, setLastUpdatedTime] = useState<string>('อัปเดตสดเมื่อสักครู่');

  // Simulated / Dynamic Environmental Real-Time Dashboard Data
  const [envMetrics, setEnvMetrics] = useState({
    aqi: 38,
    aqiStatus: 'อากาศบริสุทธิ์ (ดีมาก)',
    pm25: 9.4,
    globalTempAnomaly: '+1.18',
    globalCO2Ppm: 424.8,
    karbCommunityCO2: 148920 + Math.floor(stats.totalCO2),
  });

  useEffect(() => {
    // Update live timestamp
    const now = new Date();
    const timeStr = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')} น.`;
    setLastUpdatedTime(`อัปเดตล่าสุด ${timeStr}`);
  }, []);

  const handleRefreshEnvData = () => {
    setIsRefreshingDashboard(true);
    setTimeout(() => {
      const now = new Date();
      const timeStr = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')} น.`;
      setLastUpdatedTime(`อัปเดตล่าสุด ${timeStr}`);

      // Small real-time variation simulation
      setEnvMetrics({
        aqi: Math.floor(35 + Math.random() * 8),
        aqiStatus: 'อากาศบริสุทธิ์ (ดีมาก)',
        pm25: parseFloat((8.5 + Math.random() * 2).toFixed(1)),
        globalTempAnomaly: '+1.18',
        globalCO2Ppm: 424.8,
        karbCommunityCO2: 148920 + Math.floor(stats.totalCO2) + Math.floor(Math.random() * 5),
      });

      setIsRefreshingDashboard(false);
    }, 600);
  };

  const treesToday = (stats.todayCO2 / 2.4).toFixed(1);
  const requiredXP = getRequiredXP(stats.level);
  const progressPct = Math.min(100, Math.floor((stats.experience / requiredXP) * 100));

  const currentUnlock = getLevelUnlock(stats.level);
  const nextUnlock = getLevelUnlock(stats.level + 1);

  return (
    <div className="space-y-5">
      {/* Dynamic Status Header */}
      <div className="bg-gradient-to-br from-emerald-500 to-teal-600 rounded-3xl p-5 text-white shadow-xl relative overflow-hidden">
        {/* Playful Floating Circles */}
        <div className="absolute -right-6 -bottom-6 w-24 h-24 bg-white/10 rounded-full blur-xl" />
        <div className="absolute -left-4 -top-4 w-16 h-16 bg-brand-lime/20 rounded-full blur-lg" />

        <div className="flex justify-between items-start">
          <div className="space-y-1">
            <span className="text-emerald-100 text-xs font-semibold uppercase tracking-wider bg-emerald-700/40 px-3 py-1 rounded-full">
              วันนี้ในเมืองไทย
            </span>
            <div className="flex items-baseline space-x-1 mt-1">
              <h1 className="text-4xl font-extrabold tracking-tight">
                {stats.todayCO2.toFixed(1)}
              </h1>
              <span className="text-lg font-bold text-emerald-100">kg CO₂</span>
            </div>
            <p className="text-emerald-100 text-xs flex items-center gap-1">
              <Trees className="w-3.5 h-3.5 text-brand-lime" />
              เทียบเท่าคุณปลูกต้นไม้ได้ <strong className="text-brand-lime font-bold">{treesToday} ต้น</strong> วันนี้
            </p>
          </div>

          {/* Level Badge */}
          <button 
            onClick={() => setShowLevelRoadmapModal(true)}
            className="bg-brand-lime hover:bg-lime-400 text-emerald-950 font-bold px-3 py-1.5 rounded-2xl flex flex-col items-center justify-center border-b-4 border-emerald-700 shadow-md min-w-[68px] transition-transform active:scale-95 cursor-pointer group"
            title="กดเพื่อดูแผนผังปลดล็อก Level"
          >
            <span className="text-[9px] tracking-widest uppercase opacity-80 font-black">Level</span>
            <span className="text-xl leading-none font-black">{stats.level}</span>
            <span className="text-[8px] bg-emerald-900/20 text-emerald-950 px-1 rounded mt-0.5 font-extrabold group-hover:underline">Unlimited</span>
          </button>
        </div>

        {/* Level XP Bar */}
        <div className="mt-4 pt-1">
          <div className="flex justify-between text-xs font-medium text-emerald-100 mb-1">
            <span className="flex items-center gap-1">
              <Star className="w-3.5 h-3.5 text-yellow-300 fill-yellow-300 animate-pulse" />
              <span>ค่าประสบการณ์ (XP สะสมเลเวล)</span>
            </span>
            <span className="font-mono font-bold text-yellow-200">{stats.experience}/{requiredXP} XP</span>
          </div>
          <div className="w-full bg-emerald-900/40 h-3 rounded-full overflow-hidden p-0.5 border border-emerald-400/20">
            <div
              className="bg-gradient-to-r from-brand-lime to-yellow-300 h-full rounded-full transition-all duration-500 shadow-sm"
              style={{ width: `${progressPct}%` }}
            />
          </div>
          
          <div className="flex items-center justify-between text-[10px] text-emerald-100/90 mt-1.5">
            <span className="flex items-center gap-1">
              <span>{currentUnlock.icon}</span>
              <span>เลเวลปัจจุบัน: {currentUnlock.unlockedItem}</span>
            </span>
            <button
              onClick={() => setShowLevelRoadmapModal(true)}
              className="font-bold underline text-yellow-200 hover:text-white flex items-center gap-0.5"
            >
              <span>แผนผังปลดล็อก 3D</span>
              <ChevronRight className="w-3 h-3" />
            </button>
          </div>
        </div>

        {/* Mini Counters Stats Footer inside card */}
        <div className="grid grid-cols-3 gap-1.5 mt-4 pt-3 border-t border-emerald-400/30 text-center text-xs">
          <div className="bg-emerald-900/20 py-1.5 px-2 rounded-xl">
            <div className="font-semibold text-brand-lime flex items-center justify-center gap-1">
              <Coins className="w-3 h-3" />
              <span>{stats.coins}</span>
            </div>
            <div className="text-[10px] text-emerald-100">เหรียญสะสม</div>
          </div>

          <div className="bg-emerald-900/20 py-1.5 px-2 rounded-xl">
            <div className="font-semibold text-sky-300 flex items-center justify-center gap-1">
              <Trees className="w-3 h-3" />
              <span>{stats.treesPlanted} ต้น</span>
            </div>
            <div className="text-[10px] text-emerald-100">ปลูกแล้วทั้งหมด</div>
          </div>

          <div className="bg-emerald-900/20 py-1.5 px-2 rounded-xl">
            <div className="font-semibold text-orange-300 flex items-center justify-center gap-1">
              <Flame className="w-3 h-3 text-brand-orange animate-pulse" />
              <span>{stats.streak} วัน</span>
            </div>
            <div className="text-[10px] text-emerald-100 font-medium">ต่อเนื่องดิ๊!</div>
          </div>
        </div>
      </div>

      {/* Next Level Unlock Preview Banner */}
      <div 
        onClick={() => setShowLevelRoadmapModal(true)}
        className="bg-slate-900 text-white p-3.5 rounded-2xl flex items-center justify-between border border-slate-800 shadow-sm cursor-pointer hover:border-emerald-500/50 transition-colors"
      >
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 bg-emerald-500/20 rounded-xl flex items-center justify-center text-xl shrink-0 border border-emerald-500/30">
            {nextUnlock.icon}
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-[9px] font-black uppercase text-brand-lime bg-emerald-950 px-2 py-0.5 rounded-md border border-emerald-800">
                NEXT UNLOCK LEVEL {stats.level + 1}
              </span>
              <span className="text-[10px] text-slate-400 font-mono">(ต้องการ {getRequiredXP(stats.level + 1)} XP)</span>
            </div>
            <h4 className="text-xs font-bold text-white mt-0.5">{nextUnlock.unlockedItem}</h4>
          </div>
        </div>
        <ChevronRight className="w-4 h-4 text-slate-400" />
      </div>

      {/* ========================================================================= */}
      {/* ENVIRONMENTAL AWARENESS DASHBOARD (แดชบอร์ดสร้างความตระหนักรู้ด้านสิ่งแวดล้อม) */}
      {/* ========================================================================= */}
      <div className="bg-gradient-to-br from-white via-emerald-50/40 to-sky-50/50 rounded-3xl p-5 border border-emerald-200/80 shadow-md space-y-4 relative overflow-hidden">
        
        {/* Subtle decorative background circles */}
        <div className="absolute top-0 right-0 w-32 h-32 bg-sky-400/10 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-32 h-32 bg-emerald-400/10 rounded-full blur-2xl pointer-events-none" />

        {/* Dashboard Header Ticker */}
        <div className="flex items-center justify-between gap-2 relative z-10">
          <div>
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping" />
              <span className="text-[10px] font-black uppercase tracking-wider text-emerald-800 bg-emerald-100 px-2.5 py-0.5 rounded-full flex items-center gap-1">
                <Globe className="w-3 h-3 text-emerald-600" />
                REAL-TIME ENVIRONMENTAL DATA
              </span>
            </div>
            <h3 className="text-base font-black text-slate-900 mt-1 flex items-center gap-1.5">
              <span className="text-xl">🌍</span>
              <span>แดชบอร์ดความตระหนักรู้ด้านสิ่งแวดล้อม</span>
            </h3>
          </div>

          <button
            onClick={handleRefreshEnvData}
            disabled={isRefreshingDashboard}
            className="p-2 rounded-2xl bg-white border border-slate-200 text-slate-600 hover:text-emerald-700 hover:border-emerald-300 shadow-sm transition-all active:scale-95 shrink-0 flex items-center gap-1 text-[11px] font-bold"
            title="อัปเดตข้อมูลสิ่งแวดล้อมเรียลไทม์"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRefreshingDashboard ? 'animate-spin text-emerald-600' : ''}`} />
            <span className="hidden sm:inline">รีเฟรช</span>
          </button>
        </div>

        {/* Inspirational Motto Card Banner */}
        <div className="bg-gradient-to-r from-teal-700 via-emerald-800 to-sky-800 text-white rounded-2xl p-4 shadow-sm relative overflow-hidden">
          <div className="absolute -right-4 -bottom-4 text-6xl opacity-20 pointer-events-none">🌿</div>
          <div className="flex items-start gap-3 relative z-10">
            <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center text-2xl shrink-0 shadow-inner">
              🌱
            </div>
            <div>
              <h4 className="text-xs font-black text-brand-lime uppercase tracking-wider">
                สร้างโลกที่ดีกว่าเริ่มต้นที่ตัวเรา
              </h4>
              <p className="text-xs font-extrabold text-white mt-0.5 leading-snug">
                “ทุกการกระทำของคุณช่วยให้โลกดีขึ้น – เริ่มจากวันนี้ เพื่อโลกที่ดีขึ้นในวันพรุ่งนี้”
              </p>
              <span className="text-[10px] text-emerald-200/90 mt-1 block font-mono">
                {lastUpdatedTime} (ข้อมูลอัปเดตความตระหนักรู้สิ่งแวดล้อม)
              </span>
            </div>
          </div>
        </div>

        {/* 4 Core Environmental Infographics Grid */}
        <div className="grid grid-cols-2 gap-3 relative z-10">
          
          {/* 1. Air Quality Index (AQI) */}
          <div className="bg-white rounded-2xl p-3.5 border border-sky-100 shadow-sm hover:shadow-md transition-shadow relative overflow-hidden group">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold text-slate-500 uppercase flex items-center gap-1">
                <Wind className="w-3 h-3 text-sky-500" />
                คุณภาพอากาศ (AQI)
              </span>
              <span className="text-xs font-black bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full">
                ดีมาก
              </span>
            </div>
            
            <div className="mt-2 flex items-baseline gap-1.5">
              <span className="text-2xl font-black text-slate-900">{envMetrics.aqi}</span>
              <span className="text-xs font-bold text-slate-500">AQI</span>
              <span className="text-xl ml-auto">🌤️</span>
            </div>

            <div className="mt-1.5 pt-2 border-t border-slate-100 flex justify-between text-[10px] text-slate-500">
              <span>PM 2.5: <strong className="text-slate-700">{envMetrics.pm25} µg/m³</strong></span>
              <span className="text-emerald-600 font-bold">ปลอดภัย</span>
            </div>
          </div>

          {/* 2. Global Temperature Anomaly */}
          <div className="bg-white rounded-2xl p-3.5 border border-emerald-100 shadow-sm hover:shadow-md transition-shadow relative overflow-hidden group">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold text-slate-500 uppercase flex items-center gap-1">
                <Thermometer className="w-3 h-3 text-amber-500" />
                อุณหภูมิโลก
              </span>
              <span className="text-xs font-black bg-amber-100 text-amber-900 px-2 py-0.5 rounded-full">
                วิกฤตความร้อน
              </span>
            </div>

            <div className="mt-2 flex items-baseline gap-1.5">
              <span className="text-2xl font-black text-slate-900">{envMetrics.globalTempAnomaly}°C</span>
              <span className="text-[10px] text-slate-500">เบี่ยงเบน</span>
              <span className="text-xl ml-auto">🌡️</span>
            </div>

            <div className="mt-1.5 pt-2 border-t border-slate-100 flex justify-between text-[10px] text-slate-500">
              <span>เทียบยุคก่อนอุตสาหกรรม</span>
              <span className="text-amber-600 font-bold">เร่งลด CO₂!</span>
            </div>
          </div>

          {/* 3. Global Atmospheric CO2 */}
          <div className="bg-white rounded-2xl p-3.5 border border-teal-100 shadow-sm hover:shadow-md transition-shadow relative overflow-hidden group">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold text-slate-500 uppercase flex items-center gap-1">
                <Cloud className="w-3 h-3 text-teal-600" />
                คาร์บอนชั้นบรรยากาศ
              </span>
              <span className="text-xs font-black bg-teal-100 text-teal-900 px-2 py-0.5 rounded-full">
                2026 Live
              </span>
            </div>

            <div className="mt-2 flex items-baseline gap-1.5">
              <span className="text-2xl font-black text-slate-900">{envMetrics.globalCO2Ppm}</span>
              <span className="text-xs font-bold text-slate-500">ppm</span>
              <span className="text-xl ml-auto">🏭</span>
            </div>

            <div className="mt-1.5 pt-2 border-t border-slate-100 flex justify-between text-[10px] text-slate-500">
              <span>ความเข้มข้นคาร์บอนรวม</span>
              <span className="text-teal-700 font-bold">เป้าหมาย &lt; 350</span>
            </div>
          </div>

          {/* 4. Total KARB Community Saved CO2 */}
          <div className="bg-gradient-to-br from-emerald-500 to-teal-700 text-white rounded-2xl p-3.5 shadow-sm relative overflow-hidden group">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold text-emerald-100 uppercase flex items-center gap-1">
                <TrendingDown className="w-3 h-3 text-brand-lime" />
                ชุมชน KARB ช่วยลด
              </span>
              <span className="text-[9px] font-black bg-brand-lime text-emerald-950 px-2 py-0.5 rounded-full">
                รวมพลังผู้ใช้
              </span>
            </div>

            <div className="mt-2 flex items-baseline gap-1">
              <span className="text-xl font-black text-white">{envMetrics.karbCommunityCO2.toLocaleString()}</span>
              <span className="text-[10px] font-bold text-emerald-200">kg</span>
              <span className="text-xl ml-auto">🌳</span>
            </div>

            <div className="mt-1.5 pt-2 border-t border-emerald-400/30 flex justify-between text-[10px] text-emerald-100">
              <span>เทียบเท่าปลูกต้นไม้</span>
              <strong className="text-brand-lime">{(envMetrics.karbCommunityCO2 / 2.4).toFixed(0)} ต้น</strong>
            </div>
          </div>

        </div>

        {/* Dynamic Eco Insight Card */}
        <div className="bg-sky-50/80 border border-sky-200/60 rounded-2xl p-3 flex items-center gap-3 relative z-10">
          <div className="w-9 h-9 rounded-xl bg-sky-500 text-white flex items-center justify-center text-lg shrink-0 shadow-sm">
            💡
          </div>
          <div className="flex-1 min-w-0">
            <h5 className="text-xs font-bold text-slate-800">เกร็ดความรู้สู้ภัยโลกร้อนประจำวัน</h5>
            <p className="text-[10px] text-slate-600 leading-tight mt-0.5">
              การเลือกรับประทานอาหารหมดจาน 1 มื้อ สามารถช่วยลดการเกิดขยะอาหารและ CO₂ ได้ถึง 2.4 kg ซึ่งเทียบเท่ากับการปลูกต้นไม้ 1 ต้นเต็ม!
            </p>
          </div>
        </div>

      </div>

      {/* Pet Interactive Card */}
      <div className="bg-gradient-to-r from-teal-50 to-emerald-50 rounded-3xl p-5 border border-emerald-100 flex flex-col md:flex-row items-center gap-4 relative overflow-hidden shadow-sm">
        <div className="absolute top-2 right-3 text-[10px] font-bold text-emerald-800/60 bg-emerald-800/10 px-2 py-0.5 rounded-full flex items-center gap-1">
          <Heart className="w-2.5 h-2.5 text-brand-coral animate-pulse" />
          <span>บัดดี้คู่หูลุกซ์</span>
        </div>

        {/* Left: Beautiful floating Pet Avatar Grid */}
        <div className="flex flex-col items-center justify-center p-3.5 bg-white/80 rounded-2xl border border-emerald-200/50 shadow-inner relative">
          <div className="text-5xl floating-pet relative p-2 select-none">
            {currentPet.imageUrl}
            <div className="absolute -bottom-1 -right-1 bg-yellow-300 text-slate-800 text-[10px] px-1 font-extrabold rounded-full border border-white">
              Lv.{stats.level}
            </div>
          </div>
          <div className="mt-2 text-center">
            <span className="text-xs font-bold text-emerald-950 block">{currentPet.nameTh}</span>
            <span className="text-[9px] text-emerald-700/60 font-mono uppercase tracking-wider block">
              {currentPet.species}
            </span>
          </div>
        </div>

        {/* Right: Dialogue Box & Pet Selection */}
        <div className="flex-1 space-y-3 w-full">
          {/* Quote Speech bubble */}
          <div className="bg-white/90 rounded-2xl p-3 border border-emerald-100 text-xs text-slate-700 relative shadow-sm">
            <div className="absolute left-4 -bottom-1.5 w-3 h-3 bg-white border-b border-r border-emerald-100 rotate-45" />
            <p className="italic leading-relaxed font-medium">"{currentPet.quoteTh}"</p>
          </div>

          {/* Growth meters & selectors */}
          <div className="space-y-2">
            <div>
              <div className="flex justify-between text-[10px] text-slate-500 mb-0.5 font-bold">
                <span>ความสนิทสนมบัดดี้ (Streak Boost)</span>
                <span>{currentPet.currentProgress}%</span>
              </div>
              <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden p-0.5">
                <div
                  className="bg-brand-coral h-full rounded-full transition-all duration-500"
                  style={{ width: `${currentPet.currentProgress}%` }}
                />
              </div>
            </div>

            {/* Select Quick Alternate Pets */}
            <div className="flex items-center gap-2 pt-1">
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block">บัดดี้ของคุณ:</span>
              <div className="flex gap-1.5">
                {allPets.map((p) => (
                  <button
                    key={p.id}
                    onClick={() => onSelectPet(p.id)}
                    className={`text-xl p-1.5 rounded-xl border transition-all ${
                      currentPet.id === p.id
                        ? 'bg-yellow-100 border-yellow-400 scale-110 shadow-sm'
                        : 'bg-white border-slate-200 opacity-60 hover:opacity-100'
                    }`}
                    title={p.nameTh}
                  >
                    {p.imageUrl}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Level Unlocks Roadmap Modal Overlay */}
      {showLevelRoadmapModal && (
        <div className="fixed inset-0 bg-slate-900/80 backdrop-blur-md z-50 flex flex-col items-center justify-center p-4 animate-scale-up">
          <div className="bg-white rounded-3xl w-full max-w-md max-h-[85vh] flex flex-col shadow-2xl border-4 border-emerald-500 overflow-hidden">
            
            {/* Modal Header */}
            <div className="bg-gradient-to-r from-emerald-600 to-teal-700 text-white p-4 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2">
                <div className="bg-brand-lime text-emerald-950 p-2 rounded-xl text-xl font-black">
                  🗺️
                </div>
                <div>
                  <h3 className="text-base font-extrabold text-white">แผนผังการปลดล็อก (Level Unlocks)</h3>
                  <p className="text-[10px] text-emerald-100">
                    ปลดล็อกตกแต่ง 3D & Eco Pet ตามระดับเลเวล (Unlimited Levels)
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowLevelRoadmapModal(false)}
                className="w-8 h-8 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Current Level Banner */}
            <div className="bg-emerald-50 p-3 border-b border-emerald-100 flex items-center justify-between text-xs font-bold text-emerald-950 shrink-0">
              <div className="flex items-center gap-2">
                <Star className="w-4 h-4 text-yellow-500 fill-yellow-500 animate-bounce" />
                <span>ระดับของคุณปัจจุบัน: <strong>Level {stats.level}</strong></span>
              </div>
              <span className="text-[10px] bg-emerald-200/80 text-emerald-900 px-2 py-0.5 rounded-full font-mono">
                XP: {stats.experience} / {requiredXP}
              </span>
            </div>

            {/* Level List Scrollable Body */}
            <div className="p-4 overflow-y-auto space-y-3 flex-1">
              {Array.from({ length: Math.max(10, stats.level + 2) }).map((_, index) => {
                const lvl = index + 1;
                const unlock = getLevelUnlock(lvl);
                const reqXP = getRequiredXP(lvl);
                const isUnlocked = stats.level >= lvl;
                const isCurrent = stats.level === lvl;

                return (
                  <div
                    key={lvl}
                    className={`rounded-2xl p-3.5 border transition-all flex items-center gap-3 relative ${
                      isCurrent
                        ? 'bg-amber-50 border-amber-400 shadow-md ring-2 ring-amber-300'
                        : isUnlocked
                        ? 'bg-emerald-50/70 border-emerald-200'
                        : 'bg-slate-50 border-slate-200 opacity-75'
                    }`}
                  >
                    {/* Icon & Level Badge */}
                    <div className="flex flex-col items-center justify-center shrink-0">
                      <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-2xl border shadow-sm ${
                        isCurrent
                          ? 'bg-amber-200 border-amber-400'
                          : isUnlocked
                          ? 'bg-emerald-200 border-emerald-300'
                          : 'bg-slate-200 border-slate-300 text-slate-400'
                      }`}>
                        {unlock.icon}
                      </div>
                      <span className="text-[10px] font-black text-slate-600 mt-1">
                        Level {lvl}
                      </span>
                    </div>

                    {/* Content Details */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <h4 className={`text-xs font-extrabold truncate ${
                          isCurrent ? 'text-amber-950' : isUnlocked ? 'text-emerald-950' : 'text-slate-700'
                        }`}>
                          {unlock.unlockedItem}
                        </h4>
                        
                        {isCurrent ? (
                          <span className="text-[9px] font-black bg-amber-400 text-amber-950 px-2 py-0.2 rounded-md animate-pulse">
                            กำลังสะสม ⭐
                          </span>
                        ) : isUnlocked ? (
                          <span className="text-[9px] font-extrabold text-emerald-700 bg-emerald-100 px-1.5 py-0.2 rounded-md flex items-center gap-0.5">
                            <CheckCircle2 className="w-2.5 h-2.5 text-emerald-600" />
                            ปลดล็อกแล้ว
                          </span>
                        ) : (
                          <span className="text-[9px] font-bold text-slate-500 bg-slate-200 px-1.5 py-0.2 rounded-md flex items-center gap-0.5">
                            <Lock className="w-2.5 h-2.5 text-slate-400" />
                            {reqXP} XP
                          </span>
                        )}
                      </div>

                      <p className="text-[10px] text-slate-500 mt-0.5 leading-snug">
                        {unlock.description}
                      </p>

                      <div className="text-[9px] font-mono text-slate-400 mt-1">
                        เกณฑ์ XP เพื่อปลดล็อก: {reqXP} XP
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Modal Footer button */}
            <div className="p-3 bg-slate-50 border-t border-slate-200 shrink-0">
              <button
                onClick={() => setShowLevelRoadmapModal(false)}
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs py-3 rounded-2xl transition-colors shadow-sm"
              >
                เข้าใจแล้ว ไปลุยเก็บ XP เลเวลอัปกันเลย! 🚀
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}


