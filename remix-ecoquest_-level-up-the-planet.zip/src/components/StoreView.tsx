import { useState } from 'react';
import { Coins, ShoppingBag, ShieldCheck, Ticket, Calendar, Search, Copy, Check, ExternalLink } from 'lucide-react';
import { PartnerReward } from '../types';

interface StoreViewProps {
  userCoins: number;
  rewards: PartnerReward[];
  onRedeemReward: (rewardId: string, coinCost: number) => void;
  onShowNotification: (title: string, body: string, icon: string) => void;
}

export default function StoreView({
  userCoins,
  rewards,
  onRedeemReward,
  onShowNotification,
}: StoreViewProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [showCouponModal, setShowCouponModal] = useState<PartnerReward | null>(null);
  const [copiedRewardId, setCopiedRewardId] = useState<string | null>(null);

  const categories = [
    { id: 'all', label: 'ทั้งหมด' },
    { id: 'drink', label: 'เครื่องดื่ม' },
    { id: 'food', label: 'อาหารรักษ์โลก' },
    { id: 'service', label: 'บริการสีเขียว' },
    { id: 'snack', label: 'ของที่ระลึก' }
  ];

  const filteredRewards = rewards
    .filter(reward => selectedCategory === 'all' || reward.category === selectedCategory)
    .filter(reward => {
      const matchText = reward.title.toLowerCase() + reward.partnerName.toLowerCase() + reward.description.toLowerCase();
      return matchText.includes(searchQuery.toLowerCase());
    });

  const handleRedeemClick = (reward: PartnerReward) => {
    if (userCoins < reward.coinCost) {
      alert("ยอดเหรียญสะสมของคุณไม่เพียงพอ! มาลุยทำภารกิจลดโลกเรื่อยๆ เพื่อเก็บสะสมเสมอนะครับ 💚");
      return;
    }
    // Perform transaction
    onRedeemReward(reward.id, reward.coinCost);
    setShowCouponModal(reward);
    
    onShowNotification(
      "แลกรางวัลสำเร็จ! 🛍️",
      `ปลดล็อกสิทธิ์คุ้กกี้ ${reward.title} แล้ว กรุณานำคูปองไปแสดงที่รวงร้านพาร์ทเนอร์ครับ`,
      "🎉"
    );
  };

  const handleCopyCode = (code: string, id: string) => {
    navigator.clipboard.writeText(code);
    setCopiedRewardId(id);
    setTimeout(() => {
      setCopiedRewardId(null);
    }, 2000);
  };

  return (
    <div className="space-y-4">
      {/* Search and Filters */}
      <div className="bg-white rounded-2xl p-3 border border-slate-200/80 shadow-sm space-y-3">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="ค้นหาชื่อรางวัลหรือแบรนด์พันธมิตร..."
            className="w-full bg-slate-50 rounded-xl pl-9 pr-4 py-2 border border-slate-200 text-xs focus:ring-1 focus:ring-amber-400 focus:outline-none"
          />
        </div>

        {/* Categories slider */}
        <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-3 py-1 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                selectedCategory === cat.id
                  ? 'bg-amber-100 text-amber-800 border border-amber-300'
                  : 'bg-slate-50 text-slate-600 hover:bg-slate-100 border border-transparent'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Rewards Grid cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {filteredRewards.map((reward) => {
          const isAffordable = userCoins >= reward.coinCost;
          return (
            <div
              key={reward.id}
              className="bg-white rounded-2xl border border-slate-200/80 shadow-sm relative overflow-hidden flex flex-col justify-between group hover:border-amber-300 transition-all"
            >
              {/* Card info top body */}
              <div className="p-4 flex gap-3.5 items-start">
                <div className="text-4xl p-3.5 rounded-2xl bg-amber-50 border border-amber-200/40 select-none shadow-sm flex items-center justify-center shrink-0">
                  {reward.imageUrl}
                </div>

                <div className="space-y-1 flex-1 min-w-0">
                  <span className="text-[10px] font-bold text-slate-400 block tracking-wide uppercase">
                    {reward.partnerName}
                  </span>
                  <h4 className="text-xs font-extrabold text-slate-900 leading-snug group-hover:text-amber-600 truncate">
                    {reward.title}
                  </h4>
                  <p className="text-[10px] text-slate-500 leading-normal line-clamp-2">
                    {reward.description}
                  </p>
                </div>
              </div>

              {/* Purchase bar Bottom */}
              <div className="p-2.5 px-3 border-t border-slate-100 flex items-center justify-between bg-slate-50/50">
                <div className="flex items-center gap-1">
                  <Coins className="w-3.5 h-3.5 text-amber-500" />
                  <span className="text-xs font-black text-slate-700">{reward.coinCost}</span>
                  <span className="text-[9px] text-slate-400">เหรียญ</span>
                </div>

                <button
                  onClick={() => handleRedeemClick(reward)}
                  className={`text-[10px] font-extrabold py-1.5 px-3.5 rounded-xl transition-all shadow-[0_3px_0_#9a3412] active:translate-y-0.5 active:shadow-[0_1px_0_#9a3412] ${
                    isAffordable
                      ? 'bg-brand-orange text-white hover:bg-orange-600'
                      : 'bg-slate-200 text-slate-400 cursor-not-allowed shadow-none active:translate-y-0'
                  }`}
                >
                  {isAffordable ? 'แลกส่วนลดเลย' : 'เหรียญไม่พอ'}
                </button>
              </div>

              {/* Hot partner icon badge */}
              <div className="absolute top-2 right-2 bg-emerald-50 text-emerald-800 text-[8px] font-bold px-1.5 py-0.5 rounded-full flex items-center gap-0.5 border border-emerald-200">
                <ShieldCheck className="w-2.5 h-2.5" />
                <span>Verified Partner</span>
              </div>
            </div>
          );
        })}

        {filteredRewards.length === 0 && (
          <div className="col-span-full py-8 text-center text-slate-400 text-xs">
            😢 ไม่พบรางวัลหรือพาร์ทเนอร์ในหมวดหมู่นี้ ลองค้นคำอื่นดูนะครับน้า
          </div>
        )}
      </div>

      {/* Coupon Modal popup for code reveal */}
      {showCouponModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-white rounded-3xl p-6 max-w-sm w-full border-4 border-amber-400 shadow-2xl relative space-y-4 text-center">
            
            {/* Title / Celebration layout */}
            <div className="space-y-1">
              <div className="text-5xl animate-bounce mb-2">✨🛍️🎉</div>
              <h3 className="text-lg font-black text-slate-900">ปลดล็อกคูปองพาร์ทเนอร์สำเร็จ!</h3>
              <p className="text-xs text-emerald-600 font-extrabold flex items-center justify-center gap-1">
                <ShieldCheck className="w-4 h-4" />
                <span>อนุมัติความดีรักษ์โลกผ่านแคมเปญ เรียบร้อย</span>
              </p>
            </div>

            {/* Code presentation card */}
            <div className="bg-amber-50 rounded-2xl p-4 border border-amber-200 space-y-2">
              <span className="text-[10px] text-amber-800 font-semibold uppercase tracking-wider block">
                {showCouponModal.partnerName}
              </span>
              <h4 className="text-sm font-bold text-slate-800 leading-snug">{showCouponModal.title}</h4>
              
              {/* Big copyable Code Block */}
              <div className="bg-white rounded-xl border border-amber-300 p-3 mt-1.5 flex items-center justify-between">
                <span className="font-mono text-base font-black px-2 py-0.5 text-slate-800 select-all tracking-wider">
                  {showCouponModal.promoCode}
                </span>

                <button
                  onClick={() => handleCopyCode(showCouponModal.promoCode, showCouponModal.id)}
                  className="p-2 rounded-lg bg-amber-100 hover:bg-amber-200 text-amber-950 transition-all flex items-center gap-1 text-[10px] font-bold"
                >
                  {copiedRewardId === showCouponModal.id ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-600" />
                      <span>คัดลอกแล้ว!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>คัดลอกโค้ด</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            <p className="text-[10px] text-slate-500 leading-normal">
              *แสดงหน้าจอนี้แก่พนักงานพาร์เนอร์ที่เคาน์เตอร์ของร้านค้า Coffee & Green Partner เพื่อตรวจสอบเพื่อรับสิทธิแลกบริการ
            </p>

            <button
              onClick={() => setShowCouponModal(null)}
              className="w-full bg-slate-900 text-white font-extrabold py-3.5 rounded-2xl text-xs hover:bg-slate-800 transition-all shadow-md"
            >
              เข้าใจแล้วปิดหน้าต่างขยะ
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
