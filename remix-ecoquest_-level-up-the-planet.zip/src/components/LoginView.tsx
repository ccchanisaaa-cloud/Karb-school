import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Mail, 
  Lock, 
  Eye, 
  EyeOff, 
  User, 
  ArrowRight, 
  Sparkles, 
  ShieldCheck, 
  Leaf, 
  KeyRound, 
  CheckCircle2, 
  AlertCircle,
  Zap,
  Globe2
} from 'lucide-react';
import { 
  loginWithEmail, 
  registerWithEmail, 
  resetPassword, 
  loginWithGoogle, 
  ensureAuth 
} from '../services/firebaseService';

interface LoginViewProps {
  onLoginSuccess: (userDisplayName?: string) => void;
}

export default function LoginView({ onLoginSuccess }: LoginViewProps) {
  const [mode, setMode] = useState<'login' | 'register' | 'forgot'>('login');
  
  // Form states
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  
  // Feedback states
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  const handleEmailLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      setErrorMsg('กรุณากรอกอีเมลและรหัสผ่านให้ครบถ้วน');
      return;
    }
    setLoading(true);
    setErrorMsg('');
    setSuccessMsg('');
    try {
      const user = await loginWithEmail(email, password);
      setSuccessMsg('เข้าสู่ระบบสำเร็จกำลังนำท่านเข้าสู่แอป...');
      setTimeout(() => {
        onLoginSuccess(user.displayName || email.split('@')[0]);
      }, 600);
    } catch (err: any) {
      console.error(err);
      if (err.code === 'auth/invalid-credential' || err.code === 'auth/user-not-found' || err.code === 'auth/wrong-password') {
        setErrorMsg('อีเมลหรือรหัสผ่านไม่ถูกต้อง');
      } else if (err.code === 'auth/invalid-email') {
        setErrorMsg('รูปแบบอีเมลไม่ถูกต้อง');
      } else {
        setErrorMsg('เกิดข้อผิดพลาด: ' + (err.message || 'ไม่สามารถเข้าสู่ระบบได้'));
      }
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      setErrorMsg('กรุณากรอกอีเมลและรหัสผ่าน');
      return;
    }
    if (password.length < 6) {
      setErrorMsg('รหัสผ่านต้องมีความยาวอย่างน้อย 6 ตัวอักษร');
      return;
    }
    setLoading(true);
    setErrorMsg('');
    setSuccessMsg('');
    try {
      const user = await registerWithEmail(email, password, name || 'Eco Hero');
      setSuccessMsg('ลงทะเบียนสำเร็จ! ยินดีต้อนรับสู่ KARB');
      setTimeout(() => {
        onLoginSuccess(name || user.displayName || email.split('@')[0]);
      }, 600);
    } catch (err: any) {
      console.error(err);
      if (err.code === 'auth/email-already-in-use') {
        setErrorMsg('อีเมลนี้ถูกใช้งานไปแล้วในระบบ');
      } else {
        setErrorMsg('สมัครสมาชิกไม่สำเร็จ: ' + (err.message || 'โปรดลองอีกครั้ง'));
      }
    } finally {
      setLoading(false);
    }
  };

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) {
      setErrorMsg('กรุณากรอกอีเมลที่ใช้ลงทะเบียน');
      return;
    }
    setLoading(true);
    setErrorMsg('');
    setSuccessMsg('');
    try {
      await resetPassword(email);
      setSuccessMsg('ส่งลิงก์ตั้งรหัสผ่านใหม่ไปยังอีเมลของคุณเรียบร้อยแล้ว!');
    } catch (err: any) {
      console.error(err);
      setErrorMsg('ไม่สามารถส่งอีเมลได้: ' + (err.message || 'กรุณาตรวจสอบอีเมล'));
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleAuth = async () => {
    setLoading(true);
    setErrorMsg('');
    try {
      const user = await loginWithGoogle();
      setSuccessMsg('เข้าสู่ระบบด้วย Google สำเร็จ!');
      setTimeout(() => {
        onLoginSuccess(user.displayName || 'Google User');
      }, 500);
    } catch (err: any) {
      console.error(err);
      setErrorMsg('ไม่สามารถเข้าสู่ระบบด้วย Google ได้ (สามารถทดลองใช้ทางเลือกลองใช้งานแบบด่วนได้)');
    } finally {
      setLoading(false);
    }
  };

  const handleQuickGuest = async () => {
    setLoading(true);
    setErrorMsg('');
    try {
      const user = await ensureAuth();
      setSuccessMsg('เข้าสู่ระบบแบบด่วนสำเร็จ!');
      setTimeout(() => {
        onLoginSuccess('Guest นิสิตนักศึกษา');
      }, 400);
    } catch (err: any) {
      console.error(err);
      setErrorMsg('เกิดข้อผิดพลาดในการเชื่อมต่อ');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="relative min-h-[640px] w-full bg-gradient-to-b from-sky-400 via-emerald-400 to-teal-600 rounded-3xl overflow-hidden shadow-2xl flex flex-col justify-between p-4 sm:p-6 text-white font-sans border-4 border-white/20">
      
      {/* Background Animated Nature Graphic elements (3D Floating Island aesthetic) */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {/* Animated Sky Clouds */}
        <motion.div 
          animate={{ x: [-20, 30, -20] }}
          transition={{ duration: 12, repeat: Infinity, ease: "easeInOut" }}
          className="absolute top-4 left-6 opacity-80"
        >
          <div className="bg-white/80 backdrop-blur-sm rounded-full w-24 h-8 relative shadow-lg">
            <div className="bg-white/90 rounded-full w-10 h-10 absolute -top-4 left-3" />
            <div className="bg-white/90 rounded-full w-12 h-12 absolute -top-5 left-8" />
          </div>
        </motion.div>

        <motion.div 
          animate={{ x: [30, -10, 30] }}
          transition={{ duration: 16, repeat: Infinity, ease: "easeInOut" }}
          className="absolute top-12 right-8 opacity-70"
        >
          <div className="bg-white/70 backdrop-blur-sm rounded-full w-20 h-7 relative shadow-md">
            <div className="bg-white/80 rounded-full w-8 h-8 absolute -top-3 left-4" />
          </div>
        </motion.div>

        {/* Floating Sun Rays */}
        <div className="absolute top-0 right-0 w-72 h-72 bg-yellow-200/20 rounded-full blur-3xl pointer-events-none" />

        {/* Gentle Leaves Floating */}
        <motion.div
          animate={{ y: [0, 15, 0], rotate: [0, 10, -5, 0] }}
          transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
          className="absolute bottom-20 left-4 text-emerald-200/40"
        >
          <Leaf className="w-12 h-12" />
        </motion.div>
      </div>

      {/* Header Area: KARB Brand, Slogan, and 3D Island Mascot */}
      <div className="relative z-10 pt-2 text-center flex flex-col items-center">
        {/* Brand Logo & Name */}
        <motion.div 
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="flex items-center gap-2 bg-emerald-900/30 backdrop-blur-md px-4 py-1.5 rounded-full border border-white/30 shadow-lg mb-2"
        >
          <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-lime-400 to-emerald-300 flex items-center justify-center text-emerald-950 font-black shadow-inner">
            🌱
          </div>
          <span className="text-2xl font-black tracking-wider text-white drop-shadow-md">
            KARB
          </span>
          <span className="bg-lime-400 text-emerald-950 text-[10px] font-extrabold px-2 py-0.5 rounded-full">
            ECO APP
          </span>
        </motion.div>

        {/* Mascot Mascot Card & Speech Bubble */}
        <div className="relative my-2 flex items-center justify-center">
          {/* Mascot Speech Bubble */}
          <motion.div 
            animate={{ y: [0, -3, 0] }}
            transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}
            className="absolute -top-7 bg-white text-emerald-900 text-xs font-bold px-3 py-1 rounded-2xl shadow-lg border border-emerald-200 flex items-center gap-1 z-20 whitespace-nowrap"
          >
            <Sparkles className="w-3 h-3 text-amber-500 fill-amber-400" />
            <span>ทุกการกระทำเล็ก ๆ เปลี่ยนโลกได้! ✨</span>
            <div className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 border-x-4 border-x-transparent border-t-6 border-t-white" />
          </motion.div>

          {/* 3D Green Island Graphic Avatar */}
          <motion.div 
            animate={{ y: [0, -5, 0] }}
            transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
            className="w-20 h-20 rounded-full bg-gradient-to-b from-lime-300 via-emerald-500 to-teal-700 p-1 shadow-xl relative border-2 border-white/50 flex items-center justify-center overflow-hidden"
          >
            {/* Island Base */}
            <div className="text-4xl filter drop-shadow-md select-none">
              🦕
            </div>
            {/* Blinking eyes badge */}
            <div className="absolute bottom-1 bg-emerald-900/80 text-lime-300 text-[9px] font-extrabold px-2 py-0.5 rounded-full border border-lime-400/40">
              Lv.1 Eco Pet
            </div>
          </motion.div>
        </div>

        {/* Application Slogan */}
        <p className="text-xs font-semibold text-sky-100 drop-shadow-sm max-w-xs">
          “Small Actions, Big Impact.” – เปลี่ยนไลฟ์สไตล์ให้เป็นพลังกู้โลก
        </p>
      </div>

      {/* Main Login Card Container */}
      <motion.div 
        layout
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.4 }}
        className="relative z-10 my-3 bg-white/95 backdrop-blur-xl text-slate-800 rounded-3xl p-5 shadow-2xl border border-white/60"
      >
        {/* Error / Success Feedback Banner */}
        <AnimatePresence mode="wait">
          {errorMsg && (
            <motion.div 
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="mb-3 p-2.5 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl text-xs flex items-center gap-2 font-medium"
            >
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-500" />
              <span>{errorMsg}</span>
            </motion.div>
          )}

          {successMsg && (
            <motion.div 
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="mb-3 p-2.5 bg-emerald-50 border border-emerald-200 text-emerald-700 rounded-xl text-xs flex items-center gap-2 font-medium"
            >
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-500" />
              <span>{successMsg}</span>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Tab Headers Mode */}
        {mode !== 'forgot' && (
          <div className="flex bg-slate-100 p-1 rounded-2xl mb-4 text-xs font-bold border border-slate-200">
            <button
              onClick={() => { setMode('login'); setErrorMsg(''); setSuccessMsg(''); }}
              className={`flex-1 py-2 rounded-xl transition-all duration-200 text-center ${
                mode === 'login' 
                  ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-md' 
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              เข้าสู่ระบบ (Log In)
            </button>
            <button
              onClick={() => { setMode('register'); setErrorMsg(''); setSuccessMsg(''); }}
              className={`flex-1 py-2 rounded-xl transition-all duration-200 text-center ${
                mode === 'register' 
                  ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-md' 
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              สมัครสมาชิก (Sign Up)
            </button>
          </div>
        )}

        {/* FORGOT PASSWORD FORM */}
        {mode === 'forgot' && (
          <form onSubmit={handleForgotPassword} className="space-y-3">
            <div className="flex items-center justify-between mb-1">
              <h3 className="font-bold text-slate-800 text-sm flex items-center gap-1.5">
                <KeyRound className="w-4 h-4 text-emerald-600" />
                <span>กู้คืนรหัสผ่าน (Reset Password)</span>
              </h3>
            </div>
            <p className="text-xs text-slate-500">
              กรอกอีเมลของคุณเพื่อรับลิงก์สำหรับตั้งรหัสผ่านใหม่ผ่าน Firebase
            </p>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">อีเมลของคุณ</label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="student@university.ac.th"
                  className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white"
                  required
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-bold rounded-xl text-xs shadow-md transition-all flex items-center justify-center gap-2"
            >
              {loading ? (
                <span className="inline-block w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <>
                  <span>ส่งลิงก์ตั้งรหัสผ่าน</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>

            <button
              type="button"
              onClick={() => { setMode('login'); setErrorMsg(''); setSuccessMsg(''); }}
              className="w-full text-center text-xs text-emerald-600 hover:underline font-semibold pt-1"
            >
              ← กลับไปหน้าเข้าสู่ระบบ
            </button>
          </form>
        )}

        {/* LOGIN FORM */}
        {mode === 'login' && (
          <form onSubmit={handleEmailLogin} className="space-y-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">อีเมล (Email)</label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="karb.hero@gmail.com"
                  className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white"
                  required
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="text-xs font-bold text-slate-700">รหัสผ่าน (Password)</label>
                <button
                  type="button"
                  onClick={() => setMode('forgot')}
                  className="text-[11px] text-emerald-600 hover:underline font-semibold"
                >
                  ลืมรหัสผ่าน?
                </button>
              </div>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-9 pr-9 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-bold rounded-xl text-xs shadow-lg shadow-emerald-600/30 transition-all flex items-center justify-center gap-2 active:scale-98"
            >
              {loading ? (
                <span className="inline-block w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <>
                  <span>เข้าสู่ระบบ (Log In)</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>
        )}

        {/* REGISTER FORM */}
        {mode === 'register' && (
          <form onSubmit={handleRegister} className="space-y-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">ชื่อผู้ใช้งาน (Display Name)</label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="นิสิต สายกรีน"
                  className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">อีเมล (Email)</label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="karb.hero@gmail.com"
                  className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">สร้างรหัสผ่าน (Password)</label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="อย่างน้อย 6 ตัวอักษร"
                  className="w-full pl-9 pr-9 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-bold rounded-xl text-xs shadow-lg shadow-emerald-600/30 transition-all flex items-center justify-center gap-2 active:scale-98"
            >
              {loading ? (
                <span className="inline-block w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <>
                  <span>สร้างบัญชี KARB</span>
                  <Sparkles className="w-4 h-4 text-yellow-300 fill-yellow-300" />
                </>
              )}
            </button>
          </form>
        )}

        {/* Divider & Alternative Sign in options */}
        {mode !== 'forgot' && (
          <div className="mt-4 pt-3 border-t border-slate-100">
            <div className="relative flex justify-center text-[10px] uppercase font-bold text-slate-400 mb-3">
              <span className="bg-white px-2">หรือเข้าใช้งานด้วย</span>
            </div>

            <div className="grid grid-cols-2 gap-2">
              {/* Google Sign In */}
              <button
                type="button"
                onClick={handleGoogleAuth}
                disabled={loading}
                className="py-2 px-3 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-xl text-slate-700 text-xs font-bold flex items-center justify-center gap-2 transition"
              >
                <svg className="w-4 h-4" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/>
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/>
                </svg>
                <span>Google</span>
              </button>

              {/* Guest One-Tap Access */}
              <button
                type="button"
                onClick={handleQuickGuest}
                disabled={loading}
                className="py-2 px-3 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-xl text-emerald-800 text-xs font-bold flex items-center justify-center gap-1.5 transition"
              >
                <Zap className="w-3.5 h-3.5 text-amber-500 fill-amber-400" />
                <span>ทดลองใช้งานด่วน</span>
              </button>
            </div>
          </div>
        )}
      </motion.div>

      {/* Footer Features summary */}
      <div className="relative z-10 text-center text-white/90 text-[11px] font-medium flex items-center justify-center gap-4 pt-1">
        <span className="flex items-center gap-1">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-200" />
          <span>Firebase Cloud Sync</span>
        </span>
        <span className="flex items-center gap-1">
          <Globe2 className="w-3.5 h-3.5 text-sky-200" />
          <span>KARB Community</span>
        </span>
      </div>

    </div>
  );
}
