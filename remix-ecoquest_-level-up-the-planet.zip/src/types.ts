export interface DailyAction {
  id: string;
  nameTh: string;
  shortLabelTh?: string;
  emoji?: string;
  nameEn: string;
  baseCO2: number; // in kg
  coinReward: number;
  category: 'food' | 'transport' | 'appliance' | 'household' | 'reusable';
  iconName: string; // Lucide icon mapping name
  detailsTh: string;
  proofNeeded: boolean;
  colorClass: string; // Tailwind background color gradient block
}

export interface Pet {
  id: string;
  nameTh: string;
  nameEn: string;
  stage: 'egg' | 'baby' | 'teen' | 'adult';
  minStreak: number;
  imageUrl: string; // Or a beautiful CSS emoji representative
  currentProgress: number; // 0 to 100
  species: string;
  quoteTh: string;
}

export interface PartnerReward {
  id: string;
  title: string;
  partnerName: string;
  description: string;
  coinCost: number;
  promoCode: string;
  category: 'drink' | 'food' | 'service' | 'snack';
  imageUrl: string;
  redeemedCount: number;
}

export interface ProofPhoto {
  id: string;
  date: string;
  actionId: string;
  actionNameTh: string;
  imgUrl: string;
  caption: string;
  verified: boolean;
  coinsEarned: number;
  co2Saved: number;
}

export interface UserStats {
  todayCO2: number; // in kg
  totalCO2: number; // in kg
  todayCoins?: number; // daily earned coins (max 100 per day)
  coins: number;
  streak: number;
  level: number;
  experience: number; // 0 to 100 for current level
  treesPlanted: number;
  petId: string;
  avatarUrl?: string;
  displayName?: string;
  userIdCode?: string;
  completedActionsCount?: number;
  islandDecorations?: PlacedDecoration[];
}

export type DecorCategory = 'trees' | 'nature' | 'structures' | 'clean_energy' | 'outdoor';

export type DecorItemType = 
  | 'tree_pine' 
  | 'tree_oak' 
  | 'tree_palm' 
  | 'tree_sakura' 
  | 'tree_golden'
  | 'flowers_wild' 
  | 'flowers_sunflower' 
  | 'flowers_lavender'
  | 'heart_bush'
  | 'round_bush'
  | 'face_rock'
  | 'tree_stump'
  | 'rock_boulder' 
  | 'rock_zen' 
  | 'fairy_house'
  | 'mushroom_house'
  | 'treehouse' 
  | 'camping_tent'
  | 'wooden_bridge' 
  | 'curved_bridge'
  | 'small_pond' 
  | 'waterfall_bluff' 
  | 'mini_windmill'
  | 'wind_turbine' 
  | 'solar_panel' 
  | 'cozy_lantern'
  | 'solar_lamp'
  | 'picnic_table'
  | 'wooden_signpost'
  | 'park_bench' 
  | 'recycle_bins'
  | 'eco_bicycle'
  | 'eco_campfire'
  | 'eco_fountain'
  | 'lotus_pond'
  | 'tree_string_lights'
  | 'hanging_lantern'
  | 'stepping_stones'
  | 'flower_pot'
  | 'veggie_patch'
  | 'cute_mailbox'
  | 'mini_cafe';

export interface PlacedDecoration {
  id: string;
  type: DecorItemType;
  x: number;
  z: number;
  rotationY: number; // in radians or degrees
  scale: number;
  placedAt?: number;
}

export interface DecorCatalogItem {
  id: DecorItemType;
  nameTh: string;
  nameEn: string;
  category: DecorCategory;
  unlockLevel: number;
  emoji: string;
  descriptionTh: string;
  isCarbonTree?: boolean;
  defaultScale: number;
  radius: number;
}

export interface Friend {
  id: string;
  name: string;
  userIdCode: string;
  avatar: string; // Emoji or image URL
  avatarType: 'emoji' | 'url';
  level: number;
  totalCO2: number;
  completedActions: number;
  status: 'online' | 'offline';
  joinedDate: string;
}

export interface FriendRequest {
  id: string;
  fromName: string;
  fromUserIdCode: string;
  fromAvatar: string;
  fromLevel: number;
  timestamp: string;
}

