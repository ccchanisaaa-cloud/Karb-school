import * as THREE from 'three';
import { DecorItemType } from '../types';

// ============================================================================
// SHARED COLOR PALETTE & MATERIALS (Pastel, Cozy, Soft 3D Aesthetic)
// ============================================================================
const pastelWoodMat = new THREE.MeshStandardMaterial({ color: 0xb45309, roughness: 0.7, flatShading: true });
const lightWoodMat = new THREE.MeshStandardMaterial({ color: 0xd97706, roughness: 0.75, flatShading: true });
const darkWoodMat = new THREE.MeshStandardMaterial({ color: 0x78350f, roughness: 0.8, flatShading: true });
const smoothStoneMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, roughness: 0.6, flatShading: true });
const creamWallMat = new THREE.MeshStandardMaterial({ color: 0xfef3c7, roughness: 0.5, flatShading: true });
const pastelPinkMat = new THREE.MeshStandardMaterial({ color: 0xf472b6, roughness: 0.5, flatShading: true });
const pastelRedMat = new THREE.MeshStandardMaterial({ color: 0xef4444, roughness: 0.4, flatShading: true });
const pastelMintMat = new THREE.MeshStandardMaterial({ color: 0x34d399, roughness: 0.4, flatShading: true });
const pastelTealMat = new THREE.MeshStandardMaterial({ color: 0x2dd4bf, roughness: 0.4, flatShading: true });
const pastelYellowMat = new THREE.MeshStandardMaterial({ color: 0xfde047, roughness: 0.3, flatShading: true });
const whiteMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.3, flatShading: true });
const blackEyeMat = new THREE.MeshBasicMaterial({ color: 0x0f172a });
const blushMat = new THREE.MeshBasicMaterial({ color: 0xf472b6 });
const waterMat = new THREE.MeshStandardMaterial({ color: 0x38bdf8, roughness: 0.1, metalness: 0.2, transparent: true, opacity: 0.85 });

/**
 * Creates a cute 3D Group mesh for any decoration type in the Cozy Fantasy style
 */
export function createDecorMesh(type: DecorItemType, isNight: boolean = false): THREE.Group {
  const group = new THREE.Group();

  switch (type) {
    // =======================================================================
    // 1. TREES (Fluffy, Rounded, Pastel, Stylized)
    // =======================================================================
    case 'tree_pine': {
      // Rounded wood trunk
      const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.26, 1.4, 8), pastelWoodMat);
      trunk.position.y = 0.7;
      trunk.castShadow = true;
      group.add(trunk);

      // 3 Stacked Fluffy Rounded Pine Cones (Soft Greens)
      const pineColors = [0x15803d, 0x16a34a, 0x4ade80];
      [0, 1, 2].forEach((layer) => {
        const cone = new THREE.Mesh(
          new THREE.ConeGeometry(1.2 - layer * 0.28, 1.2 - layer * 0.2, 8),
          new THREE.MeshStandardMaterial({ color: pineColors[layer], roughness: 0.6, flatShading: true })
        );
        cone.position.y = 1.4 + layer * 0.7;
        cone.castShadow = true;
        group.add(cone);

        // Small snow / dew droplet on top
        if (layer === 2) {
          const tip = new THREE.Mesh(new THREE.SphereGeometry(0.16, 8, 8), pastelYellowMat);
          tip.position.y = 2.9;
          group.add(tip);
        }
      });
      break;
    }

    case 'tree_oak': {
      // Oak trunk
      const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.36, 1.5, 8), pastelWoodMat);
      trunk.position.y = 0.75;
      trunk.castShadow = true;
      group.add(trunk);

      // Fluffy Cloud Puffs Canopy (Multiple overlapping spheres)
      const leafMat = new THREE.MeshStandardMaterial({ color: 0x22c55e, roughness: 0.6, flatShading: true });
      const leafMat2 = new THREE.MeshStandardMaterial({ color: 0x4ade80, roughness: 0.6, flatShading: true });

      const puffs = [
        { x: 0, y: 2.2, z: 0, r: 1.1, mat: leafMat },
        { x: 0.5, y: 2.4, z: 0.4, r: 0.75, mat: leafMat2 },
        { x: -0.5, y: 2.3, z: -0.3, r: 0.7, mat: leafMat2 },
        { x: 0.2, y: 2.8, z: -0.2, r: 0.7, mat: leafMat },
      ];

      puffs.forEach(p => {
        const puff = new THREE.Mesh(new THREE.DodecahedronGeometry(p.r, 1), p.mat);
        puff.position.set(p.x, p.y, p.z);
        puff.castShadow = true;
        group.add(puff);
      });
      break;
    }

    case 'tree_palm': {
      // Curving trunk segments
      const palmTrunk = new THREE.Group();
      for (let i = 0; i < 4; i++) {
        const seg = new THREE.Mesh(new THREE.CylinderGeometry(0.18 - i * 0.02, 0.22 - i * 0.02, 0.6, 7), pastelWoodMat);
        seg.position.set(Math.sin(i * 0.3) * 0.25, 0.3 + i * 0.55, 0);
        seg.rotation.z = -0.12 * i;
        seg.castShadow = true;
        palmTrunk.add(seg);
      }
      group.add(palmTrunk);

      // Coconuts
      const cocoMat = new THREE.MeshStandardMaterial({ color: 0x78350f, roughness: 0.8 });
      for (let i = 0; i < 3; i++) {
        const coco = new THREE.Mesh(new THREE.SphereGeometry(0.16, 8, 8), cocoMat);
        const a = (i * Math.PI * 2) / 3;
        coco.position.set(0.6 + Math.cos(a) * 0.2, 2.2, Math.sin(a) * 0.2);
        group.add(coco);
      }

      // Curved Palm Fronds
      const frondMat = new THREE.MeshStandardMaterial({ color: 0x4ade80, roughness: 0.5, flatShading: true });
      for (let i = 0; i < 5; i++) {
        const frond = new THREE.Group();
        frond.position.set(0.6, 2.35, 0);
        frond.rotation.y = (i * Math.PI * 2) / 5;

        const leaf = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.05, 0.38), frondMat);
        leaf.position.set(0.7, 0, 0);
        leaf.rotation.z = -0.35;
        leaf.castShadow = true;
        frond.add(leaf);
        group.add(frond);
      }
      break;
    }

    case 'tree_sakura': {
      // Dark trunk
      const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.32, 1.6, 7), darkWoodMat);
      trunk.position.y = 0.8;
      trunk.castShadow = true;
      group.add(trunk);

      // Fluffy Pastel Pink Cloud Canopy
      const sakuraMat1 = new THREE.MeshStandardMaterial({ color: 0xf472b6, roughness: 0.5, flatShading: true });
      const sakuraMat2 = new THREE.MeshStandardMaterial({ color: 0xfbcfe8, roughness: 0.5, flatShading: true });

      const sakuraPuffs = [
        { x: 0, y: 2.3, z: 0, r: 1.15, mat: sakuraMat1 },
        { x: 0.6, y: 2.5, z: 0.4, r: 0.75, mat: sakuraMat2 },
        { x: -0.5, y: 2.4, z: -0.3, r: 0.8, mat: sakuraMat2 },
        { x: 0.1, y: 2.9, z: -0.2, r: 0.7, mat: sakuraMat1 },
      ];

      sakuraPuffs.forEach(p => {
        const puff = new THREE.Mesh(new THREE.DodecahedronGeometry(p.r, 1), p.mat);
        puff.position.set(p.x, p.y, p.z);
        puff.castShadow = true;
        group.add(puff);
      });
      break;
    }

    case 'tree_golden': {
      // Golden shimmering trunk
      const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.35, 1.8, 8), new THREE.MeshStandardMaterial({ color: 0xd97706, roughness: 0.3, metalness: 0.6 }));
      trunk.position.y = 0.9;
      trunk.castShadow = true;
      group.add(trunk);

      const goldFoliageMat = new THREE.MeshStandardMaterial({
        color: 0xfde047,
        roughness: 0.2,
        metalness: 0.5,
        emissive: 0xb45309,
        emissiveIntensity: 0.3,
        flatShading: true,
      });

      const crown = new THREE.Mesh(new THREE.DodecahedronGeometry(1.35, 1), goldFoliageMat);
      crown.position.y = 2.5;
      crown.castShadow = true;
      group.add(crown);

      // Little golden star on top
      const star = new THREE.Mesh(new THREE.OctahedronGeometry(0.25, 0), new THREE.MeshBasicMaterial({ color: 0xffffff }));
      star.position.y = 3.9;
      group.add(star);
      break;
    }

    // =======================================================================
    // 2. NATURE & CUTE FLORA
    // =======================================================================
    case 'flowers_wild': {
      // Pastel Wildflowers patch
      const colors = [0xf43f5e, 0xfbbf24, 0xec4899, 0xa855f7, 0x38bdf8];
      for (let i = 0; i < 5; i++) {
        const fGroup = new THREE.Group();
        const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.45, 5), new THREE.MeshStandardMaterial({ color: 0x22c55e }));
        stem.position.y = 0.22;
        fGroup.add(stem);

        const flowerHead = new THREE.Mesh(new THREE.SphereGeometry(0.14, 8, 8), new THREE.MeshStandardMaterial({ color: colors[i % colors.length], roughness: 0.3 }));
        flowerHead.position.y = 0.45;
        fGroup.add(flowerHead);

        const yellowCenter = new THREE.Mesh(new THREE.SphereGeometry(0.06, 6, 6), pastelYellowMat);
        yellowCenter.position.set(0, 0.47, 0.08);
        fGroup.add(yellowCenter);

        fGroup.position.set((Math.random() - 0.5) * 0.7, 0, (Math.random() - 0.5) * 0.7);
        group.add(fGroup);
      }
      break;
    }

    case 'flowers_sunflower': {
      for (let i = 0; i < 3; i++) {
        const sfGroup = new THREE.Group();
        const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.05, 0.8, 6), new THREE.MeshStandardMaterial({ color: 0x16a34a }));
        stem.position.y = 0.4;
        sfGroup.add(stem);

        // Petals ring
        const petalDisc = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.32, 0.06, 12), pastelYellowMat);
        petalDisc.position.set(0, 0.82, 0.05);
        petalDisc.rotation.x = Math.PI / 2.3;
        sfGroup.add(petalDisc);

        // Brown smiley center
        const center = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.16, 0.08, 8), darkWoodMat);
        center.position.set(0, 0.83, 0.08);
        center.rotation.x = Math.PI / 2.3;
        sfGroup.add(center);

        sfGroup.position.set((i - 1) * 0.38, 0, (Math.random() - 0.5) * 0.3);
        group.add(sfGroup);
      }
      break;
    }

    case 'flowers_lavender': {
      const lavMat = new THREE.MeshStandardMaterial({ color: 0xa855f7, roughness: 0.5, flatShading: true });
      for (let i = 0; i < 6; i++) {
        const lav = new THREE.Mesh(new THREE.ConeGeometry(0.1, 0.65, 6), lavMat);
        lav.position.set((Math.random() - 0.5) * 0.6, 0.32, (Math.random() - 0.5) * 0.6);
        group.add(lav);
      }
      break;
    }

    case 'heart_bush': {
      // Cute Heart Shaped Topiary Bush
      const heartMat = new THREE.MeshStandardMaterial({ color: 0x10b981, roughness: 0.5, flatShading: true });
      
      const leftLobe = new THREE.Mesh(new THREE.SphereGeometry(0.45, 12, 12), heartMat);
      leftLobe.position.set(-0.25, 0.65, 0);
      leftLobe.castShadow = true;
      group.add(leftLobe);

      const rightLobe = new THREE.Mesh(new THREE.SphereGeometry(0.45, 12, 12), heartMat);
      rightLobe.position.set(0.25, 0.65, 0);
      rightLobe.castShadow = true;
      group.add(rightLobe);

      const bottomCone = new THREE.Mesh(new THREE.ConeGeometry(0.58, 0.7, 8), heartMat);
      bottomCone.position.set(0, 0.45, 0);
      bottomCone.rotation.x = Math.PI;
      bottomCone.castShadow = true;
      group.add(bottomCone);

      // Cute little flower hairpin on top
      const flowerPin = new THREE.Mesh(new THREE.SphereGeometry(0.1, 6, 6), pastelPinkMat);
      flowerPin.position.set(0.35, 0.95, 0.2);
      group.add(flowerPin);
      break;
    }

    case 'round_bush': {
      // Rounded multi-bubble bush with sweet red berries
      const bushMat = new THREE.MeshStandardMaterial({ color: 0x4ade80, roughness: 0.6, flatShading: true });
      
      const centerBubble = new THREE.Mesh(new THREE.SphereGeometry(0.55, 10, 10), bushMat);
      centerBubble.position.y = 0.5;
      centerBubble.castShadow = true;
      group.add(centerBubble);

      const sideBubble1 = new THREE.Mesh(new THREE.SphereGeometry(0.35, 8, 8), bushMat);
      sideBubble1.position.set(0.4, 0.35, 0.2);
      group.add(sideBubble1);

      const sideBubble2 = new THREE.Mesh(new THREE.SphereGeometry(0.38, 8, 8), bushMat);
      sideBubble2.position.set(-0.38, 0.35, -0.15);
      group.add(sideBubble2);

      // Sweet red berries
      const berryMat = new THREE.MeshStandardMaterial({ color: 0xef4444, roughness: 0.2 });
      [
        { x: 0.2, y: 0.7, z: 0.4 },
        { x: -0.25, y: 0.6, z: 0.35 },
        { x: 0.35, y: 0.45, z: 0.38 },
      ].forEach(bp => {
        const berry = new THREE.Mesh(new THREE.SphereGeometry(0.07, 6, 6), berryMat);
        berry.position.set(bp.x, bp.y, bp.z);
        group.add(berry);
      });
      break;
    }

    case 'face_rock': {
      // Cute smiling friendly rock pebble
      const rockMesh = new THREE.Mesh(new THREE.DodecahedronGeometry(0.75, 1), smoothStoneMat);
      rockMesh.position.y = 0.48;
      rockMesh.scale.set(1.1, 0.9, 0.9);
      rockMesh.castShadow = true;
      group.add(rockMesh);

      // Two cute big glossy black eyes
      [-0.18, 0.18].forEach(x => {
        const eye = new THREE.Mesh(new THREE.SphereGeometry(0.08, 8, 8), blackEyeMat);
        eye.position.set(x, 0.55, 0.62);
        group.add(eye);

        // Catchlight twinkle
        const catchlight = new THREE.Mesh(new THREE.SphereGeometry(0.025, 4, 4), whiteMat);
        catchlight.position.set(x + 0.02, 0.58, 0.68);
        group.add(catchlight);
      });

      // Pink blush cheeks
      [-0.28, 0.28].forEach(x => {
        const blush = new THREE.Mesh(new THREE.SphereGeometry(0.06, 6, 6), blushMat);
        blush.position.set(x, 0.45, 0.58);
        group.add(blush);
      });

      // Tiny green sprout on rock head!
      const sprout = new THREE.Mesh(new THREE.ConeGeometry(0.08, 0.25, 5), new THREE.MeshStandardMaterial({ color: 0x4ade80 }));
      sprout.position.set(0, 0.98, 0);
      sprout.rotation.z = -0.2;
      group.add(sprout);
      break;
    }

    case 'tree_stump': {
      // Tree Stump with rings & cute side mushrooms
      const stump = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.65, 0.55, 12), pastelWoodMat);
      stump.position.y = 0.28;
      stump.castShadow = true;
      group.add(stump);

      // Top Ring surface
      const ringTop = new THREE.Mesh(new THREE.CylinderGeometry(0.52, 0.52, 0.05, 12), lightWoodMat);
      ringTop.position.y = 0.56;
      group.add(ringTop);

      // Little Red Mushroom sprouting on the side
      const mushStem = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.06, 0.25, 6), whiteMat);
      mushStem.position.set(0.48, 0.25, 0.2);
      mushStem.rotation.z = -0.3;
      group.add(mushStem);

      const mushCap = new THREE.Mesh(new THREE.SphereGeometry(0.12, 8, 8), pastelRedMat);
      mushCap.position.set(0.55, 0.38, 0.2);
      group.add(mushCap);
      break;
    }

    case 'rock_boulder': {
      const rockGeo = new THREE.DodecahedronGeometry(0.8, 1);
      const rock = new THREE.Mesh(rockGeo, smoothStoneMat);
      rock.position.y = 0.48;
      rock.castShadow = true;
      group.add(rock);

      const smallRock = new THREE.Mesh(new THREE.DodecahedronGeometry(0.4, 0), smoothStoneMat);
      smallRock.position.set(0.55, 0.25, 0.3);
      smallRock.castShadow = true;
      group.add(smallRock);
      break;
    }

    case 'rock_zen': {
      const sandDisc = new THREE.Mesh(new THREE.CylinderGeometry(0.95, 0.95, 0.06, 16), new THREE.MeshStandardMaterial({ color: 0xfef08a, roughness: 0.8 }));
      sandDisc.position.y = 0.03;
      group.add(sandDisc);

      const botPebble = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.65, 0.25, 8), smoothStoneMat);
      botPebble.position.y = 0.15;
      botPebble.castShadow = true;
      group.add(botPebble);

      const midPebble = new THREE.Mesh(new THREE.CylinderGeometry(0.38, 0.45, 0.2, 8), smoothStoneMat);
      midPebble.position.y = 0.34;
      midPebble.castShadow = true;
      group.add(midPebble);

      const topPebble = new THREE.Mesh(new THREE.SphereGeometry(0.22, 8, 8), new THREE.MeshStandardMaterial({ color: 0xcfd8dc }));
      topPebble.position.y = 0.52;
      topPebble.castShadow = true;
      group.add(topPebble);
      break;
    }

    case 'lotus_pond': {
      const pad = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.55, 0.03, 12), new THREE.MeshStandardMaterial({ color: 0x16a34a, roughness: 0.4 }));
      pad.position.y = 0.02;
      group.add(pad);

      const lotus = new THREE.Mesh(new THREE.ConeGeometry(0.18, 0.35, 6), pastelPinkMat);
      lotus.position.set(0, 0.18, 0);
      group.add(lotus);
      break;
    }

    // =======================================================================
    // 3. CUTE STRUCTURES & FANTASY HOUSES
    // =======================================================================
    case 'fairy_house': {
      // Cream-colored rounded cottage base
      const cottageBody = new THREE.Mesh(new THREE.CylinderGeometry(0.9, 1.0, 1.2, 12), creamWallMat);
      cottageBody.position.y = 0.6;
      cottageBody.castShadow = true;
      group.add(cottageBody);

      // Curved Fantasy Roof (Pastel Mint / Turquoise)
      const roof = new THREE.Mesh(new THREE.ConeGeometry(1.3, 1.3, 12), new THREE.MeshStandardMaterial({ color: 0x0ea5e9, roughness: 0.4, flatShading: true }));
      roof.position.y = 1.8;
      roof.castShadow = true;
      group.add(roof);

      // Chimney with soft smoke puff
      const chimney = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.15, 0.6, 6), smoothStoneMat);
      chimney.position.set(0.45, 2.0, 0.2);
      group.add(chimney);

      const smokePuff = new THREE.Mesh(new THREE.SphereGeometry(0.16, 6, 6), new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.8 }));
      smokePuff.position.set(0.45, 2.4, 0.2);
      group.add(smokePuff);

      // Round Wooden Door with golden knob
      const door = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.3, 0.06, 10), pastelWoodMat);
      door.position.set(0, 0.4, 0.95);
      door.rotation.x = Math.PI / 2;
      group.add(door);

      const doorknob = new THREE.Mesh(new THREE.SphereGeometry(0.04, 6, 6), pastelYellowMat);
      doorknob.position.set(0.15, 0.4, 0.99);
      group.add(doorknob);

      // Cozy glowing round window
      const windowMesh = new THREE.Mesh(
        new THREE.CylinderGeometry(0.2, 0.2, 0.05, 8),
        new THREE.MeshBasicMaterial({ color: isNight ? 0xfde047 : 0xffffff })
      );
      windowMesh.position.set(0.65, 0.75, 0.65);
      windowMesh.rotation.x = Math.PI / 2;
      windowMesh.rotation.z = -Math.PI / 4;
      group.add(windowMesh);
      break;
    }

    case 'mushroom_house': {
      // White/Cream Stalk Base
      const stalk = new THREE.Mesh(new THREE.CylinderGeometry(0.7, 0.85, 1.1, 12), creamWallMat);
      stalk.position.y = 0.55;
      stalk.castShadow = true;
      group.add(stalk);

      // Big Vibrant Red Mushroom Dome Roof
      const mushRoof = new THREE.Mesh(new THREE.SphereGeometry(1.2, 16, 12, 0, Math.PI * 2, 0, Math.PI * 0.55), pastelRedMat);
      mushRoof.position.y = 1.1;
      mushRoof.castShadow = true;
      group.add(mushRoof);

      // White Polka Dots on the Mushroom Roof
      const dotGeo = new THREE.CylinderGeometry(0.16, 0.16, 0.04, 8);
      [
        { x: 0, y: 2.1, z: 0.4, rx: 0.4, rz: 0 },
        { x: 0.6, y: 1.8, z: 0.6, rx: 0.5, rz: -0.4 },
        { x: -0.6, y: 1.8, z: 0.6, rx: 0.5, rz: 0.4 },
        { x: 0.8, y: 1.6, z: -0.3, rx: -0.3, rz: -0.6 },
        { x: -0.8, y: 1.6, z: -0.3, rx: -0.3, rz: 0.6 },
      ].forEach(dp => {
        const dot = new THREE.Mesh(dotGeo, whiteMat);
        dot.position.set(dp.x, dp.y, dp.z);
        dot.rotation.x = dp.rx;
        dot.rotation.z = dp.rz;
        group.add(dot);
      });

      // Arched Little Door
      const door = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.6, 0.08), pastelWoodMat);
      door.position.set(0, 0.35, 0.8);
      group.add(door);
      break;
    }

    case 'treehouse': {
      // Main trunk
      const houseTrunk = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.75, 2.6, 8), pastelWoodMat);
      houseTrunk.position.y = 1.3;
      houseTrunk.castShadow = true;
      group.add(houseTrunk);

      // Cozy Cabin box
      const cabin = new THREE.Mesh(new THREE.BoxGeometry(1.6, 1.2, 1.6), lightWoodMat);
      cabin.position.set(0, 2.7, 0);
      cabin.castShadow = true;
      group.add(cabin);

      // Cute Pink/Red Pitch Roof
      const roof = new THREE.Mesh(new THREE.ConeGeometry(1.4, 0.9, 4), new THREE.MeshStandardMaterial({ color: 0xf43f5e, roughness: 0.5, flatShading: true }));
      roof.position.set(0, 3.7, 0);
      roof.rotation.y = Math.PI / 4;
      roof.castShadow = true;
      group.add(roof);

      // Fluffy Tree Foliage canopy around it
      const foliage = new THREE.Mesh(new THREE.DodecahedronGeometry(1.6, 1), new THREE.MeshStandardMaterial({ color: 0x22c55e, roughness: 0.6, flatShading: true }));
      foliage.position.set(0, 4.3, -0.3);
      foliage.castShadow = true;
      group.add(foliage);
      break;
    }

    case 'camping_tent': {
      // A-Frame Pastel Tent
      const tentGeo = new THREE.ConeGeometry(1.1, 1.4, 3);
      const tentMat = new THREE.MeshStandardMaterial({ color: 0xf97316, roughness: 0.5, flatShading: true });
      const tent = new THREE.Mesh(tentGeo, tentMat);
      tent.position.y = 0.7;
      tent.rotation.y = Math.PI / 6;
      tent.scale.set(1.1, 1.0, 1.3);
      tent.castShadow = true;
      group.add(tent);

      // Entrance Opening inside
      const opening = new THREE.Mesh(new THREE.ConeGeometry(0.7, 0.9, 3), new THREE.MeshBasicMaterial({ color: 0x431407 }));
      opening.position.set(0, 0.45, 0.45);
      opening.rotation.y = Math.PI / 6;
      opening.scale.set(0.9, 1.0, 0.4);
      group.add(opening);

      // Little sleeping mat inside
      const mat = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.04, 1.0), pastelTealMat);
      mat.position.set(0, 0.05, 0.1);
      group.add(mat);
      break;
    }

    case 'curved_bridge': {
      // Smoothly Arched Wooden Bridge
      const bridgeArch = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.12, 1.1), lightWoodMat);
      bridgeArch.position.y = 0.12;
      bridgeArch.castShadow = true;
      group.add(bridgeArch);

      // 4 Cute Round Wooden Posts
      [-0.9, 0.9].forEach(x => {
        [-0.45, 0.45].forEach(z => {
          const post = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.07, 0.7, 8), pastelWoodMat);
          post.position.set(x, 0.35, z);
          post.castShadow = true;
          group.add(post);

          const postCap = new THREE.Mesh(new THREE.SphereGeometry(0.09, 6, 6), pastelYellowMat);
          postCap.position.set(x, 0.72, z);
          group.add(postCap);
        });
      });

      // Handrails
      [-0.45, 0.45].forEach(z => {
        const rail = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.06, 0.06), pastelWoodMat);
        rail.position.set(0, 0.65, z);
        group.add(rail);
      });
      break;
    }

    case 'small_pond': {
      // Circular Stone Rim
      const stoneRim = new THREE.Mesh(new THREE.CylinderGeometry(1.2, 1.3, 0.25, 14), smoothStoneMat);
      stoneRim.position.y = 0.12;
      stoneRim.castShadow = true;
      group.add(stoneRim);

      // Water inside
      const waterPool = new THREE.Mesh(new THREE.CylinderGeometry(1.05, 1.05, 0.1, 14), waterMat);
      waterPool.position.y = 0.22;
      group.add(waterPool);

      // Cute Little Yellow Rubber Duckling floating!
      const duckGroup = new THREE.Group();
      duckGroup.position.set(0.2, 0.28, 0.1);
      duckGroup.name = 'floatingDuck';

      // Duck Body
      const duckBody = new THREE.Mesh(new THREE.SphereGeometry(0.14, 8, 8), pastelYellowMat);
      duckBody.scale.set(1.2, 0.9, 0.9);
      duckGroup.add(duckBody);

      // Duck Head
      const duckHead = new THREE.Mesh(new THREE.SphereGeometry(0.09, 8, 8), pastelYellowMat);
      duckHead.position.set(0.12, 0.1, 0);
      duckGroup.add(duckHead);

      // Orange Beak
      const beak = new THREE.Mesh(new THREE.ConeGeometry(0.04, 0.09, 6), new THREE.MeshBasicMaterial({ color: 0xf97316 }));
      beak.position.set(0.22, 0.08, 0);
      beak.rotation.z = -Math.PI / 2;
      duckGroup.add(beak);

      group.add(duckGroup);
      break;
    }

    case 'waterfall_bluff': {
      // Rounded stone cliff
      const cliff = new THREE.Mesh(new THREE.BoxGeometry(1.8, 2.4, 1.4), smoothStoneMat);
      cliff.position.y = 1.2;
      cliff.castShadow = true;
      group.add(cliff);

      // Flowing water stream cascading
      const stream = new THREE.Mesh(new THREE.BoxGeometry(1.0, 2.5, 0.12), waterMat);
      stream.position.set(0, 1.2, 0.75);
      group.add(stream);

      // Splash pool at base
      const splashPool = new THREE.Mesh(new THREE.CylinderGeometry(0.7, 0.7, 0.1, 12), waterMat);
      splashPool.position.set(0, 0.05, 1.2);
      group.add(splashPool);
      break;
    }

    // =======================================================================
    // 4. CLEAN ENERGY & ECO
    // =======================================================================
    case 'mini_windmill': {
      // Rounded Windmill Body (Pastel Cream/Terracotta)
      const base = new THREE.Mesh(new THREE.CylinderGeometry(0.75, 1.05, 2.4, 10), creamWallMat);
      base.position.y = 1.2;
      base.castShadow = true;
      group.add(base);

      // Pastel Pink Conic Cap
      const cap = new THREE.Mesh(new THREE.ConeGeometry(0.9, 0.8, 10), pastelPinkMat);
      cap.position.y = 2.8;
      group.add(cap);

      // 4 Rotating Wooden Lattice Sails
      const sailsGroup = new THREE.Group();
      sailsGroup.position.set(0, 2.4, 0.82);
      sailsGroup.name = 'windmillSails';

      for (let i = 0; i < 4; i++) {
        const sail = new THREE.Mesh(new THREE.BoxGeometry(0.24, 1.6, 0.03), pastelWoodMat);
        sail.position.y = 0.8;
        const holder = new THREE.Group();
        holder.rotation.z = (i * Math.PI * 2) / 4;
        holder.add(sail);
        sailsGroup.add(holder);
      }
      group.add(sailsGroup);
      break;
    }

    case 'wind_turbine': {
      const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.16, 4.5, 8), whiteMat);
      pole.position.y = 2.25;
      pole.castShadow = true;
      group.add(pole);

      const hub = new THREE.Mesh(new THREE.SphereGeometry(0.2, 10, 10), pastelTealMat);
      hub.position.set(0, 4.5, 0.15);
      group.add(hub);

      const bladesGroup = new THREE.Group();
      bladesGroup.position.set(0, 4.5, 0.25);
      bladesGroup.name = 'turbineBlades';

      for (let i = 0; i < 3; i++) {
        const blade = new THREE.Mesh(new THREE.BoxGeometry(0.12, 1.8, 0.03), whiteMat);
        blade.position.y = 0.9;
        const holder = new THREE.Group();
        holder.rotation.z = (i * Math.PI * 2) / 3;
        holder.add(blade);
        bladesGroup.add(holder);
      }
      group.add(bladesGroup);
      break;
    }

    case 'solar_panel': {
      // Rounded Stand
      const stand = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.08, 0.8, 6), whiteMat);
      stand.position.y = 0.4;
      group.add(stand);

      // Tilted Deep Blue Solar Panel with Cyan grid lines
      const panelFrame = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.08, 1.2), whiteMat);
      panelFrame.position.set(0, 0.7, 0);
      panelFrame.rotation.x = 0.4;
      panelFrame.castShadow = true;
      group.add(panelFrame);

      const solarGrid = new THREE.Mesh(new THREE.PlaneGeometry(1.45, 1.05), new THREE.MeshStandardMaterial({ color: 0x1d4ed8, roughness: 0.1, metalness: 0.8 }));
      solarGrid.position.set(0, 0.75, 0);
      solarGrid.rotation.x = -Math.PI / 2 + 0.4;
      group.add(solarGrid);
      break;
    }

    case 'cozy_lantern': {
      // Vintage Street Lamp Post
      const post = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.07, 1.5, 6), darkWoodMat);
      post.position.y = 0.75;
      group.add(post);

      // Glowing Lantern Head
      const lanternMat = new THREE.MeshBasicMaterial({ color: isNight ? 0xfde047 : 0xffedd5 });
      const lantern = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.35, 0.3), lanternMat);
      lantern.position.y = 1.6;
      group.add(lantern);

      const roofCap = new THREE.Mesh(new THREE.ConeGeometry(0.26, 0.16, 4), darkWoodMat);
      roofCap.position.y = 1.85;
      roofCap.rotation.y = Math.PI / 4;
      group.add(roofCap);
      break;
    }

    case 'solar_lamp': {
      // Mushroom-shaped garden lamp
      const lampStem = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.07, 0.6, 6), creamWallMat);
      lampStem.position.y = 0.3;
      group.add(lampStem);

      const glowingCap = new THREE.Mesh(
        new THREE.SphereGeometry(0.24, 10, 8, 0, Math.PI * 2, 0, Math.PI * 0.5),
        new THREE.MeshBasicMaterial({ color: isNight ? 0xfacc15 : 0x38bdf8 })
      );
      glowingCap.position.y = 0.6;
      group.add(glowingCap);
      break;
    }

    // =======================================================================
    // 5. OUTDOOR & LIFESTYLE
    // =======================================================================
    case 'recycle_bins': {
      // 4 Cute Mini Sorting Bins (Blue, Green, Yellow, Red)
      const binColors = [0x3b82f6, 0x22c55e, 0xeab308, 0xef4444];
      [-0.45, -0.15, 0.15, 0.45].forEach((x, idx) => {
        const binBody = new THREE.Mesh(
          new THREE.BoxGeometry(0.24, 0.48, 0.24),
          new THREE.MeshStandardMaterial({ color: binColors[idx], roughness: 0.3, flatShading: true })
        );
        binBody.position.set(x, 0.24, 0);
        binBody.castShadow = true;
        group.add(binBody);

        const lid = new THREE.Mesh(new THREE.BoxGeometry(0.26, 0.06, 0.26), whiteMat);
        lid.position.set(x, 0.5, 0);
        group.add(lid);
      });
      break;
    }

    case 'eco_bicycle': {
      // Pastel Mint Eco Bicycle with flower basket
      const frameMat = pastelMintMat;
      const wheelMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.4 });

      // Two wheels
      [-0.45, 0.45].forEach(x => {
        const wheel = new THREE.Mesh(new THREE.TorusGeometry(0.22, 0.04, 8, 16), wheelMat);
        wheel.position.set(x, 0.22, 0);
        wheel.castShadow = true;
        group.add(wheel);
      });

      // Frame bar
      const bar1 = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.8, 6), frameMat);
      bar1.position.set(0, 0.3, 0);
      bar1.rotation.z = Math.PI / 2;
      group.add(bar1);

      // Handlebar
      const handle = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.25, 0.35), whiteMat);
      handle.position.set(0.42, 0.52, 0);
      group.add(handle);

      // Cute Front Wicker Basket with Pastel Flowers
      const basket = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.16, 0.22), lightWoodMat);
      basket.position.set(0.5, 0.48, 0);
      group.add(basket);

      const flowerPuff = new THREE.Mesh(new THREE.SphereGeometry(0.1, 6, 6), pastelPinkMat);
      flowerPuff.position.set(0.5, 0.58, 0);
      group.add(flowerPuff);
      break;
    }

    case 'picnic_table': {
      // Wooden Table
      const tableTop = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.08, 0.7), lightWoodMat);
      tableTop.position.y = 0.45;
      tableTop.castShadow = true;
      group.add(tableTop);

      // Red & White Checkered Picnic Cloth
      const cloth = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.02, 0.5), pastelRedMat);
      cloth.position.set(0, 0.5, 0);
      group.add(cloth);

      // Little picnic basket on table
      const basket = new THREE.Mesh(new THREE.BoxGeometry(0.25, 0.18, 0.2), pastelWoodMat);
      basket.position.set(0.15, 0.58, 0);
      group.add(basket);

      // Two Benches on sides
      [-0.45, 0.45].forEach(z => {
        const bench = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.06, 0.25), lightWoodMat);
        bench.position.set(0, 0.25, z);
        bench.castShadow = true;
        group.add(bench);
      });
      break;
    }

    case 'wooden_signpost': {
      // Wooden Post
      const post = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.06, 1.2, 6), pastelWoodMat);
      post.position.y = 0.6;
      group.add(post);

      // Sign Arrow 1 (Pointing Left)
      const sign1 = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.14, 0.04), lightWoodMat);
      sign1.position.set(-0.15, 0.95, 0.04);
      sign1.rotation.y = 0.2;
      group.add(sign1);

      // Sign Arrow 2 (Pointing Right)
      const sign2 = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.14, 0.04), creamWallMat);
      sign2.position.set(0.12, 0.75, -0.04);
      sign2.rotation.y = -0.3;
      group.add(sign2);
      break;
    }

    case 'park_bench': {
      const seat = new THREE.Mesh(new THREE.BoxGeometry(1.3, 0.08, 0.42), lightWoodMat);
      seat.position.y = 0.35;
      seat.castShadow = true;
      group.add(seat);

      const back = new THREE.Mesh(new THREE.BoxGeometry(1.3, 0.38, 0.06), lightWoodMat);
      back.position.set(0, 0.58, -0.18);
      back.castShadow = true;
      group.add(back);
      break;
    }

    case 'eco_campfire': {
      // Smooth round stones ring
      for (let i = 0; i < 6; i++) {
        const stone = new THREE.Mesh(new THREE.SphereGeometry(0.14, 6, 6), smoothStoneMat);
        const a = (i * Math.PI * 2) / 6;
        stone.position.set(Math.cos(a) * 0.4, 0.08, Math.sin(a) * 0.4);
        group.add(stone);
      }

      // Crossed logs
      for (let i = 0; i < 3; i++) {
        const log = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.6, 6), pastelWoodMat);
        log.rotation.z = Math.PI / 3;
        log.rotation.y = (i * Math.PI * 2) / 3;
        log.position.y = 0.1;
        group.add(log);
      }

      // Cozy stylized flame
      const fireMat = new THREE.MeshBasicMaterial({ color: 0xf97316 });
      const fire = new THREE.Mesh(new THREE.ConeGeometry(0.22, 0.45, 6), fireMat);
      fire.position.y = 0.3;
      fire.name = 'campfireFlame';
      group.add(fire);
      break;
    }

    case 'eco_fountain': {
      const pool = new THREE.Mesh(new THREE.CylinderGeometry(1.1, 1.2, 0.25, 14), smoothStoneMat);
      pool.position.y = 0.12;
      pool.castShadow = true;
      group.add(pool);

      const waterLevel = new THREE.Mesh(new THREE.CylinderGeometry(0.95, 0.95, 0.08, 14), waterMat);
      waterLevel.position.y = 0.22;
      group.add(waterLevel);

      const pillar = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.25, 0.7, 8), smoothStoneMat);
      pillar.position.y = 0.55;
      group.add(pillar);

      const upperBowl = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.55, 0.18, 10), smoothStoneMat);
      upperBowl.position.y = 0.9;
      group.add(upperBowl);

      const waterSpout = new THREE.Mesh(new THREE.SphereGeometry(0.12, 6, 6), new THREE.MeshBasicMaterial({ color: 0x38bdf8 }));
      waterSpout.position.y = 1.05;
      group.add(waterSpout);
      break;
    }

    case 'flower_pot': {
      // Rounded terracotta pastel pot
      const potMat = new THREE.MeshStandardMaterial({ color: 0xf472b6, roughness: 0.5, flatShading: true });
      const pot = new THREE.Mesh(new THREE.CylinderGeometry(0.38, 0.28, 0.45, 12), potMat);
      pot.position.y = 0.23;
      pot.castShadow = true;
      group.add(pot);

      // Rim
      const rim = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.42, 0.08, 12), potMat);
      rim.position.y = 0.45;
      group.add(rim);

      // Dark Soil
      const soil = new THREE.Mesh(new THREE.CylinderGeometry(0.36, 0.36, 0.05, 12), darkWoodMat);
      soil.position.y = 0.46;
      group.add(soil);

      // 3 Cute White Daisies with Yellow Center
      const daisyWhite = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.3 });
      const daisyYellow = new THREE.MeshBasicMaterial({ color: 0xfacc15 });
      [
        { x: 0, y: 0.7, z: 0 },
        { x: -0.15, y: 0.62, z: 0.12 },
        { x: 0.14, y: 0.65, z: -0.1 },
      ].forEach((dp) => {
        const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.25, 4), new THREE.MeshBasicMaterial({ color: 0x22c55e }));
        stem.position.set(dp.x, dp.y - 0.12, dp.z);
        group.add(stem);

        const flower = new THREE.Mesh(new THREE.SphereGeometry(0.1, 8, 8), daisyWhite);
        flower.position.set(dp.x, dp.y, dp.z);
        group.add(flower);

        const center = new THREE.Mesh(new THREE.SphereGeometry(0.04, 6, 6), daisyYellow);
        center.position.set(dp.x, dp.y + 0.04, dp.z);
        group.add(center);
      });
      break;
    }

    case 'veggie_patch': {
      // Wooden box border
      const boxMat = new THREE.MeshStandardMaterial({ color: 0xb45309, roughness: 0.7, flatShading: true });
      const border = new THREE.Mesh(new THREE.BoxGeometry(1.4, 0.2, 1.0), boxMat);
      border.position.y = 0.1;
      border.castShadow = true;
      group.add(border);

      // Rich Soil
      const soil = new THREE.Mesh(new THREE.BoxGeometry(1.25, 0.18, 0.85), new THREE.MeshStandardMaterial({ color: 0x451a03, roughness: 0.9 }));
      soil.position.y = 0.11;
      group.add(soil);

      // Row of Cute Carrots (Orange cone + green leaf)
      const carrotMat = new THREE.MeshStandardMaterial({ color: 0xf97316, roughness: 0.4 });
      const leafMat = new THREE.MeshStandardMaterial({ color: 0x22c55e, roughness: 0.4 });

      [-0.4, 0, 0.4].forEach((x) => {
        const carrotTop = new THREE.Mesh(new THREE.SphereGeometry(0.08, 6, 6), carrotMat);
        carrotTop.position.set(x, 0.24, -0.2);
        group.add(carrotTop);

        const leaf = new THREE.Mesh(new THREE.ConeGeometry(0.06, 0.16, 4), leafMat);
        leaf.position.set(x, 0.34, -0.2);
        group.add(leaf);
      });

      // Row of Cute Round Cabbages
      [-0.3, 0.3].forEach((x) => {
        const cabbage = new THREE.Mesh(new THREE.SphereGeometry(0.13, 8, 8), new THREE.MeshStandardMaterial({ color: 0x86efac, roughness: 0.5 }));
        cabbage.position.set(x, 0.28, 0.2);
        group.add(cabbage);
      });
      break;
    }

    case 'mini_cafe': {
      // Cozy Cafe Booth Base
      const boothMat = new THREE.MeshStandardMaterial({ color: 0xfef3c7, roughness: 0.6, flatShading: true });
      const base = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.8, 1.1), boothMat);
      base.position.y = 0.4;
      base.castShadow = true;
      group.add(base);

      // Counter Top in Warm Light Wood
      const counter = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.08, 1.2), lightWoodMat);
      counter.position.y = 0.84;
      counter.castShadow = true;
      group.add(counter);

      // 4 Corner Pillars
      const pillarMat = new THREE.MeshStandardMaterial({ color: 0x78350f, roughness: 0.7 });
      [
        { x: -0.68, z: -0.48 },
        { x: 0.68, z: -0.48 },
        { x: -0.68, z: 0.48 },
        { x: 0.68, z: 0.48 },
      ].forEach((pos) => {
        const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 1.2, 6), pillarMat);
        pole.position.set(pos.x, 1.4, pos.z);
        group.add(pole);
      });

      // Striped Pastel Awning (Mint & Cream stripes)
      const mintAwning = new THREE.MeshStandardMaterial({ color: 0x2dd4bf, roughness: 0.4, flatShading: true });
      const creamAwning = new THREE.MeshStandardMaterial({ color: 0xffedd5, roughness: 0.4, flatShading: true });

      const roofGroup = new THREE.Group();
      roofGroup.position.set(0, 1.95, 0);
      for (let s = -3; s <= 3; s++) {
        const stripe = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.1, 1.3), s % 2 === 0 ? mintAwning : creamAwning);
        stripe.position.set(s * 0.23, 0, 0);
        stripe.rotation.x = 0.15;
        roofGroup.add(stripe);
      }
      group.add(roofGroup);

      // Cute Coffee Cup & Pastry on Counter
      const cup = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.06, 0.14, 8), whiteMat);
      cup.position.set(-0.35, 0.95, 0.35);
      group.add(cup);

      const signBoard = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.22, 0.04), darkWoodMat);
      signBoard.position.set(0, 1.7, 0.55);
      group.add(signBoard);

      // Warm Cozy Glow inside Cafe at Night
      if (isNight) {
        const cafeGlow = new THREE.Mesh(
          new THREE.SphereGeometry(0.16, 8, 8),
          new THREE.MeshBasicMaterial({ color: 0xfef08a })
        );
        cafeGlow.position.set(0, 1.3, 0);
        group.add(cafeGlow);
      }
      break;
    }

    case 'hanging_lantern': {
      // Curved Wooden Arch Pole
      const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.05, 1.3, 6), pastelWoodMat);
      pole.position.set(0, 0.65, 0);
      pole.castShadow = true;
      group.add(pole);

      const arm = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.45, 6), pastelWoodMat);
      arm.position.set(0.18, 1.25, 0);
      arm.rotation.z = Math.PI / 2.5;
      group.add(arm);

      // Hanging Chain
      const chain = new THREE.Mesh(new THREE.CylinderGeometry(0.01, 0.01, 0.18, 4), smoothStoneMat);
      chain.position.set(0.35, 1.15, 0);
      group.add(chain);

      // Glowing Lantern Glass
      const lanternMat = isNight 
        ? new THREE.MeshBasicMaterial({ color: 0xfde047 }) 
        : new THREE.MeshStandardMaterial({ color: 0xfef08a, roughness: 0.3 });
      
      const lantern = new THREE.Mesh(new THREE.OctahedronGeometry(0.16, 1), lanternMat);
      lantern.position.set(0.35, 0.98, 0);
      group.add(lantern);

      // Little cute cap on top
      const cap = new THREE.Mesh(new THREE.ConeGeometry(0.18, 0.1, 6), darkWoodMat);
      cap.position.set(0.35, 1.1, 0);
      group.add(cap);
      break;
    }

    case 'tree_string_lights': {
      // 2 Wooden Stakes with curved string
      [-0.45, 0.45].forEach((x) => {
        const stake = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.04, 1.0, 6), lightWoodMat);
        stake.position.set(x, 0.5, 0);
        group.add(stake);
      });

      // String line
      const stringGeo = new THREE.TorusGeometry(0.48, 0.012, 4, 12, Math.PI);
      const stringMat = new THREE.MeshBasicMaterial({ color: 0x334155 });
      const stringMesh = new THREE.Mesh(stringGeo, stringMat);
      stringMesh.position.set(0, 0.95, 0);
      stringMesh.rotation.z = Math.PI;
      group.add(stringMesh);

      // 5 Pastel Glowing Light Bulbs
      const bulbColors = [0xfde047, 0xf472b6, 0x67e8f9, 0xa7f3d0, 0xfbbf24];
      for (let b = 0; b < 5; b++) {
        const ang = (b / 4) * Math.PI;
        const bx = -Math.cos(ang) * 0.45;
        const by = 0.95 - Math.sin(ang) * 0.28;
        const bulbMat = isNight
          ? new THREE.MeshBasicMaterial({ color: bulbColors[b % bulbColors.length] })
          : new THREE.MeshStandardMaterial({ color: bulbColors[b % bulbColors.length], roughness: 0.2 });

        const bulb = new THREE.Mesh(new THREE.SphereGeometry(0.065, 6, 6), bulbMat);
        bulb.position.set(bx, by, 0);
        group.add(bulb);
      }
      break;
    }

    case 'stepping_stones': {
      // 4 Rounded Cozy Stepping Pebbles
      const stonePositions = [
        { x: -0.35, z: -0.28, r: 0.24, rot: 0.2 },
        { x: -0.1, z: -0.05, r: 0.26, rot: -0.4 },
        { x: 0.15, z: 0.18, r: 0.23, rot: 0.5 },
        { x: 0.38, z: 0.38, r: 0.25, rot: -0.1 },
      ];

      stonePositions.forEach((sp) => {
        const pebble = new THREE.Mesh(new THREE.CylinderGeometry(sp.r, sp.r * 1.1, 0.05, 10), smoothStoneMat);
        pebble.position.set(sp.x, 0.025, sp.z);
        pebble.rotation.y = sp.rot;
        pebble.scale.set(1.1, 1, 0.9);
        group.add(pebble);
      });
      break;
    }

    case 'cute_mailbox': {
      // Wooden Pole
      const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.05, 0.8, 6), lightWoodMat);
      pole.position.set(0, 0.4, 0);
      group.add(pole);

      // Red Rounded Mailbox Body
      const boxMat = new THREE.MeshStandardMaterial({ color: 0xef4444, roughness: 0.4, flatShading: true });
      const box = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.18, 0.45, 10), boxMat);
      box.position.set(0, 0.8, 0.05);
      box.rotation.x = Math.PI / 2;
      box.castShadow = true;
      group.add(box);

      // Yellow Notification Flag
      const flagMat = new THREE.MeshBasicMaterial({ color: 0xfde047 });
      const flagPole = new THREE.Mesh(new THREE.BoxGeometry(0.02, 0.18, 0.02), flagMat);
      flagPole.position.set(0.19, 0.88, 0.1);
      group.add(flagPole);

      const flagTop = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.06, 0.01), flagMat);
      flagTop.position.set(0.22, 0.94, 0.1);
      group.add(flagTop);
      break;
    }

    default: {
      const fallback = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.7, 0.7), new THREE.MeshStandardMaterial({ color: 0x10b981 }));
      fallback.position.y = 0.35;
      group.add(fallback);
    }
  }

  return group;
}
