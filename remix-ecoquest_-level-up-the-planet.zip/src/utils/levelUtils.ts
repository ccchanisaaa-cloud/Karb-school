export interface LevelUnlockInfo {
  level: number;
  title: string;
  description: string;
  icon: string;
  unlockedItem: string;
  type: 'island' | 'pet' | 'title';
}

/**
 * Calculates required XP for a given level.
 * Level 1: 100 XP
 * Level 2: 125 XP
 * Level 3: 150 XP
 * Level 4: 175 XP
 * Level 5: 200 XP
 * Level 6: 225 XP
 * ... (+25 XP per level progressively for smooth, balanced growth)
 */
export function getRequiredXP(level: number): number {
  const safeLevel = Math.max(1, level);
  return Math.floor(100 + (safeLevel - 1) * 25);
}

export const LEVEL_UNLOCKS_MAP: Record<number, LevelUnlockInfo> = {
  1: {
    level: 1,
    title: 'จุดเริ่มต้นเกาะรักษ์โลก',
    description: 'ผืนดิน 3D ต้นไม้แรกกำเนิด และ Eco Pet วัยแรกเกิด (Baby Sprout)',
    icon: '🌱',
    unlockedItem: 'Eco Pet Baby Sprout & Base Island',
    type: 'island',
  },
  2: {
    level: 2,
    title: 'สะพานไม้ข้ามลำธาร',
    description: 'ปลดล็อกโครงสร้างสะพานไม้เชื่อมต่อผืนดินข้ามลำธาร 3D',
    icon: '🌉',
    unlockedItem: '3D Wooden Bridge',
    type: 'island',
  },
  3: {
    level: 3,
    title: 'บ้านบนต้นไม้ Treehouse',
    description: 'ปลดล็อกบ้านบนต้นไม้ พร้อมแสงไฟส่องสว่างสีทองอบอุ่น',
    icon: '🏡',
    unlockedItem: '3D Treehouse & Warm Glow',
    type: 'island',
  },
  4: {
    level: 4,
    title: 'กังหันลมพลังงานสะอาด',
    description: 'ปลดล็อกกังหันลมหมุนสร้างพลังงานหมุนเวียนบริสุทธิ์รอบเกาะ',
    icon: '💨',
    unlockedItem: '3D Eco Wind Turbine',
    type: 'island',
  },
  5: {
    level: 5,
    title: 'แผงโซลาร์เซลล์แสงอาทิตย์',
    description: 'ปลดล็อกแผงโซลาร์เซลล์ รับพลังงานแสงอาทิตย์สะอาดบนเกาะ',
    icon: '☀️',
    unlockedItem: '3D Solar Panel Grid',
    type: 'island',
  },
  6: {
    level: 6,
    title: 'ม้านั่งไม้ริมธารน้ำตก',
    description: 'ปลดล็อกม้านั่งไม้สวนสาธารณะริมธารน้ำตกสดชื่น',
    icon: '🪑',
    unlockedItem: '3D Park Bench & Waterfall View',
    type: 'island',
  },
  7: {
    level: 7,
    title: 'มงกุฎใบไม้ & ทุ่งดอกไม้',
    description: 'Eco Pet สวมมงกุฎใบไม้ พร้อมทุ่งดอกไม้บานสะพรั่งทั่วเกาะ',
    icon: '👑',
    unlockedItem: 'Eco Pet Leaf Crown & Rainbow Garden',
    type: 'pet',
  },
  8: {
    level: 8,
    title: 'กลุ่มเมฆมงคล & วิวัฒนาการ Pet',
    description: 'เปิดม่านเมฆมงคลและพัฒนา Eco Pet เป็นขั้น Teen/Adult',
    icon: '☁️',
    unlockedItem: 'Sky Cloud Network & Pet Evolution',
    type: 'pet',
  },
  9: {
    level: 9,
    title: 'ประกายดาว Starlight Aura',
    description: 'ปลดล็อกออร่าพลังงานประกายดาวเปล่งประกายรอบเกาะ 3D',
    icon: '✨',
    unlockedItem: 'Starlight Aura Particle Effect',
    type: 'island',
  },
  10: {
    level: 10,
    title: 'ผู้ดูแลเมืองวิญญาณรักษ์โลก',
    description: 'ปลดล็อกยศ Master Eco Guardian และ Unlimited Progression',
    icon: '🌟',
    unlockedItem: 'Master Guardian Title & Golden Crown',
    type: 'title',
  },
};

export function getLevelUnlock(level: number): LevelUnlockInfo {
  if (LEVEL_UNLOCKS_MAP[level]) return LEVEL_UNLOCKS_MAP[level];
  return {
    level,
    title: `ผู้ดูแลเกาะระดับ ${level}`,
    description: `ปลดล็อกพลังงานสะอาดและขยายระดับต่อเนื่องไม่จำกัด (Unlimited Level ${level})`,
    icon: '✨',
    unlockedItem: `Level ${level} Eco Emblem & Unlimited Boost`,
    type: 'title',
  };
}
