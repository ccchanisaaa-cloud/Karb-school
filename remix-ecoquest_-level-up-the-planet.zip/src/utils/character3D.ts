import * as THREE from 'three';
import { PlacedDecoration } from '../types';
import { DECOR_CATALOG } from '../data/islandDecorCatalog';

export interface CharacterControllerState {
  x: number;
  z: number;
  y: number;
  rotationY: number;
  targetRotationY: number;
  isMoving: boolean;
  isRunning: boolean;
  speed: number;
  targetPosition: THREE.Vector3 | null;
  currentAction: 'idle' | 'walk' | 'run' | 'sit' | 'wave' | 'cheer' | 'gaze';
  actionTimer: number;
  idleAutonomyTimer: number;
  nearbyInteraction: {
    type: 'sit' | 'pet' | 'cafe' | 'water' | 'tree' | null;
    title: string;
    targetPos: THREE.Vector3;
    rotation: number;
  } | null;
  bubbleText: string | null;
  bubbleTimer: number;
}

export interface CharacterMeshes {
  rootGroup: THREE.Group;
  body: THREE.Mesh;
  head: THREE.Mesh;
  leftArm: THREE.Mesh;
  rightArm: THREE.Mesh;
  leftLeg: THREE.Mesh;
  rightLeg: THREE.Mesh;
  hat: THREE.Group;
  backpack: THREE.Mesh;
  lantern: THREE.Group | null;
  targetMarker: THREE.Mesh;
  speechBubble: THREE.Group;
  bubbleCanvas: HTMLCanvasElement;
  bubbleTexture: THREE.CanvasTexture;
}

/**
 * Creates the 3D Cute Explorer Character Mesh
 */
export function createExplorerCharacter(isNight: boolean): CharacterMeshes {
  const rootGroup = new THREE.Group();
  rootGroup.name = 'playerCharacterGroup';
  rootGroup.position.set(0, 1.5, 1.2);

  // Materials with cozy pastel tones
  const skinMat = new THREE.MeshStandardMaterial({
    color: 0xffdfba, // Warm cozy skin tone
    roughness: 0.5,
    flatShading: true,
  });

  const clothesMat = new THREE.MeshStandardMaterial({
    color: 0x059669, // Forest Sage Green Jacket
    roughness: 0.6,
    flatShading: true,
  });

  const pantsMat = new THREE.MeshStandardMaterial({
    color: 0x1e293b, // Dark Navy Pants
    roughness: 0.7,
    flatShading: true,
  });

  const bootsMat = new THREE.MeshStandardMaterial({
    color: 0x78350f, // Warm Leather Boots
    roughness: 0.6,
  });

  const yellowHatMat = new THREE.MeshStandardMaterial({
    color: 0xfbbf24, // Bright Mustard Yellow Beret/Cap
    roughness: 0.5,
    flatShading: true,
  });

  const backpackMat = new THREE.MeshStandardMaterial({
    color: 0xb45309, // Leather Canvas Backpack
    roughness: 0.7,
    flatShading: true,
  });

  // 1. Torso / Jacket (Rounded cute body)
  const bodyGeo = new THREE.CylinderGeometry(0.24, 0.28, 0.44, 10);
  const body = new THREE.Mesh(bodyGeo, clothesMat);
  body.position.y = 0.48;
  body.castShadow = true;
  body.receiveShadow = true;
  rootGroup.add(body);

  // Yellow Scarf / Collar
  const scarfGeo = new THREE.TorusGeometry(0.22, 0.06, 6, 12);
  const scarfMat = new THREE.MeshStandardMaterial({ color: 0xfde047, roughness: 0.5 });
  const scarf = new THREE.Mesh(scarfGeo, scarfMat);
  scarf.position.set(0, 0.68, 0);
  scarf.rotation.x = Math.PI / 2;
  rootGroup.add(scarf);

  // 2. Head (Cute round sphere)
  const headGeo = new THREE.SphereGeometry(0.3, 14, 14);
  const head = new THREE.Mesh(headGeo, skinMat);
  head.position.y = 0.95;
  head.castShadow = true;
  rootGroup.add(head);

  // Anime Eyes with sparkle
  const eyeMat = new THREE.MeshBasicMaterial({ color: 0x0f172a });
  const eyeWhiteMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
  const blushMat = new THREE.MeshBasicMaterial({ color: 0xf472b6 });

  [-0.1, 0.1].forEach((x) => {
    // Dark pupil
    const eye = new THREE.Mesh(new THREE.SphereGeometry(0.045, 8, 8), eyeMat);
    eye.position.set(x, 0.98, 0.27);
    rootGroup.add(eye);

    // Cute White Highlight Sparkle
    const eyeGlitter = new THREE.Mesh(new THREE.SphereGeometry(0.016, 6, 6), eyeWhiteMat);
    eyeGlitter.position.set(x + 0.015, 0.995, 0.3);
    rootGroup.add(eyeGlitter);

    // Rosy Pink Blush
    const blush = new THREE.Mesh(new THREE.SphereGeometry(0.035, 6, 6), blushMat);
    blush.position.set(x * 1.5, 0.92, 0.26);
    blush.scale.set(1.2, 0.6, 0.5);
    rootGroup.add(blush);
  });

  // Smile mouth
  const smileGeo = new THREE.TorusGeometry(0.04, 0.012, 4, 8, Math.PI);
  const smileMat = new THREE.MeshBasicMaterial({ color: 0x991b1b });
  const smile = new THREE.Mesh(smileGeo, smileMat);
  smile.position.set(0, 0.88, 0.28);
  smile.rotation.x = Math.PI / 2;
  smile.rotation.z = Math.PI;
  rootGroup.add(smile);

  // 3. Cute Explorer Hat / Beret with Little Sprout
  const hatGroup = new THREE.Group();
  hatGroup.position.set(0, 1.18, 0);

  const beretBase = new THREE.Mesh(new THREE.CylinderGeometry(0.34, 0.28, 0.12, 12), yellowHatMat);
  hatGroup.add(beretBase);

  const beretDome = new THREE.Mesh(new THREE.SphereGeometry(0.32, 10, 8), yellowHatMat);
  beretDome.position.y = 0.06;
  beretDome.scale.set(1, 0.45, 1);
  hatGroup.add(beretDome);

  // Tiny Green Sprout on Hat
  const sproutStem = new THREE.Mesh(
    new THREE.CylinderGeometry(0.015, 0.015, 0.1, 4),
    new THREE.MeshBasicMaterial({ color: 0x22c55e })
  );
  sproutStem.position.y = 0.22;
  hatGroup.add(sproutStem);

  const sproutLeaf = new THREE.Mesh(
    new THREE.SphereGeometry(0.05, 6, 6),
    new THREE.MeshBasicMaterial({ color: 0x4ade80 })
  );
  sproutLeaf.position.set(0.04, 0.26, 0);
  sproutLeaf.scale.set(1.4, 0.5, 0.8);
  sproutLeaf.rotation.z = -0.4;
  hatGroup.add(sproutLeaf);

  rootGroup.add(hatGroup);

  // 4. Canvas Backpack with Rolled Map
  const backpack = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.36, 0.16), backpackMat);
  backpack.position.set(0, 0.52, -0.22);
  backpack.castShadow = true;
  rootGroup.add(backpack);

  const rolledMap = new THREE.Mesh(
    new THREE.CylinderGeometry(0.04, 0.04, 0.36, 8),
    new THREE.MeshStandardMaterial({ color: 0xfef3c7, roughness: 0.5 })
  );
  rolledMap.position.set(0, 0.72, -0.22);
  rolledMap.rotation.z = Math.PI / 2;
  rootGroup.add(rolledMap);

  // 5. Arms (Left and Right)
  const armGeo = new THREE.CylinderGeometry(0.065, 0.065, 0.32, 8);
  
  const leftArm = new THREE.Mesh(armGeo, clothesMat);
  leftArm.position.set(-0.32, 0.5, 0);
  leftArm.castShadow = true;
  rootGroup.add(leftArm);

  const leftHand = new THREE.Mesh(new THREE.SphereGeometry(0.065, 6, 6), skinMat);
  leftHand.position.set(0, -0.18, 0);
  leftArm.add(leftHand);

  const rightArm = new THREE.Mesh(armGeo, clothesMat);
  rightArm.position.set(0.32, 0.5, 0);
  rightArm.castShadow = true;
  rootGroup.add(rightArm);

  const rightHand = new THREE.Mesh(new THREE.SphereGeometry(0.065, 6, 6), skinMat);
  rightHand.position.set(0, -0.18, 0);
  rightArm.add(rightHand);

  // 6. Night Lantern (Attached to right hand when dark/night)
  let lanternGroup: THREE.Group | null = null;
  if (isNight) {
    lanternGroup = new THREE.Group();
    lanternGroup.position.set(0, -0.25, 0.1);

    // Wooden handle
    const handle = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.015, 0.18, 6), bootsMat);
    handle.position.y = 0.09;
    lanternGroup.add(handle);

    // Glowing Lantern Glass
    const glassMat = new THREE.MeshBasicMaterial({ color: 0xfef08a });
    const glass = new THREE.Mesh(new THREE.OctahedronGeometry(0.09, 1), glassMat);
    glass.position.y = -0.04;
    lanternGroup.add(glass);

    // Warm Point Light radiating from character's lantern
    const lanternLight = new THREE.PointLight(0xfde047, 1.2, 5.5, 2);
    lanternLight.position.set(0, -0.04, 0);
    lanternGroup.add(lanternLight);

    rightHand.add(lanternGroup);
  }

  // 7. Legs (Left and Right)
  const legGeo = new THREE.CylinderGeometry(0.08, 0.08, 0.32, 8);

  const leftLeg = new THREE.Mesh(legGeo, pantsMat);
  leftLeg.position.set(-0.13, 0.16, 0);
  leftLeg.castShadow = true;
  rootGroup.add(leftLeg);

  const leftBoot = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.1, 0.18), bootsMat);
  leftBoot.position.set(0, -0.18, 0.04);
  leftBoot.castShadow = true;
  leftLeg.add(leftBoot);

  const rightLeg = new THREE.Mesh(legGeo, pantsMat);
  rightLeg.position.set(0.13, 0.16, 0);
  rightLeg.castShadow = true;
  rootGroup.add(rightLeg);

  const rightBoot = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.1, 0.18), bootsMat);
  rightBoot.position.set(0, -0.18, 0.04);
  rightBoot.castShadow = true;
  rightLeg.add(rightBoot);

  // 8. Ground Target Marker (Ripple ring indicating tapped target point)
  const markerGeo = new THREE.RingGeometry(0.15, 0.32, 24);
  const markerMat = new THREE.MeshBasicMaterial({
    color: 0x34d399,
    side: THREE.DoubleSide,
    transparent: true,
    opacity: 0,
  });
  const targetMarker = new THREE.Mesh(markerGeo, markerMat);
  targetMarker.rotation.x = -Math.PI / 2;
  targetMarker.position.y = 1.52;

  // 9. Floating Speech / Reaction Bubble
  const bubbleCanvas = document.createElement('canvas');
  bubbleCanvas.width = 128;
  bubbleCanvas.height = 128;
  const bubbleTexture = new THREE.CanvasTexture(bubbleCanvas);
  bubbleTexture.minFilter = THREE.LinearFilter;

  const bubbleMat = new THREE.SpriteMaterial({
    map: bubbleTexture,
    transparent: true,
    opacity: 0,
  });
  const speechBubble = new THREE.Group();
  const bubbleSprite = new THREE.Sprite(bubbleMat);
  bubbleSprite.scale.set(0.7, 0.7, 0.7);
  speechBubble.position.set(0, 1.6, 0);
  speechBubble.add(bubbleSprite);
  rootGroup.add(speechBubble);

  return {
    rootGroup,
    body,
    head,
    leftArm,
    rightArm,
    leftLeg,
    rightLeg,
    hat: hatGroup,
    backpack,
    lantern: lanternGroup,
    targetMarker,
    speechBubble,
    bubbleCanvas,
    bubbleTexture,
  };
}

/**
 * Renders an emoji/text onto the floating speech bubble canvas
 */
export function updateBubbleTexture(
  canvas: HTMLCanvasElement,
  texture: THREE.CanvasTexture,
  text: string | null
) {
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  ctx.clearRect(0, 0, canvas.width, canvas.height);

  if (!text) {
    texture.needsUpdate = true;
    return;
  }

  // Draw rounded white speech bubble background
  ctx.fillStyle = 'rgba(255, 255, 255, 0.95)';
  ctx.strokeStyle = '#10b981';
  ctx.lineWidth = 4;

  const x = 16;
  const y = 16;
  const w = 96;
  const h = 76;
  const r = 20;

  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  // Pointer tail
  ctx.lineTo(x + w / 2 + 10, y + h);
  ctx.lineTo(x + w / 2, y + h + 16);
  ctx.lineTo(x + w / 2 - 10, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();

  ctx.fill();
  ctx.stroke();

  // Draw text / emoji
  ctx.font = '36px sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillStyle = '#0f172a';
  ctx.fillText(text, 64, 52);

  texture.needsUpdate = true;
}

/**
 * Checks if a destination position (x, z) collides with island boundaries, river water, or decorations
 */
export function checkPositionCollision(
  x: number,
  z: number,
  decorations: PlacedDecoration[],
  playerRadius: number = 0.35
): { isBlocked: boolean; slideX: number; slideZ: number; blockedReason?: string } {
  // 1. Island Boundary Check (Radius <= 6.35 is safe on grass base)
  const distFromCenter = Math.hypot(x, z);
  const maxIslandRadius = 6.35;

  if (distFromCenter > maxIslandRadius) {
    const angle = Math.atan2(z, x);
    return {
      isBlocked: true,
      slideX: Math.cos(angle) * maxIslandRadius,
      slideZ: Math.sin(angle) * maxIslandRadius,
      blockedReason: 'edge',
    };
  }

  // 2. River Collision Check
  // River center (1.1, 1.0), rotation 0.3 rad, dimensions ~1.8 width x 9.2 length
  const riverCenterX = 1.1;
  const riverCenterZ = 1.0;
  const riverRot = 0.3;
  const cosR = Math.cos(-riverRot);
  const sinR = Math.sin(-riverRot);

  const rdx = x - riverCenterX;
  const rdz = z - riverCenterZ;
  const localRiverX = rdx * cosR - rdz * sinR;
  const localRiverZ = rdx * sinR + rdz * cosR;

  // Check if character is near a bridge or stepping stones
  let hasBridgeNearby = false;
  for (const d of decorations) {
    if (d.type === 'wooden_bridge' || d.type === 'curved_bridge' || d.type === 'stepping_stones') {
      const bDist = Math.hypot(x - d.x, z - d.z);
      if (bDist < 1.4) {
        hasBridgeNearby = true;
        break;
      }
    }
  }

  // River water bounds: halfWidth ~ 0.85, halfLength ~ 4.4
  if (!hasBridgeNearby && Math.abs(localRiverX) < 0.85 && Math.abs(localRiverZ) < 4.4) {
    // Slide character along bank
    const sign = localRiverX > 0 ? 1 : -1;
    const pushedLocalX = sign * (0.85 + playerRadius);
    const worldPushedX = riverCenterX + pushedLocalX * Math.cos(riverRot) - localRiverZ * Math.sin(riverRot);
    const worldPushedZ = riverCenterZ + pushedLocalX * Math.sin(riverRot) + localRiverZ * Math.cos(riverRot);

    return {
      isBlocked: true,
      slideX: worldPushedX,
      slideZ: worldPushedZ,
      blockedReason: 'water',
    };
  }

  // 3. Decorations / Obstacles Collision Check
  for (const decor of decorations) {
    const catalogItem = DECOR_CATALOG.find((c) => c.id === decor.type);
    const obstacleRadius = ((catalogItem?.radius || 0.8) * (decor.scale || 1.0)) * 0.72; // slight buffer for natural walkability

    // Skip walkable decorations like flowers, rugs, flat stepping stones
    if (
      decor.type === 'stepping_stones' ||
      decor.type === 'flowers_wild' ||
      decor.type === 'flowers_lavender' ||
      decor.type === 'flowers_sunflower'
    ) {
      continue;
    }

    const dist = Math.hypot(x - decor.x, z - decor.z);
    const minAllowedDist = playerRadius + obstacleRadius;

    if (dist < minAllowedDist) {
      // Calculate push-out normal vector
      const angle = Math.atan2(z - decor.z, x - decor.x);
      const safeX = decor.x + Math.cos(angle) * (minAllowedDist + 0.05);
      const safeZ = decor.z + Math.sin(angle) * (minAllowedDist + 0.05);

      return {
        isBlocked: true,
        slideX: safeX,
        slideZ: safeZ,
        blockedReason: 'obstacle',
      };
    }
  }

  return { isBlocked: false, slideX: x, slideZ: z };
}

/**
 * Finds interesting interactive objects near player (Benches, Pet, Campfire, Cafe, etc.)
 */
export function findNearbyInteractions(
  playerX: number,
  playerZ: number,
  decorations: PlacedDecoration[],
  petPos: { x: number; z: number } = { x: 0, z: -0.5 }
): CharacterControllerState['nearbyInteraction'] {
  // 1. Eco Pet mascot interaction
  const distToPet = Math.hypot(playerX - petPos.x, playerZ - petPos.z);
  if (distToPet < 1.6) {
    return {
      type: 'pet',
      title: 'เล่นกับ Eco Pet 🐾',
      targetPos: new THREE.Vector3(petPos.x, 1.5, petPos.z),
      rotation: Math.atan2(petPos.x - playerX, petPos.z - playerZ),
    };
  }

  // 2. Check decorations
  for (const d of decorations) {
    const dist = Math.hypot(playerX - d.x, playerZ - d.z);

    if (dist < 1.8) {
      if (d.type === 'park_bench' || d.type === 'picnic_table') {
        return {
          type: 'sit',
          title: 'นั่งพักผ่อน 🪑',
          targetPos: new THREE.Vector3(d.x, 1.5, d.z),
          rotation: d.rotationY || 0,
        };
      }
      if (d.type === 'eco_campfire') {
        return {
          type: 'sit',
          title: 'ผิงไฟแคมป์ปิ้ง 🔥',
          targetPos: new THREE.Vector3(d.x, 1.5, d.z),
          rotation: Math.atan2(d.x - playerX, d.z - playerZ),
        };
      }
      if (d.type === 'mini_cafe') {
        return {
          type: 'cafe',
          title: 'จิบกาแฟรักษ์โลก ☕',
          targetPos: new THREE.Vector3(d.x, 1.5, d.z + 0.8),
          rotation: 0,
        };
      }
    }
  }

  return null;
}

/**
 * Updates 3D Character joint transformations, limbs walking animations, and facial gestures
 */
export function animateExplorerCharacter(
  meshes: CharacterMeshes,
  state: CharacterControllerState,
  delta: number,
  elapsedTime: number
) {
  const { rootGroup, body, head, leftArm, rightArm, leftLeg, rightLeg, hat, targetMarker, speechBubble } = meshes;

  // Smooth rotation towards target direction
  let rotDiff = state.targetRotationY - state.rotationY;
  while (rotDiff > Math.PI) rotDiff -= Math.PI * 2;
  while (rotDiff < -Math.PI) rotDiff += Math.PI * 2;
  state.rotationY += rotDiff * Math.min(1, delta * 12);
  rootGroup.rotation.y = state.rotationY;
  rootGroup.position.set(state.x, state.y, state.z);

  // Update target marker visibility and animation
  if (state.targetPosition) {
    targetMarker.visible = true;
    targetMarker.position.set(state.targetPosition.x, 1.52, state.targetPosition.z);
    const markerScale = 1.0 + Math.sin(elapsedTime * 8) * 0.15;
    targetMarker.scale.set(markerScale, markerScale, markerScale);
    (targetMarker.material as THREE.MeshBasicMaterial).opacity = 0.75;
  } else {
    targetMarker.visible = false;
  }

  // Update Speech Bubble
  if (state.bubbleText) {
    speechBubble.visible = true;
    const bubbleMat = (speechBubble.children[0] as THREE.Sprite).material;
    bubbleMat.opacity = Math.min(1, state.bubbleTimer * 2);
    speechBubble.position.y = 1.65 + Math.sin(elapsedTime * 3) * 0.04;
  } else {
    speechBubble.visible = false;
  }

  // ANIMATION STATES
  const isMoving = state.isMoving;
  const isRunning = state.isRunning;
  const action = state.currentAction;

  if (action === 'sit') {
    // Sitting pose
    body.position.y = 0.32;
    head.position.y = 0.79;
    hat.position.y = 1.02;

    leftLeg.rotation.x = -Math.PI / 2;
    leftLeg.position.set(-0.13, 0.12, 0.12);
    rightLeg.rotation.x = -Math.PI / 2;
    rightLeg.position.set(0.13, 0.12, 0.12);

    leftArm.rotation.x = -Math.PI / 4;
    rightArm.rotation.x = -Math.PI / 4;
    leftArm.rotation.z = 0;
    rightArm.rotation.z = 0;

    // Gentle cozy breathing
    head.rotation.y = Math.sin(elapsedTime * 1.5) * 0.15;
    body.rotation.z = 0;
    return;
  }

  if (action === 'wave') {
    // Waving pose
    leftLeg.rotation.x = 0;
    rightLeg.rotation.x = 0;
    leftLeg.position.set(-0.13, 0.16, 0);
    rightLeg.position.set(0.13, 0.16, 0);

    body.position.y = 0.48;
    head.position.y = 0.95;
    hat.position.y = 1.18;

    leftArm.rotation.x = 0;
    leftArm.rotation.z = 0;

    // Right arm waving high in the air
    rightArm.rotation.x = 0;
    rightArm.rotation.z = Math.PI * 0.8 + Math.sin(elapsedTime * 10) * 0.4;
    head.rotation.z = Math.sin(elapsedTime * 5) * 0.1;
    return;
  }

  if (action === 'cheer') {
    // Cheering jump pose
    const jumpY = Math.abs(Math.sin(elapsedTime * 6)) * 0.3;
    rootGroup.position.y = state.y + jumpY;

    leftArm.rotation.z = Math.PI * 0.75 + Math.sin(elapsedTime * 8) * 0.2;
    rightArm.rotation.z = -Math.PI * 0.75 - Math.sin(elapsedTime * 8) * 0.2;
    leftArm.rotation.x = 0;
    rightArm.rotation.x = 0;

    leftLeg.rotation.x = 0;
    rightLeg.rotation.x = 0;
    return;
  }

  if (isMoving) {
    // Walking / Running swing frequency & amplitude
    const freq = isRunning ? 14 : 9;
    const amp = isRunning ? 0.75 : 0.45;
    const bounceAmp = isRunning ? 0.08 : 0.04;

    const swing = Math.sin(elapsedTime * freq);

    // Leg swings (opposite phases)
    leftLeg.rotation.x = swing * amp;
    rightLeg.rotation.x = -swing * amp;
    leftLeg.position.set(-0.13, 0.16, 0);
    rightLeg.position.set(0.13, 0.16, 0);

    // Arm swings (opposite to legs)
    leftArm.rotation.x = -swing * amp;
    rightArm.rotation.x = swing * amp;
    leftArm.rotation.z = 0.1;
    rightArm.rotation.z = -0.1;

    // Subtle body bounce & forward tilt
    body.position.y = 0.48 + Math.abs(swing) * bounceAmp;
    head.position.y = 0.95 + Math.abs(swing) * bounceAmp;
    hat.position.y = 1.18 + Math.abs(swing) * bounceAmp;

    body.rotation.x = isRunning ? 0.15 : 0.06;
    head.rotation.x = isRunning ? 0.1 : 0.04;
    head.rotation.y = 0;
    head.rotation.z = 0;
  } else {
    // IDLE BREATHING & LOOKING AROUND
    const breath = Math.sin(elapsedTime * 2.5) * 0.015;

    body.position.y = 0.48 + breath;
    head.position.y = 0.95 + breath * 1.5;
    hat.position.y = 1.18 + breath * 1.5;

    body.rotation.x = 0;
    body.rotation.z = 0;

    // Reset limbs
    leftLeg.rotation.x = 0;
    rightLeg.rotation.x = 0;
    leftLeg.position.set(-0.13, 0.16, 0);
    rightLeg.position.set(0.13, 0.16, 0);

    leftArm.rotation.x = Math.sin(elapsedTime * 2) * 0.05;
    rightArm.rotation.x = -Math.sin(elapsedTime * 2) * 0.05;
    leftArm.rotation.z = 0.08;
    rightArm.rotation.z = -0.08;

    // Head looking around smoothly during idle
    head.rotation.y = Math.sin(elapsedTime * 0.8) * 0.25;
    head.rotation.x = Math.sin(elapsedTime * 1.2) * 0.06;
    hat.rotation.y = head.rotation.y;
  }
}
