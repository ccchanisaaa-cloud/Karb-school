import { 
  auth, 
  db, 
  signInAnonymously, 
  onAuthStateChanged, 
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  sendPasswordResetEmail,
  GoogleAuthProvider,
  signInWithPopup,
  signOut,
  updateProfile,
  doc, 
  getDoc, 
  setDoc, 
  updateDoc, 
  collection, 
  addDoc, 
  query, 
  where, 
  onSnapshot, 
  serverTimestamp,
  getDocs,
  deleteDoc,
  FirebaseUser 
} from '../firebase';
import { UserStats, ProofPhoto, PlacedDecoration } from '../types';

export const loginWithEmail = async (email: string, pass: string) => {
  const userCred = await signInWithEmailAndPassword(auth, email, pass);
  return userCred.user;
};

export const registerWithEmail = async (email: string, pass: string, name: string) => {
  const userCred = await createUserWithEmailAndPassword(auth, email, pass);
  if (name && userCred.user) {
    await updateProfile(userCred.user, { displayName: name });
  }
  return userCred.user;
};

export const resetPassword = async (email: string) => {
  await sendPasswordResetEmail(auth, email);
};

export const loginWithGoogle = async () => {
  const provider = new GoogleAuthProvider();
  const userCred = await signInWithPopup(auth, provider);
  return userCred.user;
};

export const logoutUser = async () => {
  await signOut(auth);
};

export const ensureAuth = (): Promise<FirebaseUser> => {
  return new Promise((resolve, reject) => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        unsubscribe();
        resolve(user);
      } else {
        try {
          const userCred = await signInAnonymously(auth);
          unsubscribe();
          resolve(userCred.user);
        } catch (err) {
          unsubscribe();
          reject(err);
        }
      }
    });
  });
};

export const subscribeUserStats = (
  uid: string, 
  initialStats: UserStats,
  onData: (stats: UserStats) => void
) => {
  const userRef = doc(db, 'users', uid);

  return onSnapshot(userRef, async (snapshot) => {
    if (snapshot.exists()) {
      const data = snapshot.data();
      onData({
        todayCO2: data.todayCO2 ?? initialStats.todayCO2,
        totalCO2: data.totalCO2 ?? initialStats.totalCO2,
        coins: data.coins ?? initialStats.coins,
        streak: data.streak ?? initialStats.streak,
        level: data.level ?? initialStats.level,
        experience: data.experience ?? initialStats.experience,
        treesPlanted: data.treesPlanted ?? initialStats.treesPlanted,
        petId: data.petId ?? initialStats.petId,
      });
    } else {
      // Initialize Firestore document with initialStats
      await setDoc(userRef, {
        ...initialStats,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      onData(initialStats);
    }
  });
};

export const saveUserStatsToFirestore = async (uid: string, stats: UserStats) => {
  try {
    const userRef = doc(db, 'users', uid);
    await setDoc(userRef, {
      ...stats,
      updatedAt: serverTimestamp(),
    }, { merge: true });
  } catch (error) {
    console.error('Error saving user stats to Firestore:', error);
  }
};

export const updateUserProfileInFirestore = async (
  uid: string, 
  displayName: string, 
  avatarUrl: string
) => {
  try {
    const userRef = doc(db, 'users', uid);
    await updateDoc(userRef, {
      displayName,
      avatarUrl,
      updatedAt: serverTimestamp(),
    });
    if (auth.currentUser) {
      await updateProfile(auth.currentUser, {
        displayName,
        photoURL: avatarUrl,
      });
    }
  } catch (error) {
    console.error('Error updating user profile in Firestore:', error);
  }
};


export const subscribeProofPhotos = (
  uid: string, 
  initialPhotos: ProofPhoto[],
  onData: (photos: ProofPhoto[]) => void
) => {
  const q = query(
    collection(db, 'proofPhotos'),
    where('userId', '==', uid)
  );

  return onSnapshot(q, async (snapshot) => {
    if (!snapshot.empty) {
      const photos: ProofPhoto[] = snapshot.docs.map(docSnap => {
        const d = docSnap.data();
        return {
          id: docSnap.id,
          date: d.date || 'วันนี้',
          actionId: d.actionId || '',
          actionNameTh: d.actionNameTh || '',
          imgUrl: d.imgUrl || '',
          caption: d.caption || '',
          verified: d.verified ?? true,
          coinsEarned: d.coinsEarned || 0,
          co2Saved: d.co2Saved || 0,
        };
      });
      onData(photos);
    } else {
      // If empty in Firestore, seed initial photos for new user so album is never blank
      for (const photo of initialPhotos) {
        await addDoc(collection(db, 'proofPhotos'), {
          ...photo,
          userId: uid,
          createdAt: serverTimestamp(),
        });
      }
    }
  }, (err) => {
    console.error('Firestore proofPhotos subscription error:', err);
  });
};

export const addProofPhotoToFirestore = async (uid: string, photo: ProofPhoto) => {
  try {
    await addDoc(collection(db, 'proofPhotos'), {
      userId: uid,
      date: photo.date,
      actionId: photo.actionId,
      actionNameTh: photo.actionNameTh,
      imgUrl: photo.imgUrl,
      caption: photo.caption,
      verified: photo.verified,
      coinsEarned: photo.coinsEarned,
      co2Saved: photo.co2Saved,
      createdAt: serverTimestamp(),
    });
  } catch (error) {
    console.error('Error adding proof photo to Firestore:', error);
  }
};

export const recordRedemptionInFirestore = async (
  uid: string, 
  rewardId: string, 
  partnerName: string, 
  title: string, 
  promoCode: string
) => {
  try {
    await addDoc(collection(db, 'userRedemptions'), {
      userId: uid,
      rewardId,
      partnerName,
      title,
      promoCode,
      redeemedAt: serverTimestamp(),
    });
  } catch (error) {
    console.error('Error recording redemption in Firestore:', error);
  }
};

export const clearUserPhotosFromFirestore = async (uid: string) => {
  try {
    const q = query(
      collection(db, 'proofPhotos'),
      where('userId', '==', uid)
    );
    const snapshot = await getDocs(q);
    const deletePromises = snapshot.docs.map(docSnap => deleteDoc(docSnap.ref));
    await Promise.all(deletePromises);
  } catch (error) {
    console.error('Error clearing user photos from Firestore:', error);
  }
};

export const saveIslandDecorationsToFirestore = async (uid: string, decorations: PlacedDecoration[]) => {
  try {
    const userRef = doc(db, 'users', uid);
    await setDoc(userRef, {
      islandDecorations: decorations,
      updatedAt: serverTimestamp(),
    }, { merge: true });
  } catch (error) {
    console.error('Error saving island decorations to Firestore:', error);
  }
};
