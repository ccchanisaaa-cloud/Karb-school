import * as XLSX from 'xlsx';
import { UserStats, DailyAction, PartnerReward, ProofPhoto, Friend } from '../types';

export interface DatabaseState {
  userStats: UserStats;
  actions: DailyAction[];
  album: ProofPhoto[];
  friends: Friend[];
  rewards: PartnerReward[];
  redemptions?: { id: string; rewardId: string; rewardTitle: string; code: string; date: string; coinsSpent: number }[];
}

export interface ExcelImportResult {
  success: boolean;
  message: string;
  data?: Partial<DatabaseState>;
  statsSummary?: {
    usersCount: number;
    actionsCount: number;
    photosCount: number;
    friendsCount: number;
    rewardsCount: number;
  };
}

/**
 * Convert the current application state into a rich multi-sheet Excel Workbook (.xlsx)
 */
export const exportDatabaseToExcel = (state: DatabaseState, filename?: string): void => {
  const wb = XLSX.utils.book_new();

  // 1. Sheet: USERS / PROFILES
  const usersData = [
    {
      'User ID Code': state.userStats.userIdCode || 'KARB-81203',
      'Display Name': state.userStats.displayName || 'นักผจญภัยรักษ์ขอบฟ้า',
      'Level': state.userStats.level,
      'Experience (XP)': state.userStats.experience,
      'Total CO2 Saved (kg)': state.userStats.totalCO2,
      'Today CO2 Saved (kg)': state.userStats.todayCO2,
      'Carbon Coins': state.userStats.coins,
      'Today Coins Earned': state.userStats.todayCoins || 0,
      'Current Streak (Days)': state.userStats.streak,
      'Trees Planted': state.userStats.treesPlanted,
      'Active Pet ID': state.userStats.petId,
      'Avatar': state.userStats.avatarUrl || '🌱',
      'Last Updated': new Date().toLocaleString('th-TH'),
    }
  ];
  const usersWs = XLSX.utils.json_to_sheet(usersData);
  usersWs['!cols'] = [
    { wch: 15 }, { wch: 25 }, { wch: 8 }, { wch: 16 }, { wch: 20 },
    { wch: 20 }, { wch: 14 }, { wch: 18 }, { wch: 20 }, { wch: 14 },
    { wch: 15 }, { wch: 15 }, { wch: 22 }
  ];
  XLSX.utils.book_append_sheet(wb, usersWs, 'USERS');

  // 2. Sheet: ACTIONS_CATALOG
  const actionsData = state.actions.map((act, index) => ({
    'No': index + 1,
    'Action ID': act.id,
    'Name (Thai)': act.nameTh,
    'Short Label': act.shortLabelTh || act.nameTh,
    'Name (English)': act.nameEn,
    'Emoji': act.emoji || '🌱',
    'Category': act.category,
    'Base CO2 (kg)': act.baseCO2,
    'Coin Reward': act.coinReward,
    'Proof Required': act.proofNeeded ? 'YES' : 'NO',
    'Details (Thai)': act.detailsTh,
  }));
  const actionsWs = XLSX.utils.json_to_sheet(actionsData);
  actionsWs['!cols'] = [
    { wch: 6 }, { wch: 16 }, { wch: 25 }, { wch: 20 }, { wch: 24 },
    { wch: 8 }, { wch: 14 }, { wch: 14 }, { wch: 14 }, { wch: 14 }, { wch: 45 }
  ];
  XLSX.utils.book_append_sheet(wb, actionsWs, 'ACTIONS_CATALOG');

  // 3. Sheet: COMPLETED_LOGS / PHOTO_ALBUM
  const albumData = state.album.map((item, index) => ({
    'No': index + 1,
    'Photo ID': item.id,
    'Date Recorded': item.date,
    'Action ID': item.actionId,
    'Action Name (Thai)': item.actionNameTh,
    'CO2 Saved (kg)': item.co2Saved,
    'Coins Earned': item.coinsEarned,
    'AI Verified': item.verified ? 'VERIFIED' : 'PENDING',
    'User Caption': item.caption,
    'Image URL': item.imgUrl,
  }));
  const albumWs = XLSX.utils.json_to_sheet(albumData);
  albumWs['!cols'] = [
    { wch: 6 }, { wch: 12 }, { wch: 16 }, { wch: 18 }, { wch: 25 },
    { wch: 15 }, { wch: 14 }, { wch: 14 }, { wch: 35 }, { wch: 40 }
  ];
  XLSX.utils.book_append_sheet(wb, albumWs, 'COMPLETED_LOGS');

  // 4. Sheet: FRIENDS_NETWORK
  const friendsData = state.friends.map((f, index) => ({
    'No': index + 1,
    'Friend ID': f.id,
    'Name': f.name,
    'User Code': f.userIdCode,
    'Avatar': f.avatar,
    'Level': f.level,
    'Total CO2 (kg)': f.totalCO2,
    'Completed Actions': f.completedActions,
    'Status': f.status,
    'Joined Date': f.joinedDate,
  }));
  const friendsWs = XLSX.utils.json_to_sheet(friendsData);
  friendsWs['!cols'] = [
    { wch: 6 }, { wch: 12 }, { wch: 22 }, { wch: 14 }, { wch: 8 },
    { wch: 8 }, { wch: 14 }, { wch: 18 }, { wch: 10 }, { wch: 16 }
  ];
  XLSX.utils.book_append_sheet(wb, friendsWs, 'FRIENDS');

  // 5. Sheet: STORE_REWARDS
  const rewardsData = state.rewards.map((r, index) => ({
    'No': index + 1,
    'Reward ID': r.id,
    'Title (Thai)': r.title,
    'Partner Name': r.partnerName,
    'Category': r.category,
    'Coin Cost': r.coinCost,
    'Promo Code': r.promoCode,
    'Redeemed Count': r.redeemedCount,
    'Description': r.description,
  }));
  const rewardsWs = XLSX.utils.json_to_sheet(rewardsData);
  rewardsWs['!cols'] = [
    { wch: 6 }, { wch: 18 }, { wch: 35 }, { wch: 30 }, { wch: 12 },
    { wch: 12 }, { wch: 16 }, { wch: 16 }, { wch: 45 }
  ];
  XLSX.utils.book_append_sheet(wb, rewardsWs, 'STORE_REWARDS');

  // Generate date stamp for file name
  const now = new Date();
  const dateStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
  const outFileName = filename || `EcoQuest_Database_${dateStr}.xlsx`;

  // Write and trigger download
  XLSX.writeFile(wb, outFileName);
};

/**
 * Import and parse an Excel (.xlsx / .xls / .csv) file to update the database
 */
export const importDatabaseFromExcel = async (file: File): Promise<ExcelImportResult> => {
  return new Promise((resolve) => {
    const reader = new FileReader();

    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: 'array' });

        const importedData: Partial<DatabaseState> = {};
        const summary = {
          usersCount: 0,
          actionsCount: 0,
          photosCount: 0,
          friendsCount: 0,
          rewardsCount: 0,
        };

        // 1. Read USERS sheet
        const userSheetName = workbook.SheetNames.find(s => s.toUpperCase().includes('USER'));
        if (userSheetName) {
          const userRows: any[] = XLSX.utils.sheet_to_json(workbook.Sheets[userSheetName]);
          if (userRows.length > 0) {
            const firstRow = userRows[0];
            importedData.userStats = {
              userIdCode: String(firstRow['User ID Code'] || firstRow['userIdCode'] || firstRow['User Code'] || 'KARB-81203'),
              displayName: String(firstRow['Display Name'] || firstRow['displayName'] || firstRow['Name'] || 'นักผจญภัยรักษ์ขอบฟ้า'),
              level: Number(firstRow['Level'] || firstRow['level'] || 1),
              experience: Number(firstRow['Experience (XP)'] || firstRow['experience'] || firstRow['XP'] || 0),
              totalCO2: Number(firstRow['Total CO2 Saved (kg)'] || firstRow['totalCO2'] || firstRow['Total CO2'] || 0),
              todayCO2: Number(firstRow['Today CO2 Saved (kg)'] || firstRow['todayCO2'] || 0),
              coins: Number(firstRow['Carbon Coins'] || firstRow['coins'] || 0),
              todayCoins: Number(firstRow['Today Coins Earned'] || firstRow['todayCoins'] || 0),
              streak: Number(firstRow['Current Streak (Days)'] || firstRow['streak'] || 1),
              treesPlanted: Number(firstRow['Trees Planted'] || firstRow['treesPlanted'] || 0),
              petId: String(firstRow['Active Pet ID'] || firstRow['petId'] || 'nong_cloud'),
              avatarUrl: String(firstRow['Avatar'] || firstRow['avatarUrl'] || '🌱'),
            };
            summary.usersCount = userRows.length;
          }
        }

        // 2. Read ACTIONS_CATALOG sheet
        const actionSheetName = workbook.SheetNames.find(s => s.toUpperCase().includes('ACTION'));
        if (actionSheetName) {
          const actionRows: any[] = XLSX.utils.sheet_to_json(workbook.Sheets[actionSheetName]);
          if (actionRows.length > 0) {
            importedData.actions = actionRows.map((r) => ({
              id: String(r['Action ID'] || r['id'] || `act_${Date.now()}`),
              nameTh: String(r['Name (Thai)'] || r['nameTh'] || r['Name'] || 'กิจกรรมรักษ์โลก'),
              shortLabelTh: String(r['Short Label'] || r['shortLabelTh'] || r['nameTh'] || ''),
              nameEn: String(r['Name (English)'] || r['nameEn'] || ''),
              emoji: String(r['Emoji'] || r['emoji'] || '🌱'),
              baseCO2: Number(r['Base CO2 (kg)'] || r['baseCO2'] || 0.5),
              coinReward: Number(r['Coin Reward'] || r['coinReward'] || 10),
              category: (r['Category'] || r['category'] || 'reusable') as any,
              iconName: 'Leaf',
              detailsTh: String(r['Details (Thai)'] || r['detailsTh'] || ''),
              proofNeeded: String(r['Proof Required'] || r['proofNeeded'] || 'YES').toUpperCase() === 'YES',
              colorClass: 'from-emerald-400 to-teal-500',
            }));
            summary.actionsCount = importedData.actions.length;
          }
        }

        // 3. Read COMPLETED_LOGS sheet
        const logsSheetName = workbook.SheetNames.find(s => s.toUpperCase().includes('LOG') || s.toUpperCase().includes('PHOTO') || s.toUpperCase().includes('ALBUM'));
        if (logsSheetName) {
          const logsRows: any[] = XLSX.utils.sheet_to_json(workbook.Sheets[logsSheetName]);
          if (logsRows.length > 0) {
            importedData.album = logsRows.map((r, i) => ({
              id: String(r['Photo ID'] || r['id'] || `p_${Date.now()}_${i}`),
              date: String(r['Date Recorded'] || r['date'] || new Date().toLocaleDateString('th-TH')),
              actionId: String(r['Action ID'] || r['actionId'] || 'clean_plate'),
              actionNameTh: String(r['Action Name (Thai)'] || r['actionNameTh'] || 'กิจกรรมรักษ์โลก'),
              co2Saved: Number(r['CO2 Saved (kg)'] || r['co2Saved'] || 0.5),
              coinsEarned: Number(r['Coins Earned'] || r['coinsEarned'] || 10),
              verified: String(r['AI Verified'] || r['verified'] || 'VERIFIED').toUpperCase() === 'VERIFIED',
              caption: String(r['User Caption'] || r['caption'] || ''),
              imgUrl: String(r['Image URL'] || r['imgUrl'] || 'https://images.unsplash.com/photo-1540189549336-e6e99c3679fe?auto=format&fit=crop&q=80&w=400'),
            }));
            summary.photosCount = importedData.album.length;
          }
        }

        // 4. Read FRIENDS sheet
        const friendsSheetName = workbook.SheetNames.find(s => s.toUpperCase().includes('FRIEND'));
        if (friendsSheetName) {
          const friendRows: any[] = XLSX.utils.sheet_to_json(workbook.Sheets[friendsSheetName]);
          if (friendRows.length > 0) {
            importedData.friends = friendRows.map((r, i) => ({
              id: String(r['Friend ID'] || r['id'] || `f_${Date.now()}_${i}`),
              name: String(r['Name'] || r['name'] || 'เพื่อนรักษ์โลก'),
              userIdCode: String(r['User Code'] || r['userIdCode'] || `KARB-${1000 + i}`),
              avatar: String(r['Avatar'] || r['avatar'] || '🦊'),
              avatarType: 'emoji',
              level: Number(r['Level'] || r['level'] || 1),
              totalCO2: Number(r['Total CO2 (kg)'] || r['totalCO2'] || 5.0),
              completedActions: Number(r['Completed Actions'] || r['completedActions'] || 5),
              status: (r['Status'] || 'online') as any,
              joinedDate: String(r['Joined Date'] || r['joinedDate'] || '1 ส.ค. 2026'),
            }));
            summary.friendsCount = importedData.friends.length;
          }
        }

        // 5. Read STORE_REWARDS sheet
        const rewardsSheetName = workbook.SheetNames.find(s => s.toUpperCase().includes('REWARD') || s.toUpperCase().includes('STORE'));
        if (rewardsSheetName) {
          const rewardRows: any[] = XLSX.utils.sheet_to_json(workbook.Sheets[rewardsSheetName]);
          if (rewardRows.length > 0) {
            importedData.rewards = rewardRows.map((r, i) => ({
              id: String(r['Reward ID'] || r['id'] || `rew_${Date.now()}_${i}`),
              title: String(r['Title (Thai)'] || r['title'] || 'รางวัลรักษ์โลก'),
              partnerName: String(r['Partner Name'] || r['partnerName'] || 'Green Partner'),
              category: (r['Category'] || r['category'] || 'drink') as any,
              coinCost: Number(r['Coin Cost'] || r['coinCost'] || 100),
              promoCode: String(r['Promo Code'] || r['promoCode'] || 'GREENOFF'),
              redeemedCount: Number(r['Redeemed Count'] || r['redeemedCount'] || 0),
              description: String(r['Description'] || r['description'] || ''),
              imageUrl: '🎁',
            }));
            summary.rewardsCount = importedData.rewards.length;
          }
        }

        resolve({
          success: true,
          message: `นำเข้าไฟล์ Excel สำเร็จ! พบข้อมูลใน ${workbook.SheetNames.length} ชีต`,
          data: importedData,
          statsSummary: summary
        });
      } catch (err: any) {
        console.error('Error importing Excel database:', err);
        resolve({
          success: false,
          message: `เกิดข้อผิดพลาดในการอ่านไฟล์ Excel: ${err?.message || 'ไฟล์ไม่ถูกต้อง'}`
        });
      }
    };

    reader.onerror = () => {
      resolve({
        success: false,
        message: 'ไม่สามารถอ่านไฟล์ได้ โปรดลองอีกครั้ง'
      });
    };

    reader.readAsArrayBuffer(file);
  });
};

/**
 * Export single table as CSV
 */
export const exportTableToCSV = (data: any[], filename: string): void => {
  const ws = XLSX.utils.json_to_sheet(data);
  const csv = XLSX.utils.sheet_to_csv(ws);
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `${filename}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};
